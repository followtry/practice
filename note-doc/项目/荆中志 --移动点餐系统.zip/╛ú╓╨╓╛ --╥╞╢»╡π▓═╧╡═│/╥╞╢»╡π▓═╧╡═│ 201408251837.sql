prompt PL/SQL Developer import file
prompt Created on 2014��8��25�� ����һ by new
set feedback off
set define off
prompt Creating COUNT_TABLE...
create table COUNT_TABLE
(
  cid       NUMBER not null,
  mid       NUMBER(3) not null,
  orderdate DATE not null,
  tid       NUMBER(2) not null,
  mnum      NUMBER(3) default 1 not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column COUNT_TABLE.cid
  is 'ͳ�Ʊ��(����1)';
comment on column COUNT_TABLE.mid
  is '�˱��';
comment on column COUNT_TABLE.orderdate
  is '����ʱ��';
comment on column COUNT_TABLE.tid
  is '����(������)';
comment on column COUNT_TABLE.mnum
  is 'ÿ��������';
alter table COUNT_TABLE
  add constraint PK_COUNT_TABLE_CID primary key (CID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt Creating DINING_TABLE...
create table DINING_TABLE
(
  tid    NUMBER(2) not null,
  pnum   NUMBER(2) not null,
  tstate NUMBER(1) default 0 not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column DINING_TABLE.tid
  is '�����';
comment on column DINING_TABLE.pnum
  is '���������';
comment on column DINING_TABLE.tstate
  is '����״̬(1,����;0,����)';
alter table DINING_TABLE
  add constraint PK_DINING_TABLE_ primary key (TID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt Creating MENU...
create table MENU
(
  mid    NUMBER(3) not null,
  mname  VARCHAR2(30) not null,
  mprice NUMBER(3) not null,
  mtype  NUMBER(2) not null,
  mpic   VARCHAR2(100)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column MENU.mid
  is '�˱��';
comment on column MENU.mname
  is '����';
comment on column MENU.mprice
  is '�˼�';
comment on column MENU.mtype
  is '������(1,��Ʒ\2,���\3,�ز�\4,��ˮ\5\��\6��ʳ\7.����)';
comment on column MENU.mpic
  is '��ͼƬ��ַ';
alter table MENU
  add constraint PK_MENU_MID primary key (MID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table MENU
  add constraint UQ_MENU_MNAME unique (MNAME)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt Creating ORDERMEAL...
create table ORDERMEAL
(
  tid       NUMBER(2) not null,
  mid       NUMBER(3) not null,
  mnum      NUMBER(3) default 0 not null,
  orderdate DATE,
  ostat     NUMBER default 0 not null
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
comment on column ORDERMEAL.tid
  is '����(������)';
comment on column ORDERMEAL.mid
  is '�˱��';
comment on column ORDERMEAL.mnum
  is 'ÿ��������';
comment on column ORDERMEAL.orderdate
  is '���ʱ��';
comment on column ORDERMEAL.ostat
  is '����״̬. 0��δ����,1�Ǵ���,2���Ѿ�����';

prompt Creating USERS...
create table USERS
(
  id       NUMBER not null,
  username VARCHAR2(20) not null,
  pwd      VARCHAR2(30),
  nickname VARCHAR2(20),
  money    NUMBER,
  type     NUMBER(1)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table USERS
  add constraint PK_USERS_ID primary key (ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt Disabling triggers for COUNT_TABLE...
alter table COUNT_TABLE disable all triggers;
prompt Disabling triggers for DINING_TABLE...
alter table DINING_TABLE disable all triggers;
prompt Disabling triggers for MENU...
alter table MENU disable all triggers;
prompt Disabling triggers for ORDERMEAL...
alter table ORDERMEAL disable all triggers;
prompt Disabling triggers for USERS...
alter table USERS disable all triggers;
prompt Loading COUNT_TABLE...
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (5, 3, to_date('23-08-2014 17:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 3);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (6, 2, to_date('23-08-2013 17:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 4);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (7, 2, to_date('23-08-2013 17:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (11, 10, to_date('23-08-2013 18:25:51', 'dd-mm-yyyy hh24:mi:ss'), 1, 6);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (3, 6, to_date('23-08-2013 17:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (4, 5, to_date('23-08-2013 17:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 2);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (12, 4, to_date('23-08-2014 18:55:35', 'dd-mm-yyyy hh24:mi:ss'), 3, 7);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (13, 5, to_date('23-08-2014 18:55:35', 'dd-mm-yyyy hh24:mi:ss'), 3, 2);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (14, 5, to_date('24-08-2014 12:08:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 5);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (15, 9, to_date('24-08-2014 12:08:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (16, 6, to_date('24-08-2014 12:08:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 3);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (17, 4, to_date('24-08-2014 12:08:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 5);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (18, 10, to_date('24-08-2014 12:11:44', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (19, 9, to_date('24-08-2014 12:11:44', 'dd-mm-yyyy hh24:mi:ss'), 1, 2);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (22, 5, to_date('24-08-2014 12:33:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 3);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (23, 6, to_date('24-08-2014 12:33:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 2);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (24, 3, to_date('24-08-2014 12:33:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (25, 4, to_date('24-08-2014 12:33:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 2);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (26, 17, to_date('24-08-2014 12:41:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (27, 21, to_date('24-08-2014 12:41:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (28, 20, to_date('24-08-2014 12:41:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 3);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (29, 18, to_date('24-08-2014 12:41:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (30, 9, to_date('24-08-2014 12:41:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (31, 19, to_date('24-08-2014 12:41:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 3);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (32, 3, to_date('24-08-2014 13:53:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (33, 4, to_date('24-08-2014 13:53:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (40, 5, to_date('25-08-2014 15:40:44', 'dd-mm-yyyy hh24:mi:ss'), 7, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (1, 4, to_date('23-08-2014 16:02:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (2, 4, to_date('23-08-2014 16:02:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (34, 6, to_date('24-08-2014 19:15:08', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (35, 9, to_date('24-08-2014 19:15:08', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (36, 5, to_date('24-08-2014 19:15:08', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (20, 2, to_date('24-08-2014 12:31:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (21, 3, to_date('24-08-2014 12:31:27', 'dd-mm-yyyy hh24:mi:ss'), 2, 2);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (10, 3, to_date('23-08-2014 18:01:50', 'dd-mm-yyyy hh24:mi:ss'), 1, 3);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (8, 5, to_date('23-08-2014 18:01:50', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (9, 5, to_date('23-08-2014 18:01:50', 'dd-mm-yyyy hh24:mi:ss'), 1, 6);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (37, 4, to_date('25-08-2014 09:54:33', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (38, 9, to_date('25-08-2014 09:54:33', 'dd-mm-yyyy hh24:mi:ss'), 1, 1);
insert into COUNT_TABLE (cid, mid, orderdate, tid, mnum)
values (39, 3, to_date('25-08-2014 09:54:33', 'dd-mm-yyyy hh24:mi:ss'), 1, 2);
commit;
prompt 40 records loaded
prompt Loading DINING_TABLE...
insert into DINING_TABLE (tid, pnum, tstate)
values (1, 12, 1);
insert into DINING_TABLE (tid, pnum, tstate)
values (2, 15, 1);
insert into DINING_TABLE (tid, pnum, tstate)
values (3, 8, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (4, 8, 1);
insert into DINING_TABLE (tid, pnum, tstate)
values (5, 8, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (6, 12, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (7, 12, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (8, 12, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (9, 15, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (10, 12, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (11, 6, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (12, 6, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (13, 6, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (14, 8, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (15, 8, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (16, 15, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (17, 15, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (18, 15, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (19, 20, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (20, 20, 0);
insert into DINING_TABLE (tid, pnum, tstate)
values (21, 20, 0);
commit;
prompt 21 records loaded
prompt Loading MENU...
insert into MENU (mid, mname, mprice, mtype, mpic)
values (3, '��˿ƻ��', 12, 1, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (54, 'СҰ����Ģ��', 65, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (1, '�˱�Ѽ', 12, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (56, '���ϴ�', 120, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (59, '�ھ�', 88, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (2, '�Ͷ�ţ��', 46, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (62, 'qweqw', 123, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (63, '232', 124, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (30, '������', 6, 6, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (31, '���մ�Ϻ', 37, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (32, '��������', 36, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (33, '���˶���', 23, 3, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (34, '���Ͷ���', 22, 3, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (35, '�峤���', 5, 6, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (36, '��ͷ', 1, 6, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (37, '�ҳ�����', 15, 3, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (38, '��֭����', 56, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (39, '������˿', 34, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (40, '�ɿ�֭�����', 4, 1, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (41, '���Ŷ���', 14, 3, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (42, '���ɾ�', 86, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (43, '���ؼ�', 120, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (44, '������', 150, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (45, '��ͷ��', 450, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (46, '����Һ', 760, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (47, '��ɽơ��', 6, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (48, '�ൺơ��', 12, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (49, 'ѩ��ơ��', 7, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (50, '����ͷ', 54, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (51, 'С��', 54, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (60, '��������', 12, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (57, '��������', 45, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (61, '���Ƕ���ͷ', 56, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (4, '��˿�㽶', 11, 1, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (5, '�����ʼ�', 32, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (6, '�׶�������', 38, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (52, '����̨', 55, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (55, '�ž�����', 343, 4, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (9, '��������', 32, 1, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (10, '�˰���', 43, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (12, '���������', 18, 5, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (13, '�����', 14, 3, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (14, '���Ͳ�', 12, 3, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (15, '��Ƥ��Ѽ', 34, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (16, '�б����� ', 43, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (17, '��Ƥը��', 24, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (18, '��������', 23, 5, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (19, '�ϴ׻���', 14, 7, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (20, '��˿��Ƥ', 16, 7, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (21, '����ϡ��', 3, 6, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (22, '����������', 11, 5, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (23, '���Ƹɱ�', 34, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (24, 'ެ�Ѽ�������', 8, 6, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (25, '��伦��', 23, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (26, 'ܽ��Ϻ��', 43, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (27, '��ଶ���', 16, 3, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (28, '������', 42, 5, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (29, '��������', 34, 2, null);
insert into MENU (mid, mname, mprice, mtype, mpic)
values (58, '��������', 45, 2, null);
commit;
prompt 59 records loaded
prompt Loading ORDERMEAL...
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (4, 36, 1, to_date('25-08-2014 14:59:34', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (1, 5, 1, to_date('25-08-2014 15:39:46', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (2, 5, 1, to_date('25-08-2014 11:05:31', 'dd-mm-yyyy hh24:mi:ss'), 0);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (2, 6, 1, to_date('25-08-2014 11:05:31', 'dd-mm-yyyy hh24:mi:ss'), 0);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (2, 48, 3, to_date('25-08-2014 11:05:53', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (2, 49, 3, to_date('25-08-2014 11:05:31', 'dd-mm-yyyy hh24:mi:ss'), 0);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (2, 48, 7, to_date('25-08-2014 11:05:31', 'dd-mm-yyyy hh24:mi:ss'), 0);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (2, 9, 1, to_date('25-08-2014 11:05:50', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (2, 49, 3, to_date('25-08-2014 11:05:55', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (2, 4, 1, to_date('25-08-2014 11:05:57', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (2, 47, 3, to_date('25-08-2014 11:10:47', 'dd-mm-yyyy hh24:mi:ss'), 0);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (4, 39, 1, to_date('25-08-2014 09:56:38', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (4, 36, 4, to_date('25-08-2014 09:56:03', 'dd-mm-yyyy hh24:mi:ss'), 0);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (4, 35, 1, to_date('25-08-2014 09:56:48', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (4, 46, 2, to_date('25-08-2014 09:56:03', 'dd-mm-yyyy hh24:mi:ss'), 0);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (4, 10, 1, to_date('25-08-2014 09:56:36', 'dd-mm-yyyy hh24:mi:ss'), 1);
insert into ORDERMEAL (tid, mid, mnum, orderdate, ostat)
values (4, 12, 1, to_date('25-08-2014 09:56:41', 'dd-mm-yyyy hh24:mi:ss'), 1);
commit;
prompt 17 records loaded
prompt Loading USERS...
insert into USERS (id, username, pwd, nickname, money, type)
values (6, 'ad', 'ad', '����Ա', 300, 1);
insert into USERS (id, username, pwd, nickname, money, type)
values (1, 'jing', '123', 'JZZ', 56000, 2);
insert into USERS (id, username, pwd, nickname, money, type)
values (5, 'jingg', 'jinggg', '����־', 3200, 2);
insert into USERS (id, username, pwd, nickname, money, type)
values (2, 'admin', 'admin', '��������Ա', 0, 3);
insert into USERS (id, username, pwd, nickname, money, type)
values (7, '123', '123', '234', 123, 2);
commit;
prompt 5 records loaded
prompt Enabling triggers for COUNT_TABLE...
alter table COUNT_TABLE enable all triggers;
prompt Enabling triggers for DINING_TABLE...
alter table DINING_TABLE enable all triggers;
prompt Enabling triggers for MENU...
alter table MENU enable all triggers;
prompt Enabling triggers for ORDERMEAL...
alter table ORDERMEAL enable all triggers;
prompt Enabling triggers for USERS...
alter table USERS enable all triggers;
set feedback on
set define on
prompt Done.
