/**
 * @author ����־
 * @time 2014-8-22 ����01:14:55
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JComboBox;

import com.neusoft.bean.Dining_table;
import com.neusoft.bean.Menu;
import com.neusoft.service.BookDinnerService;
import com.neusoft.service.ManageService;

import java.awt.event.KeyEvent;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;

/**
 * @author new
 *
 */
public class ManageOrder extends JFrame {
	
	private ManageService ms=new ManageService();  //  @jve:decl-index=0:
	
	private DefaultTableModel dtnot=new DefaultTableModel();
	
    private int tableId=0;

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel selectTidLabel = null;

	private JComboBox tidComboBox = null;

	private JLabel notserverLabel = null;

	private JScrollPane jScrollPane = null;

	private JTable notServerTable = null;

	private JButton addFoodButton = null;

	/**
	 * This is the default constructor
	 */
	public ManageOrder() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(458, 642);
		this.setContentPane(getJContentPane());
		this.setTitle("��������");
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			notserverLabel = new JLabel();
			notserverLabel.setBounds(new Rectangle(33, 55, 248, 35));
			notserverLabel.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			notserverLabel.setHorizontalAlignment(SwingConstants.CENTER);
			notserverLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			notserverLabel.setText("δ�ϵĲ��Ȼ��ˮ");
			selectTidLabel = new JLabel();
			selectTidLabel.setBounds(new Rectangle(9, 10, 127, 35));
			selectTidLabel.setText("ѡ������:");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(selectTidLabel, null);
			jContentPane.add(getTidComboBox(), null);
			jContentPane.add(notserverLabel, null);
			jContentPane.add(getJScrollPane(), null);
			jContentPane.add(getAddFoodButton(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes tidComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getTidComboBox() {
		
		
		if (tidComboBox == null) {
			tidComboBox = new JComboBox();
			tidComboBox.setBounds(new Rectangle(139, 11, 155, 34));
			tidComboBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("--��������--����----"); // TODO Auto-generated Event stub actionPerformed()
					tableId=Integer.parseInt(tidComboBox.getSelectedItem()+"");
					getNotServerTable();
				}
			});
		
			
			getTableId(tidComboBox);
		}
		return tidComboBox;
	}
	
	/**
	 * @func ��ȡ����ʹ���е����ӵ�id
	 * @param queryTable
	 */
	private void getTableId(JComboBox queryTable){
		BookDinnerService bDS=new BookDinnerService();
		List<Dining_table> tables=bDS.findOccupyTable();
		queryTable.removeAllItems();
		for (Iterator<Dining_table> iter = tables.iterator(); iter.hasNext();) {
			Dining_table table = iter.next();
			int tid=table.getTid();
			queryTable.addItem(tid);
		}
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(14, 105, 407, 472));
			jScrollPane.setViewportView(getNotServerTable());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes notServerTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getNotServerTable() {
		BookDinnerService bDS=new BookDinnerService();
		List<Menu> menus=new ArrayList<Menu>();
		//tableId=Integer.parseInt(squareAccountComboBox.getSelectedItem()+"");
		menus=bDS.notCostGoods(tableId);
		String[] cols = {"�˱��","����","�˼�","����","����"};
		dtnot=new DefaultTableModel();
		dtnot.setColumnIdentifiers(cols);
		notCost(menus);
		
		if (notServerTable == null) {
			notServerTable = new JTable();
		}
		notServerTable.setModel(dtnot);
		notServerTable.revalidate();
		return notServerTable;
	}

	/**
	 * @func ��������Ʒ
	 * @param menus
	 */
	private void notCost(List<Menu> menus){
		
		
		if(notServerTable!=null)
			notServerTable.removeAll();
		Iterator<Menu> iter=menus.iterator();
		while(iter.hasNext()){
			Menu menu=new Menu();
			menu=iter.next();
			String type="";
			/*������(1,��Ʒ\2,���\3,�ز�\4,��ˮ\5\��\6��ʳ\7.����)*/
			switch(menu.getMtype()){
			case 1:type="��ʳ";break;
			case 2:type="���";break;
			case 3:type="�ز�";break;
			case 4:type="��ˮ";break;
			case 5:type="��";break;
			case 6:type="��ʳ";break;
			case 7:type="����";break;
			default:type="�޷���";break;
			}
			System.out.println("+++++++++++����:"+menu.getMname());
			//System.out.println(menu.getMname()+"\t"+menu.getMprice()+"\t"+menu.getMtype());
			//System.out.println(menu.getMid()+"\t"+menu.getMid()+"\t"+menu.getMname()+"\t"+menu.getMprice()+"\t"+type+"\t"+menu.getMpic());
			Object[] menuRow=new Object[]{menu.getMid(),menu.getMname(),
					menu.getMprice()+"",type,menu.getMnum()};
			dtnot.addRow(menuRow);
		}
		if (notServerTable == null) {
			notServerTable=new JTable();
			notServerTable.setModel(dtnot);
			notServerTable.setRowHeight(32);
		}
	}

	/**
	 * This method initializes addFoodButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getAddFoodButton() {
		if (addFoodButton == null) {
			addFoodButton = new JButton();
			addFoodButton.setBounds(new Rectangle(328, 56, 91, 38));
			addFoodButton.setFont(new Font("Dialog", Font.BOLD, 18));
			addFoodButton.setText("�ϲ�");
			addFoodButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("---�ϲ�---"); // TODO Auto-generated Event stub actionPerformed()
					tableId=Integer.parseInt(tidComboBox.getSelectedItem()+"");
					//System.out.println("notServerTable.getValueAt(notServerTable.getSelectedRow(), 0)"+notServerTable.getValueAt(notServerTable.getSelectedRow(), 0)+"");
					int mid=Integer.parseInt(notServerTable.getValueAt(notServerTable.getSelectedRow(),0).toString());
					int oldStat=0;
					int newStat=1;
					//JOptionPane.showMessageDialog(null, tableId+"::"+mid);
					Menu menu=new Menu();
					menu.setMid(mid);
					Dining_table dt=new Dining_table();
					dt.setTid(tableId);
					//��Ҫ����,�˺�
					int count=ms.updateMenuState(dt, menu, oldStat, newStat);
					if(count>0){
						JOptionPane.showMessageDialog(null, "��ѡ�˾��Ѿ�����");
					}else{
						JOptionPane.showMessageDialog(null, "�Ʋ�״̬��Ϣ�����쳣");
					}
					getNotServerTable();
				}
			});
		}
		return addFoodButton;
	}
}  //  @jve:decl-index=0:visual-constraint="10,10"
