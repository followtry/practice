/**
 * @author ����־
 * @time 2014-8-23 ����09:31:21
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.KeyEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;

import com.neusoft.bean.User;
import com.neusoft.service.UserService;

/**
 * @author new
 *
 */
public class AddUser extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel adduserLabel = null;

	private JLabel userNameLabel = null;

	private JLabel pwdLabel = null;

	private JLabel nicknameLabel = null;

	private JLabel moneyLabel = null;

	private JLabel typeLabel = null;

	private JTextField usernameTextField = null;

	private JPasswordField pwdPasswordField = null;

	private JTextField nicknameTextField = null;

	private JTextField moneyTextField = null;

	private JComboBox typeComboBox = null;

	private JButton cancelButton = null;

	private JButton okButton = null;

	/**
	 * This is the default constructor
	 */
	public AddUser() {
		super();
		initialize();
	}

	private void close(){
		this.setVisible(false);
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(358, 440);
		this.setContentPane(getJContentPane());
		this.setTitle("�����û�");
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			typeLabel = new JLabel();
			typeLabel.setBounds(new Rectangle(26, 280, 115, 30));
			typeLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			typeLabel.setHorizontalAlignment(SwingConstants.CENTER);
			typeLabel.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			typeLabel.setText("����:");
			moneyLabel = new JLabel();
			moneyLabel.setBounds(new Rectangle(26, 230, 115, 30));
			moneyLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			moneyLabel.setHorizontalAlignment(SwingConstants.CENTER);
			moneyLabel.setText("�˻����:");
			nicknameLabel = new JLabel();
			nicknameLabel.setBounds(new Rectangle(26, 180, 115, 30));
			nicknameLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			nicknameLabel.setHorizontalAlignment(SwingConstants.CENTER);
			nicknameLabel.setText("�ǳ�:");
			pwdLabel = new JLabel();
			pwdLabel.setBounds(new Rectangle(26, 130, 115, 30));
			pwdLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			pwdLabel.setHorizontalAlignment(SwingConstants.CENTER);
			pwdLabel.setText("����:");
			userNameLabel = new JLabel();
			userNameLabel.setBounds(new Rectangle(26, 80, 115, 30));
			userNameLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			userNameLabel.setHorizontalAlignment(SwingConstants.CENTER);
			userNameLabel.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			userNameLabel.setText("�û���:");
			adduserLabel = new JLabel();
			adduserLabel.setBounds(new Rectangle(16, 10, 324, 44));
			adduserLabel.setFont(new Font("Dialog", Font.BOLD, 24));
			adduserLabel.setHorizontalAlignment(SwingConstants.CENTER);
			adduserLabel.setText("�����û�");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(adduserLabel, null);
			jContentPane.add(userNameLabel, null);
			jContentPane.add(pwdLabel, null);
			jContentPane.add(nicknameLabel, null);
			jContentPane.add(moneyLabel, null);
			jContentPane.add(typeLabel, null);
			jContentPane.add(getUsernameTextField(), null);
			jContentPane.add(getPwdPasswordField(), null);
			jContentPane.add(getNicknameTextField(), null);
			jContentPane.add(getMoneyTextField(), null);
			jContentPane.add(getTypeComboBox(), null);
			jContentPane.add(getCancelButton(), null);
			jContentPane.add(getOkButton(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes usernameTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getUsernameTextField() {
		if (usernameTextField == null) {
			usernameTextField = new JTextField();
			usernameTextField.setBounds(new Rectangle(155, 80, 152, 30));
		}
		return usernameTextField;
	}

	/**
	 * This method initializes pwdPasswordField	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getPwdPasswordField() {
		if (pwdPasswordField == null) {
			pwdPasswordField = new JPasswordField();
			pwdPasswordField.setBounds(new Rectangle(155, 130, 152, 30));
		}
		return pwdPasswordField;
	}

	/**
	 * This method initializes nicknameTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getNicknameTextField() {
		if (nicknameTextField == null) {
			nicknameTextField = new JTextField();
			nicknameTextField.setBounds(new Rectangle(155, 180, 152, 30));
		}
		return nicknameTextField;
	}

	/**
	 * This method initializes moneyTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getMoneyTextField() {
		if (moneyTextField == null) {
			moneyTextField = new JTextField();
			moneyTextField.setBounds(new Rectangle(155, 230, 152, 30));
		}
		return moneyTextField;
	}

	/**
	 * This method initializes typeComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getTypeComboBox() {
		if (typeComboBox == null) {
			typeComboBox = new JComboBox();
			typeComboBox.addItem("��ͨ�û�");
			typeComboBox.addItem("����Ա");
			typeComboBox.setBounds(new Rectangle(155, 280, 152, 30));
		}
		return typeComboBox;
	}

	/**
	 * This method initializes cancelButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setBounds(new Rectangle(30, 340, 120, 35));
			cancelButton.setFont(new Font("Dialog", Font.BOLD, 18));
			cancelButton.setText("ȡ��");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					close();
				}
			});
		}
		return cancelButton;
	}

	/**
	 * This method initializes okButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setBounds(new Rectangle(177, 340, 120, 35));
			okButton.setFont(new Font("Dialog", Font.BOLD, 18));
			okButton.setText("����");
			okButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String tmp=typeComboBox.getSelectedItem()+"";
					int  type=0;
					User user=new User();
					user.setUserName(usernameTextField.getText());
					user.setPwd(pwdPasswordField.getText());
					user.setNickName(nicknameTextField.getText());
					String money=moneyTextField.getText();
					Pattern p = Pattern.compile("(^[0-9]{4})|(^[0-9]{3})|(^[0-9]{2})|(^[0-9]{1})");  
					Matcher m = p.matcher(money);  
					
					if(!user.getUserName().equals("")&&!user.getPwd().equals("")&&m.matches()==true){
						user.setMoney(Integer.parseInt(moneyTextField.getText()));
						if(tmp.equals("��ͨ�û�")){
							type=2;
						}else if(tmp.equals("����Ա")){
							type=1;
						}else{
							JOptionPane.showMessageDialog(null, "��û�и�����");
						}
						if(type==1){/*�� 0 ,�� 1,ȡ�� 2*/
							int judge=JOptionPane.showConfirmDialog(null, "��ȷ��Ҫ���ӹ���Ա�˻���?");
							if(judge==0){//��
								user.setType(type);
								addUser(user);
							}else{
								
							}
						}else if(type==2){
							user.setType(type);
							addUser(user);
						}
					}else if(user.getUserName().equals("")){
						JOptionPane.showMessageDialog(null, "��д�û���");
					}else if(user.getPwd().equals("")){
						JOptionPane.showMessageDialog(null, "���벻��Ϊ��");
					}else if(moneyTextField.getText().equals("")){
						JOptionPane.showMessageDialog(null, "�˻����Ϊ��");
					}else if(m.matches()==false){
						JOptionPane.showMessageDialog(null, "�˻�����������");
					}
					
				}
			});
		}
		return okButton;
	}
	
	private void addUser(User user){
		UserService us=new UserService();
		//�ж��û��Ƿ����
		boolean isOK=us.isRegister(user);
		if(isOK){
			JOptionPane.showMessageDialog(null, "����"+user.getUserName()+"�û��ɹ�");
		}else{
			JOptionPane.showMessageDialog(null, user.getUserName()+"�û��Ѿ�����,���޸��û�����������");
		}
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
