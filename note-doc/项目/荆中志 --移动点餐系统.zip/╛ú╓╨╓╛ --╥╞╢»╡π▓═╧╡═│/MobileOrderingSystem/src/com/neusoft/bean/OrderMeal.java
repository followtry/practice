/**
 * @author ����־
 * @time 2014-8-19 ����06:41:30
 * @func 
 * 
 */
package com.neusoft.bean;

import java.util.Date;

/**
 * @author new
 *
 */
public class OrderMeal {
	
	private int tid;
	private int mid;
	private int mnum;
	private Date date=new Date();
/*	insert into ordermeal(tid,mid,mnum,orderdate) 
	values(1,2,1,to_date('2014-8-23 12:23:23','yyyy-mm-dd HH:mi:ss'))*/
	
	/**
	 * @return the mid
	 */
	public int getMid() {
		return mid;
	}
	/**
	 * @param mid the mid to set
	 */
	public void setMid(int mid) {
		this.mid = mid;
	}
	/**
	 * @return the mnum
	 */
	public int getMnum() {
		return mnum;
	}
	/**
	 * @param mnum the mnum to set
	 */
	public void setMnum(int mnum) {
		this.mnum = mnum;
	}
	/**
	 * @return the tid
	 */
	public int getTid() {
		return tid;
	}
	/**
	 * @param tid the tid to set
	 */
	public void setTid(int tid) {
		this.tid = tid;
	}
	

}
/*orderMeal	��ͱ�
�ֶ�	����
tid	number(2)
mid	number(3)
mnum	number(1)
orderdate	date*/

