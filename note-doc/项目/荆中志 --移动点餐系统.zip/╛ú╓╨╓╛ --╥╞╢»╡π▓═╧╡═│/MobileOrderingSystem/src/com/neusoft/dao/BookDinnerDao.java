/**
 * @author ����־
 * @time 2014-8-19 ����07:02:05
 * @func �����¼��е�΢����
 * 
 */
package com.neusoft.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.neusoft.bean.Dining_table;
import com.neusoft.bean.Menu;
import com.neusoft.jdbc.DBConn;

/**
 * @author new
 *
 */
public class BookDinnerDao {
	
	private Connection conn;
	private DBConn db=new DBConn();
	
	public BookDinnerDao() {}
	
	public BookDinnerDao(Connection conn) {
		this.conn=conn;
	}
	
	/**
	 * @func ���\��� ��;�Ӳ�\�Ӿ�
	 * @param menu
	 * @param dt
	 * @param num
	 * @return int
	 * @throws SQLException
	 */
	public int addOrderForm_1(Menu menu,Dining_table dt) throws SQLException{
		int count=0;
		int mid=menu.getMid();
		int tid=dt.getTid();
		int stat=0;
		int num=menu.getMnum();
		db.connection(this.conn);
		
		
		//insert into ordermeal(tid,mid,mnum,orderdate,ostat)  values(?,?,?,sysdate)
		String sql="insert into ordermeal  values(?,?,?,sysdate,?)";

		Object obj[]={tid,mid,num,stat};
		count=db.executeUpdate(sql, obj);
		//db.close();
		return count;
	}
	
	
	
	/**
	 * @func ���\��� ��;�Ӳ�\�Ӿ�
	 * @param menu
	 * @param dt
	 * @param num
	 * @return int
	 * @throws SQLException
	 */
	public int addOrderForm(Menu menu,Dining_table dt) throws SQLException{
		int count=0;
		int mid=menu.getMid();
		int tid=dt.getTid();
		int stat=0;
		int num=menu.getMnum();
		db.connection(this.conn);
		//�Ȳ�ѯorderMeal�����Ƿ����������,û�о�������,�о�������1
		String  queryMenu="select * from ordermeal where tid=? and mid=?";
		Object queryObj[]={tid,mid};
		ResultSet rs=db.executeQuery(queryMenu, queryObj);
		if(rs.next()){
			String updateMenu="update ordermeal set mnum=mnum+? where tid=? and mid=?";
			Object updateObj[]={num,tid,mid};
			count=db.executeUpdate(updateMenu, updateObj);
		}else{
			//insert into ordermeal(tid,mid,mnum,orderdate,ostat)  values(?,?,?,sysdate)
			String sql="insert into ordermeal  values(?,?,?,sysdate,?)";

			Object obj[]={tid,mid,num,stat};
			count=db.executeUpdate(sql, obj);
		}
		return count;
	}
	

	
	/**
	 * @func ͨ���������Ҳ�
	 * @param name
	 * @return Menu
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public Menu browseMenuByName(String name) throws SQLException, ClassNotFoundException{
		Menu menu=new Menu();
		db.connection(this.conn);
		
		String sql="select * from menu where mname=?";
		Object obj[]={name};
		ResultSet rset=db.executeQuery(sql, obj);
		if(rset.next())
		{
			menu.setMid(rset.getInt("mid"));
			menu.setMname(rset.getString("mname"));
			menu.setMprice(rset.getInt("mprice"));
			menu.setMtype(rset.getInt("mtype"));
			menu.setMpic(rset.getString("mpic"));
			//System.out.println("name:"+menu.getMname());
		}
		System.out.println("OK----");
		//db.close();
		return menu;
	}
	
	/**
	 * @func ͨ���۸�Χ�������
	 * @param type
	 * @return List<Menu> 
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public List<Menu> browseMenuByPrice(int lowPrice,int highPrice) throws SQLException, ClassNotFoundException{
		List<Menu> menus=new ArrayList<Menu>();
		db.connection(this.conn);
		String sql="select * from menu where mprice between ? and ?";
		Object obj[]={lowPrice,highPrice};
		ResultSet rset=db.executeQuery(sql, obj);
		while(rset.next())
		{
			Menu menu=new Menu();
			menu.setMid(rset.getInt("mid"));
			menu.setMname(rset.getString("mname"));
			menu.setMprice(rset.getInt("mprice"));
			menu.setMtype(rset.getInt("mtype"));
			menu.setMpic(rset.getString("mpic"));
			menus.add(menu);
		}
		//db.close();
		return menus;
	}
	
	/**
	 * @func ͨ�������������
	 * @param type
	 * @return List<Menu> 
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public List<Menu> browseMenuByType(int type) throws SQLException, ClassNotFoundException{
		List<Menu> menus=new ArrayList<Menu>();
		db.connection(this.conn);
		String sql="select * from menu where mtype=?";
		Object obj[]={type};
		ResultSet rset=db.executeQuery(sql, obj);
		while(rset.next())
		{
			Menu menu=new Menu();
			menu.setMid(rset.getInt("mid"));
			menu.setMname(rset.getString("mname"));
			menu.setMprice(rset.getInt("mprice"));
			menu.setMtype(rset.getInt("mtype"));
			menu.setMpic(rset.getString("mpic"));
			menus.add(menu);
		}
		//db.close();
		return menus;
	}
	
	/**
	 * @func ����˵�
	 * @return List<Menu>
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public List<Menu> browseMenu() throws SQLException, ClassNotFoundException{
		List<Menu> menus=new ArrayList<Menu>();
		db.connection(this.conn);
		String sql="select * from menu order by mid";
		ResultSet rset=db.executeQuery(sql);
		while(rset.next()){
			Menu menu=new Menu();
			menu.setMid(rset.getInt("mid"));
			menu.setMname(rset.getString("mname"));
			menu.setMprice(rset.getInt("mprice"));
			menu.setMtype(rset.getInt("mtype"));
			menu.setMpic(rset.getString("mpic"));
			menus.add(menu);
		}
		//db.close();
		return menus;
	}
	/**
	 * @func ͨ�����Ų�������
	 * @param tid
	 * @return Dining_table
	 * @throws SQLException
	 */
	public Dining_table findTableByTid(int tid) throws SQLException{
		Dining_table dt=new Dining_table();
		db.connection(this.conn);
		String sql="select * from Dining_table where tid=?";
		Object obj[]={tid};
		ResultSet rset=db.executeQuery(sql, obj);
		if(rset.next()){
			dt.setTid(rset.getInt("tid"));
			dt.setPnum(rset.getInt("pnum"));
			dt.setTstate(rset.getInt("tstate"));
		}
		//db.close();
		return dt;
	}
	
	/**
	 * @func ���Ĳ�����״̬,����ռ����tstateΪ1,����ռ����tstateΪ0
	 * @param tid
	 * @param tstate
	 * @return int
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public int updateTableStat(int tid,int tstate ) throws ClassNotFoundException, SQLException{
		int count=0;
		db.connection(this.conn);
		String sql="update  dining_table set tstate=? where tid=? ";
		Object obj[]={tstate,tid};
		count = db.executeUpdate(sql,obj);
		//db.close();
		return count;
	}
	
	/**
	 * @func ������Ȼ���ŵĲ��������ż��������������
	 * @return List<Dining_table> 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public List<Dining_table> findEmptyTable() throws ClassNotFoundException, SQLException{
		List<Dining_table> tables=new ArrayList<Dining_table>();
		db.connection(this.conn);
		String sql="select tid,pnum,tstate " +
				" from dining_table where tstate=0";
		ResultSet rset=db.executeQuery(sql);
		while(rset.next()){
			Dining_table dt=new Dining_table();
			dt.setTid(rset.getInt("tid"));
			dt.setPnum(rset.getInt("pnum"));
			//System.out.println("tid :"+dt.getTid()+"\tpnum:"+dt.getPnum());
			tables.add(dt);
		}
		//db.close();
		return tables;
	}
	
	/**
	 * @func �����Ѿ���ռ�õĲ��������ż��������������
	 * @return List<Dining_table> 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public List<Dining_table> findOccupyTable() throws ClassNotFoundException, SQLException{
		List<Dining_table> tables=new ArrayList<Dining_table>();
		db.connection(this.conn);
		String sql="select tid,pnum,tstate " +
				" from dining_table where tstate=1";
		ResultSet rset=db.executeQuery(sql);
		while(rset.next()){
			Dining_table dt=new Dining_table();
			dt.setTid(rset.getInt("tid"));
			dt.setPnum(rset.getInt("pnum"));
			dt.setTstate(rset.getInt("tstate"));
			//System.out.println("tid :"+dt.getTid()+"\tpnum:"+dt.getPnum());
			tables.add(dt);
		}
		//db.close();
		return tables;
	}
	
	/**
	 * @func ���¶������е�ĳ���˵�����
	 * @param menu
	 * @param dt
	 * @param num
	 * @return
	 * @throws SQLException 
	 */
	public int updateOrderMenuNum(Menu menu,Dining_table dt,int num) throws SQLException{
		int count=0;
		db.connection(this.conn);
		int mid=menu.getMid();
		int tid=dt.getTid();
		String query="select * from ordermeal where tid=? and mid=?";
		Object objquery[]={tid,mid};
		ResultSet rs=db.executeQuery(query, objquery);
		int a=222;
		if(rs.next()){
			//System.out.println("----"+(a=rs.getInt("tid"))+"----");
			String sql="update ordermeal set mnum=mnum+? where tid=? and mid=?";
			Object obj[]={num,tid,mid};
			count=db.executeUpdate(sql, obj);
		}
		System.out.println("---111-"+count+"--111--");
		return count;
	}
	
	/**
	 * @func �����ѽ������˽��(�ͻ���ʹ��)
	 * @return
	 * @throws SQLException 
	 */
	public int alreadyCostMoney(int tid) throws SQLException{
		int cost=0;
		db.connection(this.conn);
		String sql="select sum(m.mprice*o.mnum) ������ from menu m " +
				"join ordermeal o on m.mid=o.mid " +
				"and o.tid=? and o.ostat=1 ";
		Object obj[]={tid};
		ResultSet rs=db.executeQuery(sql, obj);
		if(rs.next()){
			cost=rs.getInt("������");
		}
		return cost;
	}
	
	/**
	 * @func �����ѽ��
	 * @return
	 * @throws SQLException 
	 */
	public int notCostMoney(int tid) throws SQLException{
		int cost=0;
		db.connection(this.conn);
		String sql="select sum(m.mprice*o.mnum) ������ from menu m " +
				"join ordermeal o on m.mid=o.mid " +
				"and o.tid=? and o.ostat=0 ";
		Object obj[]={tid};
		ResultSet rs=db.executeQuery(sql, obj);
		if(rs.next()){
			cost=rs.getInt("������");
		}
		return cost;
	}
	
	/**
	 * @func �Ѿ����ѵ���Ʒ
	 * @param tid
	 * @return List<Menu>
	 * @throws SQLException
	 */
	public List<Menu> alreadyCostGoods(int tid) throws SQLException{
		List<Menu> menus=new ArrayList<Menu>();
		
		db.connection(this.conn);
		String sql="select m.mid �˱��,m.mname ����,m.mprice �˼�,m.mtype ����,o.mnum ���� from menu m " +
				"join ordermeal o on m.mid=o.mid and " +
				"o.tid=? and o.ostat=1 ";
		Object obj[]={tid};
		ResultSet rs=db.executeQuery(sql, obj);
		while(rs.next()){
			Menu  menu=new Menu();
			menu.setMid(rs.getInt("�˱��"));
			menu.setMname(rs.getString("����"));
			menu.setMprice(rs.getInt("�˼�"));
			menu.setMtype(rs.getInt("����"));
			menu.setMnum(rs.getInt("����"));
			
			menus.add(menu);
		}
		return menus;
	}
	
	/**
	 * @func �����ѵ���Ʒ
	 * @param tid
	 * @return List<Menu>
	 * @throws SQLException
	 */
	public List<Menu> notCostGoods(int tid) throws SQLException{
		List<Menu> menus=new ArrayList<Menu>();
		
		db.connection(this.conn);
		String sql="select m.mid �˱��,m.mname ����,m.mprice �˼�,m.mtype ���� ,o.mnum ���� from menu m " +
				"join ordermeal o on m.mid=o.mid and " +
				"o.tid=? and o.ostat=0 ";
		Object obj[]={tid};
		ResultSet rs=db.executeQuery(sql, obj);
		while(rs.next()){
			Menu  menu=new Menu();
			menu.setMid(rs.getInt("�˱��"));
			menu.setMname(rs.getString("����"));
			menu.setMprice(rs.getInt("�˼�"));
			menu.setMtype(rs.getInt("����"));
			menu.setMnum(rs.getInt("����"));
			menus.add(menu);
		}
		return menus;
	}
}