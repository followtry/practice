/**
 * @author ����־
 * @time 2014-8-21 ����11:28:50
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.BoxLayout;
import javax.swing.JToolBar;
import java.awt.Rectangle;

import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import com.neusoft.bean.Dining_table;
import com.neusoft.bean.Menu;
import com.neusoft.service.BookDinnerService;
import com.neusoft.service.ManageService;

import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;

/**
 * @author new
 *
 */
public class ContentPage extends JFrame {
	
	private DefaultTableModel dtalready=new DefaultTableModel();
	
	private DefaultTableModel dtNot=new DefaultTableModel();
	
	private int tid=0;
	
	private BookDinnerService bDS=new BookDinnerService();  //  @jve:decl-index=0:
	
	private String userName="";  //  @jve:decl-index=0:

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel currentLabel = null;

	private JLabel userNameLabel = null;

	private JLabel accountLabel = null;

	private JLabel moneyLabel = null;

	private JLabel unitLabel = null;

	private JLabel finishOrderLabel = null;

	private JLabel notServingLabel = null;

	private JScrollPane finishedScrollPane = null;

	private JTable finishedOrderTable = null;

	private JScrollPane notservingScrollPane = null;

	private JTable notServingTable = null;

	private JLabel costLabel = null;

	private JLabel costMoneyLabel = null;

	private JLabel unitaLabel = null;

	private JLabel notCostLabel = null;

	private JLabel notCostMoneyLabel = null;

	private JLabel unitbLabel = null;

	private JButton squareAccountsButton = null;

	private JButton backPlantButton = null;

	private JLabel currentTLabel = null;

	private JLabel cuTableLabel = null;

	private JLabel unitcLabel = null;

	private JButton addButton = null;

	private JButton flushButton = null;

	private JLabel allCostMoneyLabel = null;

	/**
	 * This is the default constructor
	 */
	public ContentPage() {
		super();
		initialize();
	}
	
	
	
	public ContentPage(String userName,int tid) {
		super();
		this.userName=userName;
		this.tid=tid;
		initialize();
		userNameLabel.setText(this.userName);
		cuTableLabel.setText(this.tid+"");
		int money=bDS.getUserMoney(this.userName);
		moneyLabel.setText(money+"");
		costMoneyLabel.setText(bDS.alreadyCostMoney(tid)+"");
		notCostMoneyLabel.setText(bDS.notCostMoney(tid)+"");
	}

	public void close(){
		this.setVisible(false);
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(810, 543);
		this.setContentPane(getJContentPane());
		this.setTitle("����");
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			allCostMoneyLabel = new JLabel();
			allCostMoneyLabel.setBounds(new Rectangle(653, 368, 139, 33));
			allCostMoneyLabel.setText("");
			unitcLabel = new JLabel();
			unitcLabel.setBounds(new Rectangle(713, 14, 37, 30));
			unitcLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			unitcLabel.setHorizontalAlignment(SwingConstants.LEFT);
			unitcLabel.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			unitcLabel.setText("��");
			cuTableLabel = new JLabel();
			cuTableLabel.setBounds(new Rectangle(668, 14, 45, 30));
			cuTableLabel.setText("");
			currentTLabel = new JLabel();
			currentTLabel.setBounds(new Rectangle(588, 14, 81, 30));
			currentTLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			currentTLabel.setHorizontalAlignment(SwingConstants.CENTER);
			currentTLabel.setText("��ǰ����:");
			unitbLabel = new JLabel();
			unitbLabel.setBounds(new Rectangle(559, 478, 43, 26));
			unitbLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			unitbLabel.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			unitbLabel.setText("Ԫ");
			notCostMoneyLabel = new JLabel();
			notCostMoneyLabel.setBounds(new Rectangle(476, 478, 84, 26));
			notCostMoneyLabel.setHorizontalAlignment(SwingConstants.CENTER);
			notCostMoneyLabel.setText("");
			notCostLabel = new JLabel();
			notCostLabel.setBounds(new Rectangle(352, 478, 124, 26));
			notCostLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			notCostLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			notCostLabel.setText("�����ѽ��:");
			unitaLabel = new JLabel();
			unitaLabel.setBounds(new Rectangle(232, 478, 40, 26));
			unitaLabel.setHorizontalAlignment(SwingConstants.LEFT);
			unitaLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			unitaLabel.setText("Ԫ");
			costMoneyLabel = new JLabel();
			costMoneyLabel.setBounds(new Rectangle(140, 478, 92, 26));
			costMoneyLabel.setHorizontalAlignment(SwingConstants.CENTER);
			costMoneyLabel.setText("");
			costLabel = new JLabel();
			costLabel.setBounds(new Rectangle(17, 478, 125, 26));
			costLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			costLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			costLabel.setText("�����ѽ��:");
			notServingLabel = new JLabel();
			notServingLabel.setBounds(new Rectangle(378, 74, 233, 40));
			notServingLabel.setFont(new Font("Dialog", Font.BOLD, 24));
			notServingLabel.setHorizontalAlignment(SwingConstants.CENTER);
			notServingLabel.setText("δ����");
			finishOrderLabel = new JLabel();
			finishOrderLabel.setBounds(new Rectangle(47, 74, 228, 40));
			finishOrderLabel.setHorizontalAlignment(SwingConstants.CENTER);
			finishOrderLabel.setFont(new Font("Dialog", Font.BOLD, 24));
			finishOrderLabel.setHorizontalTextPosition(SwingConstants.CENTER);
			finishOrderLabel.setText("������");
			unitLabel = new JLabel();
			unitLabel.setBounds(new Rectangle(452, 14, 34, 30));
			unitLabel.setText("Ԫ");
			moneyLabel = new JLabel();
			moneyLabel.setBounds(new Rectangle(408, 14, 45, 30));
			moneyLabel.setHorizontalAlignment(SwingConstants.CENTER);
			moneyLabel.setText("");
			accountLabel = new JLabel();
			accountLabel.setBounds(new Rectangle(327, 14, 81, 30));
			accountLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			accountLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			accountLabel.setText("�˻����:");
			userNameLabel = new JLabel();
			userNameLabel.setBounds(new Rectangle(84, 14, 98, 30));
			userNameLabel.setText("");
			currentLabel = new JLabel();
			currentLabel.setBounds(new Rectangle(15, 14, 69, 30));
			currentLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			currentLabel.setHorizontalAlignment(SwingConstants.CENTER);
			currentLabel.setText("��ǰ�û�:");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(currentLabel, null);
			jContentPane.add(userNameLabel, null);
			jContentPane.add(accountLabel, null);
			jContentPane.add(moneyLabel, null);
			jContentPane.add(unitLabel, null);
			jContentPane.add(finishOrderLabel, null);
			jContentPane.add(notServingLabel, null);
			jContentPane.add(getFinishedScrollPane(), null);
			jContentPane.add(getNotservingScrollPane(), null);
			jContentPane.add(costLabel, null);
			jContentPane.add(costMoneyLabel, null);
			jContentPane.add(unitaLabel, null);
			jContentPane.add(notCostLabel, null);
			jContentPane.add(notCostMoneyLabel, null);
			jContentPane.add(unitbLabel, null);
			jContentPane.add(getSquareAccountsButton(), null);
			jContentPane.add(getBackPlantButton(), null);
			jContentPane.add(currentTLabel, null);
			jContentPane.add(cuTableLabel, null);
			jContentPane.add(unitcLabel, null);
			jContentPane.add(getAddButton(), null);
			jContentPane.add(getFlushButton(), null);
			jContentPane.add(allCostMoneyLabel, null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes finishedScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getFinishedScrollPane() {
		if (finishedScrollPane == null) {
			finishedScrollPane = new JScrollPane();
			finishedScrollPane.setBounds(new Rectangle(13, 128, 299, 339));
			finishedScrollPane.setViewportView(getFinishedOrderTable());
		}
		return finishedScrollPane;
	}

	/**
	 * This method initializes finishedOrderTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getFinishedOrderTable() {
		BookDinnerService bDS=new BookDinnerService();
		List<Menu> menus=new ArrayList<Menu>();
		menus=bDS.alreadyCostGoods(this.tid);
		String[] cols = {"����","�˼�","����","����"};
		dtalready=new DefaultTableModel();
		dtalready.setColumnIdentifiers(cols);
		alreadyCost(menus);
		return finishedOrderTable;
	}
	
	/**
	 * @func ��������Ʒ
	 * @param menus
	 */
	private void alreadyCost(List<Menu> menus){
		
		
		if(finishedOrderTable!=null)
			finishedOrderTable.removeAll();
		Iterator<Menu> iter=menus.iterator();
		while(iter.hasNext()){
			Menu menu=new Menu();
			menu=iter.next();
			String type="";
			/*������(1,��Ʒ\2,���\3,�ز�\4,��ˮ\5\��\6��ʳ\7.����)*/
			switch(menu.getMtype()){
			case 1:type="��ʳ";break;
			case 2:type="���";break;
			case 3:type="�ز�";break;
			case 4:type="��ˮ";break;
			case 5:type="��";break;
			case 6:type="��ʳ";break;
			case 7:type="����";break;
			default:type="�޷���";break;
			}
			System.out.println("+++++++++++����:"+menu.getMname());
			//System.out.println(menu.getMname()+"\t"+menu.getMprice()+"\t"+menu.getMtype());
			//System.out.println(menu.getMid()+"\t"+menu.getMid()+"\t"+menu.getMname()+"\t"+menu.getMprice()+"\t"+type+"\t"+menu.getMpic());
			Object[] menuRow=new Object[]{menu.getMname(),
					menu.getMprice()+"",type,menu.getMnum()};
			dtalready.addRow(menuRow);
		}
		if (finishedOrderTable == null) {
			finishedOrderTable=new JTable();
			
			finishedOrderTable.setRowHeight(32);
		}
		finishedOrderTable.setModel(dtalready);
		finishedOrderTable.revalidate();
	}

	/**
	 * This method initializes notservingScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getNotservingScrollPane() {
		if (notservingScrollPane == null) {
			notservingScrollPane = new JScrollPane();
			notservingScrollPane.setBounds(new Rectangle(345, 128, 302, 338));
			notservingScrollPane.setViewportView(getNotServingTable());
		}
		return notservingScrollPane;
	}

	/**
	 * This method initializes notServingTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getNotServingTable() {
		
		BookDinnerService bDS=new BookDinnerService();
		List<Menu> menus=new ArrayList<Menu>();
		menus=bDS.notCostGoods(this.tid);
		notCost(menus);
		
		return notServingTable;
	}

	/**
	 * @func ��������Ʒ
	 * @param menus
	 */
	private void notCost(List<Menu> menus){

		String[] cols = {"����","�˼�","����","����"};
		dtNot=new DefaultTableModel();
		dtNot.setColumnIdentifiers(cols);
		if(notServingTable!=null)
			notServingTable.removeAll();
		Iterator<Menu> iter=menus.iterator();
		while(iter.hasNext()){
			Menu menu=new Menu();
			menu=iter.next();
			String type="";
			/*������(1,��Ʒ\2,���\3,�ز�\4,��ˮ\5\��\6��ʳ\7.����)*/
			switch(menu.getMtype()){
			case 1:type="��ʳ";break;
			case 2:type="���";break;
			case 3:type="�ز�";break;
			case 4:type="��ˮ";break;
			case 5:type="��";break;
			case 6:type="��ʳ";break;
			case 7:type="����";break;
			default:type="�޷���";break;
			}
			System.out.println("---------����:"+menu.getMname());
			//System.out.println(menu.getMname()+"\t"+menu.getMprice()+"\t"+menu.getMtype());
		//	System.out.println(menu.getMid()+"\t"+menu.getMid()+"\t"+menu.getMname()+"\t"+menu.getMprice()+"\t"+type+"\t"+menu.getMpic());
			Object[] menuRow=new Object[]{menu.getMname(),menu.getMprice()+"",type,menu.getMnum()};
			dtNot.addRow(menuRow);
		}
		if (notServingTable == null) {
			notServingTable=new JTable();
			
			notServingTable.setRowHeight(32);
		}
		notServingTable.setModel(dtNot);
		notServingTable.revalidate();
	}
	/**
	 * This method initializes squareAccountsButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getSquareAccountsButton() {
		if (squareAccountsButton == null) {
			squareAccountsButton = new JButton();
			squareAccountsButton.setBounds(new Rectangle(662, 140, 105, 39));
			squareAccountsButton.setFont(new Font("Dialog", Font.BOLD, 18));
			squareAccountsButton.setText("����");
			squareAccountsButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("----����--"); // TODO Auto-generated Event stub actionPerformed()
					int money=bDS.alreadyCostMoney(tid);
					
					allCostMoneyLabel.setText("���ܹ����� "+money+" Ԫ");
					JOptionPane.showMessageDialog(null, "���ܹ�����"+money+"Ԫ,�����뵽��̨!лл!!");
					System.out.println("----����--"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return squareAccountsButton;
	}

	/**
	 * This method initializes backPlantButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBackPlantButton() {
		if (backPlantButton == null) {
			backPlantButton = new JButton();
			backPlantButton.setBounds(new Rectangle(662, 205, 105, 39));
			backPlantButton.setFont(new Font("Dialog", Font.BOLD, 18));
			backPlantButton.setText("�˲�\\��");
			backPlantButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					ManageService ms=new ManageService();
					Dining_table dt=new Dining_table();
					int x=notServingTable.getSelectedRow();
					if(x!=-1){
						String menuName=notServingTable.getValueAt(notServingTable.getSelectedRow(), 0)+"";
						System.err.println("--menuName---:"+menuName);
						dt.setTid(tid);
						int a=ms.deleteOrderForm(menuName, dt);
						if(a>0){
							getNotServingTable();
							JOptionPane.showMessageDialog(null, "�˲ͳɹ�!");
							
						}else{
							JOptionPane.showMessageDialog(null, "�˲�ʧ��");
						}
					}else{
						JOptionPane.showMessageDialog(null, "����ûѡ��Ҫ�˵�ʳ����!");
					}
				}
			});
		}
		return backPlantButton;
	}

	/**
	 * This method initializes addButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getAddButton() {
		if (addButton == null) {
			addButton = new JButton();
			addButton.setBounds(new Rectangle(662, 270, 105, 39));
			addButton.setFont(new Font("Dialog", Font.BOLD, 18));
			addButton.setText("�Ӳ�");
		
			addButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					close();
				}
			});
		}
		return addButton;
	}



	/**
	 * This method initializes flushButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getFlushButton() {
		if (flushButton == null) {
			flushButton = new JButton();
			flushButton.setBounds(new Rectangle(655, 428, 82, 34));
			flushButton.setFont(new Font("Dialog", Font.BOLD, 18));
			flushButton.setText("ˢ��");
			flushButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
				
					getFinishedOrderTable();
					getNotServingTable();
				
					costMoneyLabel.setText(bDS.alreadyCostMoney(tid)+"");
					notCostMoneyLabel.setText(bDS.notCostMoney(tid)+"");
					
					
				}
			});
		}
		return flushButton;
	}

}  //  @jve:decl-index=0:visual-constraint="-113,55"
