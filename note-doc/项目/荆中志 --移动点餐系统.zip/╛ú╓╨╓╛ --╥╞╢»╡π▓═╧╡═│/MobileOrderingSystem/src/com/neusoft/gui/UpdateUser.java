/**
 * @author ����־
 * @time 2014-8-23 ����11:22:06
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;

import com.neusoft.bean.User;
import com.neusoft.service.UserService;

import java.awt.event.KeyEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author new
 *
 */
public class UpdateUser extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel updateLabel = null;

	private JLabel usernameLabel = null;

	private JLabel newPwdLabel = null;

	private JLabel userNameLabel = null;

	private JPasswordField newPasswordField = null;

	private JLabel confirmLabel = null;

	private JPasswordField confirmPasswordField = null;

	private JButton cancelButton = null;

	private JButton okButton = null;
	
	private String userName="";  //  @jve:decl-index=0:
	private String manageName="";  //  @jve:decl-index=0:

	/**
	 * This is the default constructor
	 */
	public UpdateUser() {
		super();
		initialize();
	}
	
	public UpdateUser(String userName,String manageName) {
		super();
		this.userName=userName;
		this.manageName=manageName;
		initialize();
		initUserInfo();
	}
	
	private void close(){
		this.setVisible(false);
	}
	
	private void initUserInfo(){
		UserService us=new UserService();
		User user=new User();
		user=us.getUserInfo(this.userName);
		userNameLabel.setText(user.getUserName());
		
		
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(342, 322);
		this.setContentPane(getJContentPane());
		this.setTitle("�޸��û�");
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			confirmLabel = new JLabel();
			confirmLabel.setBounds(new Rectangle(14, 181, 144, 34));
			confirmLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			confirmLabel.setHorizontalAlignment(SwingConstants.CENTER);
			confirmLabel.setText("ȷ��������:");
			userNameLabel = new JLabel();
			userNameLabel.setBounds(new Rectangle(166, 80, 149, 34));
			userNameLabel.setText("");
			newPwdLabel = new JLabel();
			newPwdLabel.setBounds(new Rectangle(14, 131, 144, 34));
			newPwdLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			newPwdLabel.setHorizontalAlignment(SwingConstants.CENTER);
			newPwdLabel.setText("������:");
			usernameLabel = new JLabel();
			usernameLabel.setBounds(new Rectangle(14, 80, 144, 34));
			usernameLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			usernameLabel.setHorizontalAlignment(SwingConstants.CENTER);
			usernameLabel.setText("�û���:");
			updateLabel = new JLabel();
			updateLabel.setBounds(new Rectangle(22, 16, 302, 38));
			updateLabel.setFont(new Font("Dialog", Font.BOLD, 24));
			updateLabel.setHorizontalAlignment(SwingConstants.CENTER);
			updateLabel.setText("�޸��û�����");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(updateLabel, null);
			jContentPane.add(usernameLabel, null);
			jContentPane.add(newPwdLabel, null);
			jContentPane.add(userNameLabel, null);
			jContentPane.add(getNewPasswordField(), null);
			jContentPane.add(confirmLabel, null);
			jContentPane.add(getConfirmPasswordField(), null);
			jContentPane.add(getCancelButton(), null);
			jContentPane.add(getOkButton(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes newPasswordField	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getNewPasswordField() {
		if (newPasswordField == null) {
			newPasswordField = new JPasswordField();
			newPasswordField.setBounds(new Rectangle(166, 131, 149, 34));
		}
		return newPasswordField;
	}

	/**
	 * This method initializes confirmPasswordField	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getConfirmPasswordField() {
		if (confirmPasswordField == null) {
			confirmPasswordField = new JPasswordField();
			confirmPasswordField.setBounds(new Rectangle(166, 181, 149, 34));
		}
		return confirmPasswordField;
	}

	/**
	 * This method initializes cancelButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setBounds(new Rectangle(30, 233, 113, 42));
			cancelButton.setText("ȡ��");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					close();
				}
			});
		}
		return cancelButton;
	}

	/**
	 * This method initializes okButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setBounds(new Rectangle(188, 235, 109, 39));
			okButton.setText("ȷ��");
			okButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					UserService us=new UserService();
					User user=new User();
					String pwd=newPasswordField.getText();
					String pwdc=confirmPasswordField.getText();
					int type=us.getUserType(manageName);
					//JOptionPane.showMessageDialog(null, "type="+type);
					if(type==3&&!pwd.equals("")&&pwd.equals(pwdc)){
						user.setUserName(userName);
						user.setPwd(pwd);
						boolean isok=us.updateUser(user);
						if(isok){
							JOptionPane.showMessageDialog(null, "�����û���Ϣ�ɹ�");
						}else{
							JOptionPane.showMessageDialog(null, "�����û���Ϣʧ��");
						}
					
					}else if(type!=3){
						JOptionPane.showMessageDialog(null, "�㲻�ǳ�������Ա,û��Ȩ���޸��û�����!");
					}else{
						JOptionPane.showMessageDialog(null, "�����������벻һ��");
					}
				}
			});
		}
		return okButton;
	}

}  //  @jve:decl-index=0:visual-constraint="285,23"
