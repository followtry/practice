/**
 * @author ����־
 * @time 2014-8-23 ����10:18:28
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.neusoft.bean.User;
import com.neusoft.service.UserService;

/**
 * @author new
 *
 */
public class UserManage extends JFrame {
	
	private UserService us=new UserService();  //  @jve:decl-index=0:
	
	private DefaultTableModel dt=new DefaultTableModel();

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel userManageLabel = null;

	private JLabel userListLabel = null;

	private JScrollPane jScrollPane = null;

	private JTable userTable = null;

	private JButton updateButton = null;

	private JButton deleteButton = null;

	private JButton addButton = null;

	private JButton exitButton = null;

	private JButton flushButton = null;

	private JButton updateMoneyButton = null;
	
	private String manageName="";

	/**
	 * This is the default constructor
	 */
	public UserManage() {
		super();
		initialize();
	}
	
	public UserManage(String manageName) {
		super();
		this.manageName=manageName;
		initialize();
	}
	private void close(){
		this.setVisible(false);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(609, 597);
		this.setContentPane(getJContentPane());
		this.setTitle("�û�����");
		this.setResizable(false);
		this.setVisible(true);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			userListLabel = new JLabel();
			userListLabel.setBounds(new Rectangle(28, 84, 138, 26));
			userListLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			userListLabel.setText("�û��б�:");
			userManageLabel = new JLabel();
			userManageLabel.setBounds(new Rectangle(26, 15, 548, 60));
			userManageLabel.setFont(new Font("Dialog", Font.BOLD, 24));
			userManageLabel.setHorizontalAlignment(SwingConstants.CENTER);
			userManageLabel.setText("�û���Ϣ����");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(userManageLabel, null);
			jContentPane.add(userListLabel, null);
			jContentPane.add(getJScrollPane(), null);
			jContentPane.add(getUpdateButton(), null);
			jContentPane.add(getDeleteButton(), null);
			jContentPane.add(getAddButton(), null);
			jContentPane.add(getExitButton(), null);
			jContentPane.add(getFlushButton(), null);
			jContentPane.add(getUpdateMoneyButton(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(26, 113, 438, 438));
			jScrollPane.setViewportView(getUserTable());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes userTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getUserTable() {
		getAllUserInfo();
		if (userTable == null) {
			userTable = new JTable(dt);
			userTable.setRowHeight(24);
		}
		
		
		return userTable;
	}
	
	private void getAllUserInfo(){
		String cols[]={"���","�û���","�ǳ�","����","���"};
		List<User> users=new ArrayList<User>();
		UserService us =new UserService();
		
		users=us.getAllUserInfo();
		System.err.println("------------getAllUserInfo----------------");
		dt=new DefaultTableModel();
		dt.setColumnIdentifiers(cols);
		Iterator<User> iter=users.iterator();
		String type="";
		while(iter.hasNext()){
			User user=new User();
			user=iter.next();
			if(user.getType()==1){ type="����Ա"; }
			else if(user.getType()==3){ type="��������Ա"; }
			else if(user.getType()==2) {  type="��ͨ�û�"; }
			Object [] newRow={user.getId()+"",user.getUserName(),
					user.getNickName(),type,user.getMoney()+""};
			
			dt.addRow(newRow);
		}
		if (userTable == null) {
			userTable = new JTable(dt);
			userTable.setRowHeight(24);
		}
		userTable.setModel(dt);
		userTable.revalidate();
		
	}
	

	/**
	 * This method initializes updateButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getUpdateButton() {
		if (updateButton == null) {
			updateButton = new JButton();
			updateButton.setBounds(new Rectangle(483, 117, 102, 35));
			updateButton.setText("�޸��û�");
			updateButton.addActionListener(new java.awt.event.ActionListener() {   
				public void actionPerformed(java.awt.event.ActionEvent e) {   
					int x=userTable.getSelectedRow();
					if(x!=-1){
						String userName=userTable.getValueAt(x, 1)+"";
						System.out.println("userName="+userName);
						UpdateUser uu=new UpdateUser(userName,manageName);
						uu.setLocation(400, 200);
						uu.setVisible(true);
					}else{
						JOptionPane.showMessageDialog(null, "��δѡ���û�,���ҵ�!");
					}
					
					
					
				}
			
			});
		}
		return updateButton;
	}

	/**
	 * This method initializes deleteButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getDeleteButton() {
		if (deleteButton == null) {
			deleteButton = new JButton();
			deleteButton.setBounds(new Rectangle(483, 229, 103, 34));
			deleteButton.setText("ɾ���û�");
			deleteButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int x=userTable.getSelectedRow();
					int y=userTable.getSelectedColumn();
					int type=0;
					type=us.getUserType(manageName);
					if(type==3&&x!=-1&&y!=-1){
						String userName=userTable.getValueAt(x, 1)+"";
						User user=new User();
						user.setUserName(userName);
						UserService us=new UserService();
						us.deleteUser(user);
						getUserTable();
					}else if(type!=3){
						JOptionPane.showMessageDialog(null, "�����ǳ�������Ա,û��ɾ��Ȩ��!");
					}else{
						JOptionPane.showMessageDialog(null, "��δѡ���û�,���ҵ�!");
					}
					
				}
			});
		}
		return deleteButton;
	}

	/**
	 * This method initializes addButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getAddButton() {
		if (addButton == null) {
			addButton = new JButton();
			addButton.setBounds(new Rectangle(484, 179, 99, 34));
			addButton.setText("�����û�");
			addButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					AddUser au=new AddUser();
					au.setLocation(400, 200);
					au.setVisible(true);
				}
			});
		}
		return addButton;
	}

	/**
	 * This method initializes exitButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getExitButton() {
		if (exitButton == null) {
			exitButton = new JButton();
			exitButton.setBounds(new Rectangle(482, 342, 104, 35));
			exitButton.setText("�˳�");
			exitButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					close();
				}
			});
		}
		return exitButton;
	}

	/**
	 * This method initializes flushButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getFlushButton() {
		if (flushButton == null) {
			flushButton = new JButton();
			flushButton.setBounds(new Rectangle(367, 81, 85, 29));
			flushButton.setText("ˢ��");
			flushButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					getUserTable();
				}
			});
		}
		return flushButton;
	}

	/**
	 * This method initializes updateMoneyButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getUpdateMoneyButton() {
		if (updateMoneyButton == null) {
			updateMoneyButton = new JButton();
			updateMoneyButton.setBounds(new Rectangle(482, 284, 104, 35));
			updateMoneyButton.setText("�˻���ֵ");
			updateMoneyButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int x=userTable.getSelectedRow();
					int y=userTable.getSelectedColumn();
					if(x!=-1&&y!=-1){
						String userName=userTable.getValueAt(x, 1)+"";
						String pwd=JOptionPane.showInputDialog(null, "�������û�����:");
						//JOptionPane.showMessageDialog(null, userName+":"+pwd);
						if(us.isLogin(userName, pwd)){
							//�޸��˻����
							String addMoney=JOptionPane.showInputDialog(null, "������"+userName+"�û����ӵĽ��");
							Pattern p = Pattern.compile("(^[0-9]{3})|(^[0-9]{2})|(^[0-9]{1})");  
							Matcher m = p.matcher(addMoney);
							if(m.matches()==true){
								User user=new User();
								user.setUserName(userName);
								user.setMoney(Integer.parseInt(addMoney));
								UserService us=new UserService();
								if(us.updateMoney(user)){
									JOptionPane.showMessageDialog(null, "�ѳɹ���ֵ!");
								}else{
									JOptionPane.showMessageDialog(null, "��ֵʧ��!");
								}
								
							}else{
								JOptionPane.showMessageDialog(null, "����ȷ������!");
							}
						}else{
							JOptionPane.showMessageDialog(null, "�������벻��ȷ������Υ�����!�Ѿ�����¼");
						}
						
						/*String userName=userTable.getValueAt(x, 1)+"";
						User user=new User();
						user.setUserName(userName);
						UserService us=new UserService();
						us.deleteUser(user);*/
						getUserTable();
					}else{
						JOptionPane.showMessageDialog(null, "��δѡ���û�,���ҵ�!");
					}
				}
			});
		}
		return updateMoneyButton;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
