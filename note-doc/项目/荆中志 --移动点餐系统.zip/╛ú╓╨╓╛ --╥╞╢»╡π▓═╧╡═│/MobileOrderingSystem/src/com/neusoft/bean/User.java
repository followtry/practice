/**
 * @time  2014-8-18 ����06:04:53
 * @author new
 * @function users���е��ֶ�ӳ��ʵ����
 * @����  10.25.117.10
 * 
 */
package com.neusoft.bean;

/**
 * 
 */
public class User {
	private int id;
	private String userName;
	private String pwd;
	private String nickName;
	private int money;
	private int type;
	/**
	 * @return the type
	 */
	public int getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}
	public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return this.userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPwd() {
		return this.pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getNickName() {
		return this.nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public int getMoney() {
		return this.money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	
}
