/**
 * @author ����־
 * @time 2014-8-19 ����06:37:15
 * @func menu����ʵ����ӳ��
 * 
 */
package com.neusoft.bean;

/**
 * @author new
 *
 */
public class Menu {
	private int mid;
	private String mname;
	private int mprice;
	private int mtype;
	private int mnum;
	private String mpic;
	
	/**
	 * @return the mnum
	 */
	public int getMnum() {
		return mnum;
	}
	/**
	 * @param mnum the mnum to set
	 */
	public void setMnum(int mnum) {
		this.mnum = mnum;
	}
	/**
	 * @return the mid
	 */
	public int getMid() {
		return mid;
	}
	/**
	 * @param mid the mid to set
	 */
	public void setMid(int mid) {
		this.mid = mid;
	}
	/**
	 * @return the mname
	 */
	public String getMname() {
		return mname;
	}
	/**
	 * @param mname the mname to set
	 */
	public void setMname(String mname) {
		this.mname = mname;
	}
	/**
	 * @return the mpic
	 */
	public String getMpic() {
		return mpic;
	}
	/**
	 * @param mpic the mpic to set
	 */
	public void setMpic(String mpic) {
		this.mpic = mpic;
	}
	/**
	 * @return the mprice
	 */
	public int getMprice() {
		return mprice;
	}
	/**
	 * @param mprice the mprice to set
	 */
	public void setMprice(int mprice) {
		this.mprice = mprice;
	}
	/**
	 * @return the mtype
	 */
	public int getMtype() {
		return mtype;
	}
	/**
	 * @param mtype the mtype to set
	 */
	public void setMtype(int mtype) {
		this.mtype = mtype;
	}
}

/*menu	�˵�������
�ֶ�	����
mid	number(3)
mname	varchar(30)
mprice	number(3)
mtype	number(2)
mpic	varchar(100)
*/