/**
 * @author ����־
 * @time 2014-8-20 ����04:22:22
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.neusoft.service.UserService;

/**
 * @author new
 *
 */
public class Login extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel logo = null;

	private JLabel userLabel = null;

	private JLabel pwdLabel = null;

	private JTextField userName = null;

	private JPasswordField password = null;

	private JLabel forgetPwd = null;

	private JCheckBox keepPwd = null;

	private JCheckBox autoLogin = null;

	private JButton login = null;

	private JButton reset = null;

	/**
	 * This is the default constructor
	 */
	public Login() {
		super();
		initialize();
	}

	public void close(){
		this.setVisible(false);
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(400, 600);
		this.setLocation(new Point(400, 300));
		this.setResizable(false);
		this.setContentPane(getJContentPane());
		this.setTitle("�û���¼");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			forgetPwd = new JLabel();
			forgetPwd.setBounds(new Rectangle(283, 329, 101, 26));
			forgetPwd.setFont(new Font("Dialog", Font.BOLD, 16));
			forgetPwd.setHorizontalAlignment(SwingConstants.CENTER);
			forgetPwd.setText("��������?");
			forgetPwd.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					JOptionPane.showMessageDialog(null, "�����������ȥ�ҾƵ��̨��Ա��������,�ǵô�����֤Ŷ!!^_^");
				}
			});
			pwdLabel = new JLabel();
			pwdLabel.setBounds(new Rectangle(22, 328, 74, 27));
			pwdLabel.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			pwdLabel.setHorizontalAlignment(SwingConstants.CENTER);
			pwdLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			pwdLabel.setText("����:");
			userLabel = new JLabel();
			userLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			userLabel.setHorizontalAlignment(SwingConstants.CENTER);
			userLabel.setLocation(new Point(22, 278));
			userLabel.setSize(new Dimension(74, 27));
			userLabel.setText("�û���:");
			logo = new JLabel();
			logo.setBounds(new Rectangle(12, 14, 368, 210));
			logo.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			logo.setIcon(new ImageIcon(getClass().getResource("/image/logo.jpg")));
			logo.setText("logoͼƬ");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(logo, null);
			jContentPane.add(userLabel, null);
			jContentPane.add(pwdLabel, null);
			jContentPane.add(getUserName(), null);
			jContentPane.add(getPassword(), null);
			jContentPane.add(forgetPwd, null);
			jContentPane.add(getKeepPwd(), null);
			jContentPane.add(getAutoLogin(), null);
			jContentPane.add(getLogin(), null);
			jContentPane.add(getReset(), null);
			
			userName.setText("jing");
			password.setText("123");
		}
		return jContentPane;
	}
	/**
	 * This method initializes userName	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getUserName() {
		if (userName == null) {
			userName = new JTextField();
			userName.setLocation(new Point(96, 278));
			userName.setSize(new Dimension(174, 27));
		}
		return userName;
	}

	/**
	 * This method initializes password	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getPassword() {
		if (password == null) {
			password = new JPasswordField();
			password.setSize(new Dimension(174, 27));
			password.setLocation(new Point(96, 328));
		}
		return password;
	}

	/**
	 * This method initializes keepPwd	
	 * 	
	 * @return javax.swing.JCheckBox	
	 */
	private JCheckBox getKeepPwd() {
		if (keepPwd == null) {
			keepPwd = new JCheckBox();
			keepPwd.setBounds(new Rectangle(32, 398, 100, 29));
			keepPwd.setHorizontalAlignment(SwingConstants.CENTER);
			keepPwd.setFont(new Font("Dialog", Font.BOLD, 14));
			keepPwd.setSelected(true);
			keepPwd.setText("��ס����");
		}
		return keepPwd;
	}
	/**
	 * This method initializes autoLogin	
	 * 	
	 * @return javax.swing.JCheckBox	
	 */
	private JCheckBox getAutoLogin() {
		if (autoLogin == null) {
			autoLogin = new JCheckBox();
			autoLogin.setBounds(new Rectangle(154, 398, 100, 26));
			autoLogin.setHorizontalAlignment(SwingConstants.CENTER);
			autoLogin.setFont(new Font("Dialog", Font.BOLD, 14));
			autoLogin.setText("�Զ���¼");
		}
		return autoLogin;
	}

	/**
	 * This method initializes login	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getLogin() {
		if (login == null) {
			login = new JButton();
			login.setBounds(new Rectangle(28, 445, 132, 38));
			login.setText("��¼");
			login.setFont(new Font("Dialog", Font.BOLD, 18));
			login.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					String user=userName.getText();
					String pwd=password.getText();
					System.out.println("user:"+user+"\tpwd:"+pwd);
					UserService us=new UserService();
					int type=us.getUserType(user);
					if(us.isLogin(user, pwd)&&type==2){
						
						FirstPage_1 fp=new FirstPage_1(user);
						int w = (Toolkit.getDefaultToolkit().getScreenSize().width-login.WIDTH)/5;
						int h = (Toolkit.getDefaultToolkit().getScreenSize().height-login.HEIGHT)/5;
						
						fp.setLocation(w, h);
						fp.setVisible(true);
						close();
						System.out.println("��¼�ɹ�");
					}else if(us.isLogin(user, pwd)&&(type==1||type==3)){
						Manage manage=new Manage(user);
						int w = (Toolkit.getDefaultToolkit().getScreenSize().width-login.WIDTH)/6;
						int h = (Toolkit.getDefaultToolkit().getScreenSize().height-login.HEIGHT)/5;
						manage.setLocation(20, h);
						manage.setVisible(true);
						close();
						System.out.println("����Ա��¼�ɹ�");
						
					}else{
						JOptionPane.showMessageDialog(null,	"�û������������!");
						System.out.println("��¼ʧ��");
					}
					
				}
			});
			
		}
		return login;
	}

	/**
	 * This method initializes reset	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getReset() {
		if (reset == null) {
			reset = new JButton();
			reset.setBounds(new Rectangle(190, 445, 132, 38));
			reset.setFont(new Font("Dialog", Font.BOLD, 18));
			reset.setText("����");
			reset.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					userName.setText("");
					password.setText("");
				}
			});
		}
		return reset;
	}

}
