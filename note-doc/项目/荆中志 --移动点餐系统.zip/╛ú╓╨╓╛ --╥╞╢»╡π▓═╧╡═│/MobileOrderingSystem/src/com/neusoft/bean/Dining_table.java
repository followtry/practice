/**
 * @author ����־
 * @time 2014-8-19 ����06:39:30
 * @func  Dining_table����ʵ�����ϵӳ��
 * 
 */
package com.neusoft.bean;

/**
 * @author new
 *
 */
public class Dining_table {
	private int tid;
	private int pnum;
	private int tstate;
	/**
	 * @return the pnum
	 */
	public int getPnum() {
		return pnum;
	}
	/**
	 * @param pnum the pnum to set
	 */
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	/**
	 * @return the tid
	 */
	public int getTid() {
		return tid;
	}
	/**
	 * @param tid the tid to set
	 */
	public void setTid(int tid) {
		this.tid = tid;
	}
	/**
	 * @return the tstate
	 */
	public int getTstate() {
		return tstate;
	}
	/**
	 * @param tstate the tstate to set
	 */
	public void setTstate(int tstate) {
		this.tstate = tstate;
	}
	
}
/*dining_table	������
�ֶ�	����
tid	number(2)
pnum	number(2)
tstate	number(1)
*/

