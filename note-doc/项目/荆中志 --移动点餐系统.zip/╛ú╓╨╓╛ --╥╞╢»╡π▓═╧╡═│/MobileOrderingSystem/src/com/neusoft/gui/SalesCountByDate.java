package com.neusoft.gui;



import java.awt.Frame;
import javax.swing.JLabel;
import java.awt.Rectangle;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.neusoft.bean.Menu;
import com.neusoft.service.BookDinnerService;
import com.neusoft.service.ManageService;
import com.neusoft.service.Wnl;
import java.awt.Dimension;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/*import com.neusoft.bean.Diskorder;
import com.neusoft.bean.Menu;
import com.neusoft.bean.TotalView;
import com.neusoft.bean.Wnl;
import com.neusoft.service.MenuManagerService;
import com.neusoft.service.TotalViewService;
*/
public class SalesCountByDate extends Frame {
	
	private String dday="";  //  @jve:decl-index=0:
	
	//��Ϊfalseʱ��ʾ���ǰ��²�ѯ,��Ϊtrueʱ��ʾ���ǰ��ղ�ѯ
	private boolean flag=false;
	
	private DefaultTableModel dtMonth=null;

	private DefaultTableModel dt=null;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JComboBox years = null;
	private JComboBox months = null;
	private JLabel jLabel1 = null;
	private JScrollPane jScrollPane = null;
	private JTable jTable = null;
	private JButton jButton2 = null;
	private JButton queryButton3 = null;
	private JLabel salesNumLabel2 = null;
	private JLabel dateLabel2 = null;
	private JLabel salesMoneyLabel2 = null;
	private JScrollPane jScrollPane1 = null;
	private JTable eachTypeSalesTable1 = null;

	private JButton exitButton = null;
	/**
	 * This is the default constructor
	 */
	public SalesCountByDate() {
		super();
		initialize();
	}
	
	private void close(){
		this.setVisible(false);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		salesMoneyLabel2 = new JLabel();
		salesMoneyLabel2.setBounds(new Rectangle(279, 310, 253, 33));
		salesMoneyLabel2.setFont(new Font("Dialog", Font.BOLD, 18));
		salesMoneyLabel2.setText("�����ܶ�:");
		dateLabel2 = new JLabel();
		dateLabel2.setBounds(new Rectangle(25, 307, 249, 34));
		dateLabel2.setFont(new Font("Dialog", Font.BOLD, 18));
		dateLabel2.setText("��ʾ����:");
		salesNumLabel2 = new JLabel();
		salesNumLabel2.setBounds(new Rectangle(71, 254, 382, 46));
		salesNumLabel2.setHorizontalAlignment(SwingConstants.CENTER);
		salesNumLabel2.setFont(new Font("Dialog", Font.BOLD, 18));
		salesNumLabel2.setText("���۶�ͳ��");
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(219, 40, 38, 22));
		jLabel1.setText("��");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(108, 39, 30, 25));
		jLabel.setText("��");
		this.setLayout(null);
		this.setSize(597, 788);
		this.setTitle("Ӫҵ��ͳ��");
		this.setResizable(false);

		this.add(jLabel, null);
		this.add(getYears(), null);
		this.add(getMonths(), null);
		this.add(jLabel1, null);
		this.add(getJScrollPane(), null);
		this.add(getJButton2(), null);
		this.add(getQueryButton3(), null);
		this.add(salesNumLabel2, null);
		this.add(dateLabel2, null);
		this.add(salesMoneyLabel2, null);
		this.add(getJScrollPane1(), null);
		this.add(getExitButton(), null);
		/*this.add(getJButton3(), null);*/
	}

	/**
	 * This method initializes years	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getYears() {
		if (years == null) {
			years = new JComboBox();
			for(int i=1998;i<2022;i++)
			years.addItem(i+"");
			years.setSelectedItem(2014+"");
			years.setBounds(new Rectangle(29, 39, 77, 27));
		}
		return years;
	}

	/**
	 * This method initializes months	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getMonths() {
		if (months == null) {
			months = new JComboBox();
			for(int i=1;i<13;i++)
			months.addItem(i+"");
			months.setSelectedItem(8+"");
			months.setBounds(new Rectangle(138, 40, 80, 23));
			months.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int mymonth=Integer.parseInt(months.getSelectedItem()+"");
					int myyears=Integer.parseInt(years.getSelectedItem()+"");
//					���ԭ��
					
					for(int i=dt.getRowCount()-1;i>=0;i--){
						dt.removeRow(i);
					}
					Wnl wnl=new Wnl();
					String yue[][]=wnl.showCalendarOfMonth(myyears,mymonth);
					for(int i=0;i<yue.length;i++){
						if(i>0&&yue[i][0]==null){
							//System.out.println("����");
							break;
						}
						dt.addRow(new String[]{yue[i][0],yue[i][1],yue[i][2],yue[i][3],yue[i][4],yue[i][5],yue[i][6]});
						//dt.addRow(new String[]{m.getMname(),m.getMtype(),Integer.toString(m.getMprice()),Integer.toString(m.getMnum())});
					}
					
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return months;
	}

	/**
	 * This method initializes jTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getJTable() {
		
		String[] cols = {"��","һ","��","��","��","��","��"};
		String[][] rows ={};
//		MenuManagerService service=new MenuManagerService();
//		List menuList=service.finaAll();
		Wnl wnl=new Wnl();
		String yue[][]=wnl.showCalendarOfMonth(2013,10);
	//	DefaultTableModel dt = new DefaultTableModel(rows,cols);
		dt = new DefaultTableModel(rows,cols);
		for(int i=0;i<yue.length;i++)
			dt.addRow(new String[]{yue[i][0],yue[i][1],yue[i][2],yue[i][3],yue[i][4],yue[i][5],yue[i][6]});
			//dt.addRow(new String[]{m.getMname(),m.getMtype(),Integer.toString(m.getMprice()),Integer.toString(m.getMnum())});
//		
		
		if (jTable == null) {
		}
		return jTable;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(21, 72, 555, 165));
			jScrollPane.setViewportView(getJTable2());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes jTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getJTable2() {
		String[] cols = {"��","һ","��","��","��","��","��"};
		String[][] rows ={};
//		MenuManagerService service=new MenuManagerService();
//		List menuList=service.finaAll();
		Wnl wnl=new Wnl();
		String yue[][]=wnl.showCalendarOfMonth(2014,8);
	//	DefaultTableModel dt = new DefaultTableModel(rows,cols);
		dt = new DefaultTableModel(rows,cols);
		for(int i=0;i<yue.length;i++){
			if(i>0&&yue[i][0]==null){
				//System.out.println("����");
				break;
			}
			dt.addRow(new String[]{yue[i][0],yue[i][1],yue[i][2],yue[i][3],yue[i][4],yue[i][5],yue[i][6]});
			//dt.addRow(new String[]{m.getMname(),m.getMtype(),Integer.toString(m.getMprice()),Integer.toString(m.getMnum())});
		}
		if (jTable == null) {
			jTable = new JTable(dt);
			jTable.setRowHeight(22);
		}
		return jTable;
	}

	

	/**
	 * This method initializes jButton2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton2() {
		if (jButton2 == null) {
			jButton2 = new JButton();
			jButton2.setBounds(new Rectangle(467, 279, 105, 28));
			jButton2.setText("��ѯ(����)");
			jButton2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					//���Ӳ�����������
					flag=false;
					getEachTypeSalesTable1();
				}
			});
		}
		return jButton2;
	}

	/**
	 * This method initializes queryButton3	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getQueryButton3() {
		if (queryButton3 == null) {
			queryButton3 = new JButton();
			queryButton3.setBounds(new Rectangle(468, 244, 104, 30));
			queryButton3.setText("��ѯ(����)");
			queryButton3.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					ManageService ms=new ManageService();
					
					System.out.println("----jTable.getSelectedRow()--!!!"+jTable.getSelectedRow());
					System.out.println("----jTable.getSelectedcol()--!!!"+jTable.getSelectedColumn());
					int x=jTable.getSelectedRow();
					int y=jTable.getSelectedColumn();
					
					if(x==-1||y==-1){
						JOptionPane.showMessageDialog(null, "��ֻѡ�������,��ûѡ����");
						
					}else{
						dday=jTable.getValueAt(jTable.getSelectedRow(), jTable.getSelectedColumn())+"";
						System.out.println("dday:"+dday);
						if(dday.equals("null")){
							JOptionPane.showMessageDialog(null, "��ѡ������Ч������");
						}else{
							//���Ӳ�����������
							flag=true;
							getEachTypeSalesTable1();
						}
					}
					
				}
			});
		}
		return queryButton3;
	}

	/**
	 * This method initializes jScrollPane1	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setBounds(new Rectangle(26, 346, 517, 421));
			jScrollPane1.setViewportView(getEachTypeSalesTable1());
		}
		return jScrollPane1;
	}

	/**
	 * This method initializes eachTypeSalesTable1	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getEachTypeSalesTable1() {
		
		ManageService ms=new ManageService();
		if(flag==false){
			//��ʼʱ���
			String month=years.getSelectedItem()+"-"+months.getSelectedItem();
			//��Ϊ�¸���
			int tmp=Integer.parseInt(months.getSelectedItem()+"")+1;
			//��ֹʱ���
			String end=years.getSelectedItem()+"-"+tmp;
			System.out.println("=========end=============="+end);
			long count=ms.getSalesTotleMoneyOfMonth(month,end);
			dateLabel2.setText("�·�:"+years.getSelectedItem()+"��"+months.getSelectedItem()+"��");
			salesMoneyLabel2.setText("�����ܶ�Ϊ:"+count+"Ԫ");
			System.err.println("���²�ѯ:  flag="+flag);
			queryByMonth(month,end);
		}else if(flag==true){
			String day=years.getSelectedItem()+"-"+months.getSelectedItem()+"-"+dday;
			long count=ms.getSalesTotleMoneyOfDay(day);
			dateLabel2.setText("����:"+day);
			salesMoneyLabel2.setText("�����ܶ�Ϊ:"+count+"Ԫ");
			queryByDay(day);
			System.err.println("���ղ�ѯ:  flag="+flag);
		}
		
		//System.err.println("======��ѯ:  flag="+flag);
		if (eachTypeSalesTable1 == null) {
			eachTypeSalesTable1 = new JTable();
		}
		
		eachTypeSalesTable1.setModel(dtMonth);
		eachTypeSalesTable1.revalidate();
		
		return eachTypeSalesTable1;
	}
	
	
	public void queryByMonth(String month,String end){
		ManageService ms=new ManageService();
		//tableId=Integer.parseInt(squareAccountComboBox.getSelectedItem()+"");
		//menus=bDS.alreadyCostGoods(tableId);
		List<Object[]> lists=ms.queryByMonth(month,end);
		String[] cols = {"���","����","�˼�","����","���۶�"};
		if(eachTypeSalesTable1!=null)
			eachTypeSalesTable1.removeAll();
		dtMonth=new DefaultTableModel();
		dtMonth.setColumnIdentifiers(cols);
		Iterator<Object[]> iter=lists.iterator();
		while(iter.hasNext()){
			Object[] newRow=iter.next();
			dtMonth.addRow(newRow);
		}

		if (eachTypeSalesTable1 == null) {
			eachTypeSalesTable1=new JTable();
			eachTypeSalesTable1.setModel(dtMonth);
			eachTypeSalesTable1.setRowHeight(32);
		}
		
		
	}

	public void queryByDay(String day){
		ManageService ms=new ManageService();
		//tableId=Integer.parseInt(squareAccountComboBox.getSelectedItem()+"");
		//menus=bDS.alreadyCostGoods(tableId);
		List<Object[]> lists=ms.queryByDay(day);
		String[] cols = {"���","����","�˼�","����","���۶�"};
		if(eachTypeSalesTable1!=null)
			eachTypeSalesTable1.removeAll();
		dtMonth=new DefaultTableModel();
		dtMonth.setColumnIdentifiers(cols);
		Iterator<Object[]> iter=lists.iterator();
		while(iter.hasNext()){
			Object[] newRow=iter.next();
			dtMonth.addRow(newRow);
		}

		if (eachTypeSalesTable1 == null) {
			eachTypeSalesTable1=new JTable();
			eachTypeSalesTable1.setModel(dtMonth);
			eachTypeSalesTable1.setRowHeight(32);
		}
		
		
	}

	/**
	 * This method initializes exitButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getExitButton() {
		if (exitButton == null) {
			exitButton = new JButton();
			exitButton.setBounds(new Rectangle(475, 33, 94, 30));
			exitButton.setFont(new Font("Dialog", Font.BOLD, 18));
			exitButton.setText("�˳�");
			exitButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					close();
				}
			});
		}
		return exitButton;
	}

	/**
	 * This method initializes jButton3	
	 * 	
	 * @return javax.swing.JButton	
	 */
	/*private JButton getJButton3() {
		if (jButton3 == null) {
			jButton3 = new JButton();
			jButton3.setBounds(new Rectangle(493, 160, 92, 33));
			jButton3.setText("��ѯĳ��");
			jButton3.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int myyear=Integer.parseInt(years.getSelectedItem()+"");
					//System.out.println(myyear);
					int mymonth=Integer.parseInt(months.getSelectedItem()+"");
					//System.out.println(mymonth);
					int myday=Integer.parseInt(dt.getValueAt(jTable.getSelectedRow(), jTable.getSelectedColumn())+"");
					//System.out.println(myday);
					TotalViewService service=new TotalViewService();
					List list=service.selectByDay(myyear, mymonth, myday);
//					System.out.println(list.size());
//					List list2=new ArrayList();

					
					
					//System.out.println(list);
					Iterator iter=list.iterator();
//					���ԭ��
					
					for(int i=dt2.getRowCount()-1;i>=0;i--){
						dt2.removeRow(i);
					}
					
					while(iter.hasNext()){
						System.out.println("����");
						TotalView tv=new TotalView();
						tv=(TotalView)iter.next();
						dt2.addRow(new String[]{tv.getMname(),tv.getMtype(),tv.getPerprice()+"",tv.getNum()+"",tv.getMumprice()+""});
					}
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButton3;
	}*/

	/**
	 * This method initializes jTable	
	 * 	
	 * @return javax.swing.JTable	
	 */


}  //  @jve:decl-index=0:visual-constraint="95,-176"
