/**
 * @author ����־
 * @time 2014-8-22 ����09:09:46
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JComboBox;

import com.neusoft.bean.Dining_table;
import com.neusoft.bean.Menu;
import com.neusoft.service.BookDinnerService;
import com.neusoft.service.ManageService;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

/**
 * @author new
 *
 */
public class SquareAccounts extends JFrame {
	
	private BookDinnerService bDS=new BookDinnerService();  //  @jve:decl-index=0:
	
	private ManageService ms=new ManageService();  //  @jve:decl-index=0:
	
	private int tableId=0;

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel suqLabel = null;

	private JComboBox squareAccountComboBox = null;

	private JLabel accountLabel = null;

	private JScrollPane jScrollPane = null;

	private JTable accountTable = null;

	private JLabel costLabel = null;

	private JLabel costMoneyLabel = null;

	private JLabel realPayLabel = null;

	private JTextField payTextField = null;

	private JLabel oddChangeLabel = null;

	private JLabel oddchangeLabel = null;

	private JButton SquareAccountButton = null;
	
	private DefaultTableModel dtalready=new DefaultTableModel();

	/**
	 * This is the default constructor
	 */
	public SquareAccounts() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(582, 491);
		this.setContentPane(getJContentPane());
		this.setTitle("����");
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			oddchangeLabel = new JLabel();
			oddchangeLabel.setBounds(new Rectangle(480, 131, 87, 29));
			oddchangeLabel.setText("");
			oddChangeLabel = new JLabel();
			oddChangeLabel.setBounds(new Rectangle(405, 130, 67, 29));
			oddChangeLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			oddChangeLabel.setHorizontalAlignment(SwingConstants.CENTER);
			oddChangeLabel.setText("����:");
			realPayLabel = new JLabel();
			realPayLabel.setBounds(new Rectangle(405, 91, 67, 29));
			realPayLabel.setHorizontalAlignment(SwingConstants.CENTER);
			realPayLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			realPayLabel.setText("ʵ�����:");
			costMoneyLabel = new JLabel();
			costMoneyLabel.setBounds(new Rectangle(471, 53, 100, 28));
			costMoneyLabel.setText("");
			costLabel = new JLabel();
			costLabel.setBounds(new Rectangle(340, 52, 130, 29));
			costLabel.setHorizontalAlignment(SwingConstants.CENTER);
			costLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			costLabel.setText("�����ѽ��:");
			accountLabel = new JLabel();
			accountLabel.setBounds(new Rectangle(12, 51, 261, 36));
			accountLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			accountLabel.setHorizontalAlignment(SwingConstants.CENTER);
			accountLabel.setText("�����˵���ʾ:");
			suqLabel = new JLabel();
			suqLabel.setText("��������:");
			suqLabel.setBounds(new Rectangle(13, 8, 75, 33));
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(suqLabel, null);
			jContentPane.add(accountLabel, null);
			jContentPane.add(getJScrollPane(), null);
			jContentPane.add(costLabel, null);
			jContentPane.add(costMoneyLabel, null);
			jContentPane.add(realPayLabel, null);
			jContentPane.add(getPayTextField(), null);
			jContentPane.add(oddChangeLabel, null);
			jContentPane.add(oddchangeLabel, null);
			jContentPane.add(getSquareAccountButton(), null);
			jContentPane.add(getSquareAccountComboBox(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes squareAccountComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getSquareAccountComboBox() {
		if (squareAccountComboBox == null) {
			squareAccountComboBox = new JComboBox();
			squareAccountComboBox.setBounds(new Rectangle(90, 9, 145, 33));
			squareAccountComboBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("--����--)"); // TODO Auto-generated Event stub actionPerformed()
					String tid=squareAccountComboBox.getSelectedItem()+"";
					System.err.println("--squareAccountComboBox--"+squareAccountComboBox.getSelectedItem());
					if(!tid.equals("null")){
						tableId= Integer.parseInt(tid);
						System.out.println(tableId);
						getAccountTable();
						int money=bDS.alreadyCostMoney(tableId);
						costMoneyLabel.setText(" "+money+" Ԫ");
						payTextField.setText("");
						oddchangeLabel.setText("");
					}
					
					
					
					
				}
			});
			getTableId(squareAccountComboBox);
		}
		return squareAccountComboBox;
	}
	
	/**
	 * @func ��������Ʒ
	 * @param menus
	 */
	private void alreadyCost(List<Menu> menus){
		
		
		if(accountTable!=null)
			accountTable.removeAll();
		Iterator<Menu> iter=menus.iterator();
		while(iter.hasNext()){
			Menu menu=new Menu();
			menu=iter.next();
			String type="";
			/*������(1,��Ʒ\2,���\3,�ز�\4,��ˮ\5\��\6��ʳ\7.����)*/
			switch(menu.getMtype()){
			case 1:type="��ʳ";break;
			case 2:type="���";break;
			case 3:type="�ز�";break;
			case 4:type="��ˮ";break;
			case 5:type="��";break;
			case 6:type="��ʳ";break;
			case 7:type="����";break;
			default:type="�޷���";break;
			}
			System.out.println("+++++++++++����:"+menu.getMname());
			//System.out.println(menu.getMname()+"\t"+menu.getMprice()+"\t"+menu.getMtype());
			//System.out.println(menu.getMid()+"\t"+menu.getMid()+"\t"+menu.getMname()+"\t"+menu.getMprice()+"\t"+type+"\t"+menu.getMpic());
			Object[] menuRow=new Object[]{menu.getMname(),
					menu.getMprice()+"",type,menu.getMnum()};
			dtalready.addRow(menuRow);
		}
		if (accountTable == null) {
			accountTable=new JTable();
			accountTable.setModel(dtalready);
			accountTable.setRowHeight(32);
		}
	}
	
	/**
	 * @func ��ȡ����ʹ���е����ӵ�id
	 * @param queryTable
	 */
	private void getTableId(JComboBox queryBox){
		BookDinnerService bDS=new BookDinnerService();
		List<Dining_table> tables=bDS.findOccupyTable();
		queryBox.removeAllItems();
		for (Iterator<Dining_table> iter = tables.iterator(); iter.hasNext();) {
			Dining_table table = iter.next();
			int tid=table.getTid();
			queryBox.addItem(tid);
		}
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(11, 97, 392, 351));
			jScrollPane.setViewportView(getAccountTable());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes accountTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getAccountTable() {
		BookDinnerService bDS=new BookDinnerService();
		List<Menu> menus=new ArrayList<Menu>();
		//tableId=Integer.parseInt(squareAccountComboBox.getSelectedItem()+"");
		menus=bDS.alreadyCostGoods(tableId);
		String[] cols = {"����","�˼�","����","����"};
		dtalready=new DefaultTableModel();
		dtalready.setColumnIdentifiers(cols);
		alreadyCost(menus);
		
		if (accountTable == null) {
			accountTable = new JTable(dtalready);
		}
		
		accountTable.setModel(dtalready);
		accountTable.revalidate();
		return accountTable;
	}

	/**
	 * This method initializes payTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getPayTextField() {
		if (payTextField == null) {
			payTextField = new JTextField();
			payTextField.setBounds(new Rectangle(480, 91, 87, 29));
		}
		return payTextField;
	}

	/**
	 * This method initializes SquareAccountButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getSquareAccountButton() {
		if (SquareAccountButton == null) {
			SquareAccountButton = new JButton();
			SquareAccountButton.setBounds(new Rectangle(473, 197, 90, 39));
			SquareAccountButton.setFont(new Font("Dialog", Font.BOLD, 18));
			SquareAccountButton.setText("����");
			SquareAccountButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("----����--"); // TODO Auto-generated Event stub actionPerformed()
					int money=bDS.alreadyCostMoney(tableId);
					costMoneyLabel.setText(" "+money+" Ԫ");
					String pays=payTextField.getText();
					Pattern p = Pattern.compile("(^[0-9]{4})|(^[0-9]{3})|(^[0-9]{2})|(^[0-9]{1})|(^[0-9]{5})");  
					Matcher m = p.matcher(pays);  
					if(m.matches()==true){
						int pay=Integer.parseInt(payTextField.getText()+"");
						costMoneyLabel.setText(" "+money+" Ԫ");
						int oddChange=pay-money;
						if(oddChange>=0){
							oddchangeLabel.setText(oddChange+"Ԫ");
							/*appendCountTable  squareAccounts*/
							Dining_table dt=new Dining_table();
							dt.setTid(tableId);
							int num1=ms.appendCountTable(dt);
							if(num1>0){
								JOptionPane.showMessageDialog(null, "���Ѽ�¼�Ѿ����ӵ�ͳ�Ʊ���");
								num1=ms.squareAccounts(dt);
								if(num1>0){
									JOptionPane.showMessageDialog(null, "����������,������ɾ��");
									getTableId(squareAccountComboBox);
								}
							}else{
								JOptionPane.showMessageDialog(null, "���Ѽ�¼���ӵ�ͳ�Ʊ�ʧ��!");
							}
						}else{
							JOptionPane.showMessageDialog(null, "��������");
						}
					}else{
						JOptionPane.showMessageDialog(null, "����������!");
					}
				
				}
			});
		}
		return SquareAccountButton;
	}

}  //  @jve:decl-index=0:visual-constraint="95,13"
