/**
 * @author ����־
 * @time 2014-8-22 ����02:50:19
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.neusoft.bean.Menu;
import com.neusoft.service.BookDinnerService;
import com.neusoft.service.ManageService;

/**
 * @author new
 *
 */
public class FoodSalesNum extends JFrame {
	
	private DefaultTableModel dt=new DefaultTableModel();

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel salesLabel = null;

	private JScrollPane jScrollPane = null;

	private JTable salesTable = null;

	/**
	 * This is the default constructor
	 */
	public FoodSalesNum() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(526, 579);
		this.setContentPane(getJContentPane());
		this.setTitle("��\\������");
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			salesLabel = new JLabel();
			salesLabel.setBounds(new Rectangle(64, 7, 372, 48));
			salesLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			salesLabel.setHorizontalAlignment(SwingConstants.CENTER);
			salesLabel.setText("�������а�");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(salesLabel, null);
			jContentPane.add(getJScrollPane(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(15, 58, 481, 462));
			jScrollPane.setViewportView(getSalesTable());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes salesTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getSalesTable() {
		
		List<Menu> menus=new ArrayList<Menu>();
		//tableId=Integer.parseInt(squareAccountComboBox.getSelectedItem()+"");
		ManageService ms=new ManageService();
		menus=ms.getSalesVolume();
		String[] cols = {"�˱��","����","�˼�","����","����"};
		dt=new DefaultTableModel();
		dt.setColumnIdentifiers(cols);
		salesNum(menus);
		if (salesTable == null) {
			salesTable = new JTable();
			salesTable.setEnabled(false);
			salesTable.setColumnSelectionAllowed(true);
		}
		return salesTable;
	}
	

	/**
	 * @func ��������Ʒ
	 * @param menus
	 */
	private void salesNum(List<Menu> menus){
		
		
		if(salesTable!=null)
			salesTable.removeAll();
		Iterator<Menu> iter=menus.iterator();
		while(iter.hasNext()){
			Menu menu=new Menu();
			menu=iter.next();
			String type="";
			/*������(1,��Ʒ\2,���\3,�ز�\4,��ˮ\5\��\6��ʳ\7.����)*/
			switch(menu.getMtype()){
			case 1:type="��ʳ";break;
			case 2:type="���";break;
			case 3:type="�ز�";break;
			case 4:type="��ˮ";break;
			case 5:type="��";break;
			case 6:type="��ʳ";break;
			case 7:type="����";break;
			default:type="�޷���";break;
			}
			System.out.println("+++++++++++����:"+menu.getMname());
			//System.out.println(menu.getMname()+"\t"+menu.getMprice()+"\t"+menu.getMtype());
			//System.out.println(menu.getMid()+"\t"+menu.getMid()+"\t"+menu.getMname()+"\t"+menu.getMprice()+"\t"+type+"\t"+menu.getMpic());
			Object[] menuRow=new Object[]{menu.getMid(),menu.getMname(),
					menu.getMprice()+"",type,menu.getMnum()};
			dt.addRow(menuRow);
		}
		if (salesTable == null) {
			salesTable=new JTable();
			salesTable.setModel(dt);
			salesTable.setRowHeight(32);
		}
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
