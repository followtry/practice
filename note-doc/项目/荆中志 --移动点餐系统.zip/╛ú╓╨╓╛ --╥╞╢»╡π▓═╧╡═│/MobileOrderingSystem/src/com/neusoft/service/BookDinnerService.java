/**
 * @author ����־
 * @time 2014-8-20 ����01:18:24
 * @func ����ʱ�ĸ�����
 * 
 */
package com.neusoft.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.neusoft.bean.Dining_table;
import com.neusoft.bean.Menu;
import com.neusoft.bean.User;
import com.neusoft.dao.BookDinnerDao;
import com.neusoft.dao.UserDao;
import com.neusoft.jdbc.DBConn;

/**
 * @author new
 *
 */
public class BookDinnerService {

	private Connection conn;
	
	private DBConn db=new DBConn();
	
	/**
	 * @func �ҵ����ʵ����ӾͲͻ���
	 * @param dt
	 * @return	boolean
	 */
	public boolean chooseTable(Dining_table dt){
		boolean isOk=false;
		try {
			this.conn=db.connection();
			
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			int tid=dt.getTid();
			int tstate=dt.getTstate();
			Dining_table dtmp=bDao.findTableByTid(tid);
			if(dtmp.getTstate()==0&&dtmp.getTid()>0){
				int num=bDao.updateTableStat(tid, tstate);
				if (num>0) {
					System.out.println("�Ѿ�����");
					isOk=true;
				}else{
					System.out.println("û�ҵ����ʵĲ���1");
					isOk=false;
				}
			}else if(dtmp.getTstate()==1&&dtmp.getTid()>0){
				int num=bDao.updateTableStat(tid, tstate);
				System.err.println("num="+num);
				if (num>0) {
					System.out.println("������Դ�Ѿ��ͷ�");
					isOk=true;
				}else{
					System.out.println("dtmp.getTstate()"+dtmp.getTstate()+"\tdtmp.getTid()"+dtmp.getTid());
					isOk=false;
				}
			}else{
				System.out.println("���Ų��ڷ�Χ������δѡ��");
				isOk=false;
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println("������δ���سɹ�--chooseTable--");
			isOk=false;
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("ϵͳSQL���ִ���--chooseTable--");
			isOk=false;
			e.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		return isOk;
	}
	
	/**
	 * @func ���ҿ��еĲ���,�Ա���ʾ�ڿͻ�����
	 * @return List<Dining_table>
	 */
	public List<Dining_table> findEmptyTable(){
		List<Dining_table> tables=new ArrayList<Dining_table>();
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			tables=bDao.findEmptyTable();
		} catch (ClassNotFoundException e) {
			System.out.println("������δ���سɹ�--findEmptyTable--");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("ϵͳSQL���ִ���--findEmptyTable--");
			e.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		
		return tables;
	}
	
	/**
	 * @func ���ұ�ռ�õĲ���,�Ա���ʾ�ڿͻ�����
	 * @return List<Dining_table>
	 */
	public List<Dining_table> findOccupyTable(){
		List<Dining_table> tables=new ArrayList<Dining_table>();
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			tables=bDao.findOccupyTable();
		} catch (ClassNotFoundException e) {
			System.out.println("������δ���سɹ�--findEmptyTable--");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("ϵͳSQL���ִ���--findEmptyTable--");
			e.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		
		return tables;
	}
	
	/**
	 * @func ͨ�� ��Ų���������Ϣ
	 * @param tid
	 * @return
	 */
	public Dining_table findTableByTid(int tid){
		Dining_table dt=new Dining_table();
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			dt=bDao.findTableByTid(tid);
			
		} catch (ClassNotFoundException e) {
			System.out.println("������δ���سɹ�--findTableByTid--");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("ϵͳSQL���ִ���--findEmptyTable--");
			e.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		return dt;
	}
	
	/**
	 * @func ����˵�
	 * @return List<Menu>
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public List<Menu> browseMenu(){
		List<Menu> menus=new ArrayList<Menu>();
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			menus=bDao.browseMenu();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		
		return menus;
	}
	
	/**
	 * @func ͨ�������������
	 * @param type
	 * @return List<Menu> 
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public List<Menu> browseMenuByType(int type){
		List<Menu> menus=new ArrayList<Menu>();
		
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			menus=bDao.browseMenuByType(type);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		return menus;
	}
	
	/**
	 * @func ͨ���������Ҳ�
	 * @param name
	 * @return Menu
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public Menu browseMenuByName(String name){
		Menu menu=new Menu();
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			menu=bDao.browseMenuByName(name);
		} catch (ClassNotFoundException e) {
			System.out.println("---browseMenuByName--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("---browseMenuByName--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		return menu;
	}
	
	/**
	 * @func ���Ӷ�����¼
	 * @param menuNames
	 * @param dt
	 * @param num
	 * @return int
	 */
	public int addOrderForms(List<Menu> menuNames,Dining_table dt){
		int count=0;
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			for (int i = 0; i < menuNames.size(); i++) {
				Menu menu=new Menu();
				 menu=menuNames.get(i);
				//System.out.println("name"+name);
				//menu=bDao.browseMenuByName(name);
				count+=bDao.addOrderForm(menu, dt);
			}
			System.out.println("--bDS--addOrderForms--�������ӳɹ�!");
		} catch (ClassNotFoundException e) {
			System.out.println("---addOrderForms--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("---addOrderForms--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		return count;
	}
	
	/**
	 * @func ͨ���û����鿴�û����
	 * @param user
	 * @return int
	 */
	public int getUserMoney(String username){
		int money=0;
		try {
			this.conn=db.connection();
			UserDao uDao=new UserDao(this.conn);
			money=uDao.getUserInfo(username).getMoney();
			System.out.println("money:"+money);
		} catch (ClassNotFoundException e) {
			System.out.println("---getUserMoney--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("---getUserMoney--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		return money;
	}
	
	/**
	 * @func �����ѽ������˽��
	 * @return
	 * @throws SQLException 
	 */
	public int alreadyCostMoney(int tid){
		int cost=0;
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			cost=bDao.alreadyCostMoney(tid);
			System.out.println("--alreadyCostMoney--"+cost);
		} catch (ClassNotFoundException e1) {
			System.out.println("---alreadyCostMoney--ClassNotFound-");
			e1.printStackTrace();
		} catch (SQLException e1) {
			System.out.println("---alreadyCostMoney--SQLException-");
			e1.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		return cost;
		
	}
	
	/**
	 * @func �����ѽ��
	 * @return
	 * @throws SQLException 
	 */
	public int notCostMoney(int tid){
		int cost=0;
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			cost=bDao.notCostMoney(tid);
			System.out.println("--notCostMoney--"+cost);
		} catch (ClassNotFoundException e1) {
			System.out.println("---notCostMoney--ClassNotFound-");
			e1.printStackTrace();
		} catch (SQLException e1) {
			System.out.println("---notCostMoney--SQLException-");
			e1.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		return cost;
	}
	
	/**
	 * @func �Ѿ����ѵ���ƷalreadyCostGoods
	 * @param tid
	 * @return List<Menu>
	 * @throws SQLException
	 */
	public List<Menu> alreadyCostGoods(int tid){
		List<Menu> menus=new ArrayList<Menu>();
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			menus=bDao.alreadyCostGoods(tid);
		} catch (ClassNotFoundException e) {
			System.out.println("---alreadyCostGoods--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("---alreadyCostGoods--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		return menus;
		
	}
	
	/**
	 * @func �����ѵ���Ʒ
	 * @param tid
	 * @return List<Menu>
	 * @throws SQLException
	 */
	public List<Menu> notCostGoods(int tid){
		List<Menu> menus=new ArrayList<Menu>();
		try {
			this.conn=db.connection();
			BookDinnerDao bDao=new BookDinnerDao(this.conn);
			menus=bDao.notCostGoods(tid);
		} catch (ClassNotFoundException e) {
			System.out.println("---alreadyCostGoods--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("---alreadyCostGoods--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				if(db!=null)
					db.close();
			} catch (SQLException e) {
				System.out.println("���ݿ�����δ�����ر�");
				e.printStackTrace();
			}
		}
		return menus;
	}
}