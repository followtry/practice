/**
 * @author ����־
 * @time 2014-8-19 ����06:11:03
 * @func ������
 * 
 */
package com.neusoft.contral;

import java.awt.Toolkit;

import com.neusoft.gui.MOGUI;

/**
 * @author new
 *
 */
public class GUIMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MOGUI mogui=new MOGUI();
		int w = (Toolkit.getDefaultToolkit().getScreenSize().width-mogui.WIDTH)/3;
		int h = (Toolkit.getDefaultToolkit().getScreenSize().height-mogui.HEIGHT)/4;
		
		mogui.setLocation(w, h);
		mogui.setVisible(true);
	}

}
