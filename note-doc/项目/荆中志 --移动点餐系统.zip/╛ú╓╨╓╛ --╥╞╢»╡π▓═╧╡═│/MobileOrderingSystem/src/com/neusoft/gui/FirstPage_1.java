/**
 * @author ����־
 * @time 2014-8-20 ����05:07:26
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.Font;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.SwingConstants;

import com.neusoft.bean.Dining_table;
import com.neusoft.bean.Menu;
import com.neusoft.dao.BookDinnerDao;
import com.neusoft.service.BookDinnerService;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import java.awt.ComponentOrientation;
import javax.swing.ListSelectionModel;
import javax.swing.BorderFactory;
import javax.swing.border.EtchedBorder;
import java.awt.event.KeyEvent;

/**
 * @author new
 *
 */
public class FirstPage_1 extends JFrame {
	
	/**********test****************/
	/*private  DefaultTableModel dtm=null;*/
	 /**********test****************/
	private String menuName="";  //  @jve:decl-index=0:
	
	private List<Menu> menuNames=new ArrayList<Menu>();  //  @jve:decl-index=0:
	
	private int tid=0;
	
	private String user="";  //  @jve:decl-index=0:

	private JLabel current = null;

	private JLabel userName = null;

	private JLabel queryLabel = null;

	private JComboBox queryTable = null;

	private JButton beSeated = null;

	private JButton beSeated2 = null;
	
	private BookDinnerService bDS=new BookDinnerService();  //  @jve:decl-index=0:

	/**
	 * This is the default constructor
	 */
	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel hintLabel = null;

	private JLabel peopleNum = null;

	private JLabel jLabel = null;

	private JScrollPane scrollPane = null;

	private JTable menuTable = null;

	private JLabel menuLabel = null;

	private DefaultTableModel dt;
	private DefaultTableModel dtOrder=new DefaultTableModel();

	private JLabel currentTableLabel = null;

	private JLabel tidLabel = null;

	private JLabel tidTextLabel = null;
	
	private boolean changeTable=false;
	private boolean selectTable=false;

	private JLabel foodLabel = null;

	private JComboBox foodTypeBox = null;

	private JLabel balLabel = null;

	private JLabel balanceLabel = null;

	private JLabel unitLabel = null;

	private JScrollPane orderScrollPane = null;

	private JTable orderTable = null;

	private JLabel orderInfoLabel = null;

	private JButton cancelOrderButton = null;

	private JButton okOrderButton = null;
	

	/**
	 * This is the default constructor
	 */
	/**
	 * This is the default constructor
	 */
	public FirstPage_1() {
		super();
		initialize();
	}
	public FirstPage_1(String user) {
		super();
		this.user=user;
		initialize();
		userName.setText(this.user);
		int money=bDS.getUserMoney(userName.getText());
		balanceLabel.setText(money+"");
	}
	
	public void close(){
		this.setVisible(false);
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setContentPane(getJContentPane());
		this.setTitle("��ҳ");
		this.setBounds(new Rectangle(400, 300, 873, 526));
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			orderInfoLabel = new JLabel();
			orderInfoLabel.setBounds(new Rectangle(512, 107, 271, 29));
			orderInfoLabel.setHorizontalAlignment(SwingConstants.CENTER);
			orderInfoLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			orderInfoLabel.setText("������Ϣ");
			unitLabel = new JLabel();
			unitLabel.setBounds(new Rectangle(403, 2, 30, 32));
			unitLabel.setText("Ԫ");
			balanceLabel = new JLabel();
			balanceLabel.setBounds(new Rectangle(339, 2, 65, 32));
			balanceLabel.setHorizontalAlignment(SwingConstants.CENTER);
			balanceLabel.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
			
			balLabel = new JLabel();
			balLabel.setBounds(new Rectangle(235, 2, 106, 32));
			balLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			balLabel.setText("�˻����:");
			foodLabel = new JLabel();
			foodLabel.setBounds(new Rectangle(237, 50, 72, 44));
			foodLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			foodLabel.setText("����ѡ��:");
			tidTextLabel = new JLabel();
			tidTextLabel.setBounds(new Rectangle(598, 5, 37, 26));
			tidTextLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			tidTextLabel.setText("��");
			tidLabel = new JLabel();
			tidLabel.setBounds(new Rectangle(554, 5, 42, 26));
			tidLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			if(tid==0)
				tidLabel.setText("δѡ");
			currentTableLabel = new JLabel();
			currentTableLabel.setBounds(new Rectangle(477, 5, 76, 27));
			currentTableLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			currentTableLabel.setText("��ǰ����:");
			menuLabel = new JLabel();
			menuLabel.setBounds(new Rectangle(8, 47, 226, 47));
			menuLabel.setFont(new Font("Dialog", Font.BOLD, 24));
			menuLabel.setHorizontalAlignment(SwingConstants.CENTER);
			menuLabel.setText("��˵�");
			peopleNum = new JLabel();
			peopleNum.setBounds(new Rectangle(554, 39, 115, 26));
			peopleNum.setText("");
			hintLabel = new JLabel();
			hintLabel.setBounds(new Rectangle(476, 38, 76, 28));
			hintLabel.setHorizontalAlignment(SwingConstants.CENTER);
			hintLabel.setFont(new Font("Dialog", Font.BOLD, 14));
			hintLabel.setText("��������:");
			queryLabel = new JLabel();
			queryLabel.setBounds(new Rectangle(476, 70, 75, 32));
			queryLabel.setHorizontalAlignment(SwingConstants.CENTER);
			queryLabel.setText("���в���:");
			userName = new JLabel();
			userName.setBounds(new Rectangle(78, 2, 125, 30));
			userName.setBackground(new Color(218, 47, 159));
			userName.setText("");
			current = new JLabel();
			current.setBounds(new Rectangle(12, 2, 66, 30));
			current.setHorizontalAlignment(SwingConstants.CENTER);
			current.setBackground(new Color(218, 203, 159));
			current.setText("��ǰ�û�:");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.setFont(new Font("Dialog", Font.PLAIN, 14));
			jContentPane.add(current, null);
			jContentPane.add(userName, null);
			jContentPane.add(queryLabel, null);
			jContentPane.add(getQueryTable(), null);
			jContentPane.add(getBeSeated(), null);
			jContentPane.add(getBeSeated2(), null);
			jContentPane.add(hintLabel, null);
			jContentPane.add(peopleNum, null);
			jContentPane.add(getScrollPane(), null);
			jContentPane.add(menuLabel, null);
			
			jContentPane.add(currentTableLabel, null);
			jContentPane.add(tidLabel, null);
			jContentPane.add(tidTextLabel, null);
			jContentPane.add(foodLabel, null);
			jContentPane.add(getFoodTypeBox(), null);
			jContentPane.add(balLabel, null);
			jContentPane.add(balanceLabel, null);
			jContentPane.add(unitLabel, null);
			jContentPane.add(getOrderScrollPane(), null);
			jContentPane.add(orderInfoLabel, null);
			jContentPane.add(getCancelOrderButton(), null);
			jContentPane.add(getOkOrderButton(), null);
		}
		return jContentPane;
	}
	
	/**
	 * This method initializes queryTable	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getQueryTable() {
		if (queryTable == null) {
			queryTable = new JComboBox();
			queryTable.setBounds(new Rectangle(555, 71, 112, 31));
			queryTable.addItemListener(new java.awt.event.ItemListener() {
				public void itemStateChanged(java.awt.event.ItemEvent e) {
					//System.out.println("getSelectedItem----- :"+queryTable.getSelectedItem());
					if(queryTable.getSelectedItem()!=null){
						int tableid=Integer.parseInt(queryTable.getSelectedItem()+"");
						System.out.println("--getQueryTable------table--index"+queryTable.getSelectedIndex());
						System.out.println("--getQueryTable------tableid:"+tableid);
						Dining_table dt=new Dining_table();
						dt=bDS.findTableByTid(tableid);
						peopleNum.setText("���� "+dt.getPnum()+" ��");
					}
				}
			});
			getTableId(queryTable);
		}
		return queryTable;
	}

	/**
	 * @func ��ȡ���п����ӵ�id
	 * @param queryTable
	 */
	private void getTableId(JComboBox queryTable){
		BookDinnerService bDS=new BookDinnerService();
		List<Dining_table> tables=bDS.findEmptyTable();
		queryTable.removeAllItems();
		for (Iterator<Dining_table> iter = tables.iterator(); iter.hasNext();) {
			Dining_table table = iter.next();
			int tid=table.getTid();
			queryTable.addItem(tid);
		}
	}
	
	/**
	 * This method initializes beSeated	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBeSeated() {
		if (beSeated == null) {
			beSeated = new JButton();
			beSeated.setBounds(new Rectangle(675, 70, 90, 33));
			beSeated.setFont(new Font("Dialog", Font.BOLD, 18));
			beSeated.setText("ѡ��");
			beSeated.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					//System.out.println("actionPerformed()"); 
					if(tid==0)
						selectTable=true;
					tid=Integer.parseInt(queryTable.getSelectedItem()+"");
					System.out.println("tid:"+tid);
					
					Dining_table dt=new Dining_table();
					dt.setTid(tid);
					dt.setTstate(1);/*��������*/
					if(selectTable&&bDS.chooseTable(dt)){
						tid=Integer.parseInt(queryTable.getSelectedItem()+"");
						System.out.println("--��������-- : "+tid);
						tidLabel.setText(tid+"");
						selectTable=false;
						JOptionPane.showMessageDialog(null, "����������!^_^");
					}else if(!selectTable){
						JOptionPane.showMessageDialog(null, "���Ѿ�ѡ���˲���!");
					}else{
						tid=0;
						tidLabel.setText("δѡ");
						JOptionPane.showMessageDialog(null, "ѡ�����ɹ�,����һ�ΰ�!");
					}
					getTableId(queryTable);
				}
			});
		}
		return beSeated;
	}

	/**
	 * This method initializes beSeated2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBeSeated2() {
		if (beSeated2 == null) {
			beSeated2 = new JButton();
			beSeated2.setBounds(new Rectangle(768, 70, 83, 33));
			beSeated2.setFont(new Font("Dialog", Font.BOLD, 18));
			beSeated2.setText("����");
			beSeated2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if(tid>0)
						changeTable=true;
					Dining_table dt=new Dining_table();
					System.out.println("��ǰ�Ĳ�����:"+tid);
					dt.setTid(tid);
					dt.setTstate(0);/*�ͷŲ���*/
					if(!changeTable){
						JOptionPane.showMessageDialog(null, "����ѡ�����,�����л����Ļ���Ŷ!");
					}
					else if(bDS.chooseTable(dt)&&changeTable){
						changeTable=false;
						tid=0;
						tidLabel.setText("δѡ");
						JOptionPane.showMessageDialog(null, "�����ͷ�,����һ����!^_^");
					}else{
						JOptionPane.showMessageDialog(null, "�������ɹ�,����һ�ΰ�!");
					}
					getTableId(queryTable);
				}
			});
		}
		return beSeated2;
	}
	/**
	 * This method initializes scrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setBounds(new Rectangle(5, 105, 448, 339));
			scrollPane.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
			scrollPane.setViewportView(getMenuTable());
			scrollPane.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
		}
		return scrollPane;
	}
	
	private void addMenu(List<Menu> menus){
		
		String[] cols = {"�˱��","����","�۸�","����","ѡ��"};
		String[][] rows ={};
		//dt=(DefaultTableModel)menuTable.getModel();
		//dt = new DefaultTableModel(rows,cols);
		/**********test****************/
		/*dtm = (DefaultTableModel)menuTable.getModel();
		  dtm.setColumnIdentifiers(cols);*/
			/*********test*****************/
		  
		dt=new DefaultTableModel();
		dt.setColumnIdentifiers(cols);
		JCheckBox selectBox=new JCheckBox();
		selectBox.setText("");
		if(menuTable!=null)
			menuTable.removeAll();
		Iterator iter=menus.iterator();
		while(iter.hasNext()){
			Menu menu=new Menu();
			menu=(Menu)iter.next();
			String type="";
			/*������(1,��Ʒ\2,���\3,�ز�\4,��ˮ\5\��\6��ʳ\7.����)*/
			switch(menu.getMtype()){
			case 1:type="��ʳ";break;
			case 2:type="���";break;
			case 3:type="�ز�";break;
			case 4:type="��ˮ";break;
			case 5:type="��";break;
			case 6:type="��ʳ";break;
			case 7:type="����";break;
			default:type="�޷���";break;
			}
			selectBox.setVisible(true);
			//System.out.println(menu.getMid()+"\t"+menu.getMid()+"\t"+menu.getMname()+"\t"+menu.getMprice()+"\t"+type+"\t"+menu.getMpic());
			Object[] menuRow=new Object[]{menu.getMid()+"",menu.getMname(),
					menu.getMprice()+"",type,new Boolean(false)};
			dt.addRow(menuRow);
			
		}
	       
	}
	/**
	 * This method initializes menuTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getMenuTable() {

		BookDinnerService bDS=new BookDinnerService();
		List<Menu> menus=new ArrayList<Menu>();
		menus=bDS.browseMenu();
		addMenu(menus);
		
		System.out.println("---------------------");
		if (menuTable == null) {
			/*menuTable = new JTable(dt);*/
			menuTable = new JTable(dt);
			
			menuTable.setEnabled(true);
			menuTable.setFont(new Font("Dialog", Font.PLAIN, 14));
			menuTable.setRowHeight(32);
			menuTable.setSelectionBackground(new Color(40, 154, 149));
			menuTable.setShowGrid(true);
			
			menuTable.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
			menuTable.setColumnSelectionAllowed(true);
			menuTable.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
			menuTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			menuTable.setBackground(new Color(0, 153, 153));
			menuTable.addMouseListener(new java.awt.event.MouseAdapter() {   
				public void mousePressed(java.awt.event.MouseEvent e) { 
					if(tid!=0){
						System.out.println(menuTable.getValueAt(menuTable.getSelectedRow(),1));
						menuName=menuTable.getValueAt(menuTable.getSelectedRow(),1)+"";
						BookDinnerService bds=new BookDinnerService();
						Menu menu =new Menu();
						menu=bds.browseMenuByName(menuName);
						int i;
						boolean flag=true;
						for(i=0;i<menuNames.size();i++){
							System.err.println("1111111--menuNames.get(i).getMnum()"+menuNames.get(i).getMnum());
							if(menuNames.get(i).getMname().equals(menuName)){
								menuNames.get(i).setMnum(menuNames.get(i).getMnum()+1);
								flag=false;
								System.err.println("=========menuNames.get(i).getMnum()"+menuNames.get(i).getMnum());
							}
						}
						if(i==0||flag==true){
							menu.setMnum(menu.getMnum()+1);
								menuNames.add(menu);
								System.err.println("------menuNames.get(i).getMnum()"+menuNames.get(i).getMnum());
						}
						
						System.out.println("mousePressed()"); // TODO Auto-generated Event stub mousePressed()
						orderMenu(menuNames);
						if(orderTable!=null){
							orderTable.setModel(dtOrder);
							System.out.println("dtOrder");
						}
					}else{
						JOptionPane.showMessageDialog(null, "��������λ����,��ѡ��Ҳ����Ŷ!");
					}
				}   
			});
			menuTable.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
				public void mouseDragged(java.awt.event.MouseEvent e) {
					System.out.println("--mouseDragged()--"); // TODO Auto-generated Event stub mouseDragged()
					System.out.println(menuName);
				}
			});
			
		
			menuTable.setRowHeight(20, 30);
		}
		return menuTable;
	}
	/**
	 * This method initializes foodTypeBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getFoodTypeBox() {
		if (foodTypeBox == null) {
			foodTypeBox = new JComboBox();
			foodTypeBox.addItem("ȫ��")  ;
			foodTypeBox.addItem("��ʳ");
			foodTypeBox.addItem("��ʳ");
			foodTypeBox.addItem("��ʳ");
			foodTypeBox.addItem("��ˮ");
			foodTypeBox.addItem("��");
			foodTypeBox.addItem("��ʳ");
			foodTypeBox.addItem("����");
			foodTypeBox.setBounds(new Rectangle(312, 51, 139, 43));
			foodTypeBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("foodTypeBox--index:"+foodTypeBox.getSelectedIndex()+"\tfoodTypeBox--item:"+foodTypeBox.getSelectedItem()); // TODO Auto-generated Event stub actionPerformed()
					List<Menu> menus=new ArrayList<Menu>();
					int type=foodTypeBox.getSelectedIndex();/*�����ѯ*/
					if(type>0){
						menus=bDS.browseMenuByType(type);
						
					}else if(type==0){
						menus=bDS.browseMenu();
					}else{
						System.out.println("--foodTypeBox--ѡ�����!");
					}
					 
					addMenu(menus);
					if(menuTable!=null)
						menuTable.setModel(dt);
					/*	menuTable.setModel(dtm);*/
				}
			});
			
		}
		return foodTypeBox;
	}
	/**
	 * This method initializes orderScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getOrderScrollPane() {
		if (orderScrollPane == null) {
			orderScrollPane = new JScrollPane();
			orderScrollPane.setBounds(new Rectangle(478, 140, 367, 301));
			orderScrollPane.setViewportView(getOrderTable());
		}
		return orderScrollPane;
	}
	/**
	 * This method initializes orderTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getOrderTable() {
		if (orderTable == null) {
			orderTable = new JTable(dtOrder);
		}
		orderTable.setVisible(true);
		orderTable.setRowHeight(32);
		orderTable.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mousePressed(java.awt.event.MouseEvent e) {
				System.out.println("---mousePressed()--"+
						orderTable.getValueAt(orderTable.getSelectedRow(),0 ));
				/*menuNames*/
				String mname=orderTable.getValueAt(orderTable.getSelectedRow(),0)+"";
				for(int i=0;i<menuNames.size();i++){
					if(menuNames.get(i).getMname().equals(mname)&&menuNames.get(i).getMnum()>1){
						System.out.println(menuNames.get(i));
						menuNames.get(i).setMnum(menuNames.get(i).getMnum()-1);
					}else if(menuNames.get(i).getMname().equals(mname)&&menuNames.get(i).getMnum()==1){
						menuNames.remove(i);
						break;
					}
				}
				orderMenu(menuNames);
				if(orderTable!=null){
					orderTable.setModel(dtOrder);
				}
			}
		});
		return orderTable;
	}
	
	private void orderMenu(List<Menu> menuNames){
		String[] cols = {"����","�۸�","����","����"};
		dtOrder=new DefaultTableModel();
		dtOrder.setColumnIdentifiers(cols);
		orderTable.removeAll();
		Iterator<Menu> iter=menuNames.iterator();
		while(iter.hasNext()){
			Menu menu=new Menu();
			menu =iter.next();
			//menu=bDS.browseMenuByName(mname);
			String type="";
			/*������(1,��Ʒ\2,���\3,�ز�\4,��ˮ\5\��\6��ʳ\7.����)*/
			switch(menu.getMtype()){
			case 1:type="��ʳ";break;
			case 2:type="���";break;
			case 3:type="�ز�";break;
			case 4:type="��ˮ";break;
			case 5:type="��";break;
			case 6:type="��ʳ";break;
			case 7:type="����";break;
			default:type="�޷���";break;
			}
			System.out.println(menu.getMname()+"\t"+menu.getMprice()+"\t"+menu.getMtype());
			//System.out.println(menu.getMid()+"\t"+menu.getMid()+"\t"+menu.getMname()+"\t"+menu.getMprice()+"\t"+type+"\t"+menu.getMpic());
			Object[] menuRow=new Object[]{menu.getMname(),
					menu.getMprice()+"",type,menu.getMnum()};
			dtOrder.addRow(menuRow);
		}
	}
	/**
	 * This method initializes cancelOrderButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelOrderButton() {
		if (cancelOrderButton == null) {
			cancelOrderButton = new JButton();
			cancelOrderButton.setBounds(new Rectangle(479, 450, 136, 36));
			cancelOrderButton.setFont(new Font("Dialog", Font.BOLD, 18));
			cancelOrderButton.setText("ȡ������");
			cancelOrderButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					menuNames.removeAll(menuNames);
					orderMenu(menuNames);
					if(orderTable!=null){
						orderTable.setModel(dtOrder);
					}
					JOptionPane.showMessageDialog(null, "�����Ѿ�ȡ��");
				}
				
			});
		}
		return cancelOrderButton;
	}
	/**
	 * This method initializes okOrderButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkOrderButton() {
		if (okOrderButton == null) {
			okOrderButton = new JButton();
			okOrderButton.setBounds(new Rectangle(690, 448, 117, 35));
			okOrderButton.setFont(new Font("Dialog", Font.BOLD, 18));
			okOrderButton.setText("ȷ�϶���");
			okOrderButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("---ȷ�϶���--"); // TODO Auto-generated Event stub actionPerformed()
					
					Dining_table dt=new Dining_table();
					dt.setTid(tid);
					//int num=1;/*�˵�����*/
					int count=bDS.addOrderForms(menuNames, dt);
					if(count>0){
						JOptionPane.showMessageDialog(null, "�ɹ��ύ����,�ܹ�"+count+"��!����:"+tid);
					
						menuNames.removeAll(menuNames);
						orderMenu(menuNames);
						if(orderTable!=null){
							orderTable.setModel(dtOrder);
						}
						ContentPage cp=new  ContentPage(userName.getText(),tid);
						
						int w = (Toolkit.getDefaultToolkit().getScreenSize().width-FirstPage_1.WIDTH)/5;
						int h = (Toolkit.getDefaultToolkit().getScreenSize().height-FirstPage_1.HEIGHT)/5;
						
						cp.setLocation(w, h);
						cp.setVisible(true);
					}else{
						JOptionPane.showMessageDialog(null, "�ɹ��ύ����ʧ��!! ����:"+tid);
					}
				//	close();
					
				}
			});
		}
		return okOrderButton;
	}
}  //  @jve:decl-index=0:visual-constraint="10,10"  