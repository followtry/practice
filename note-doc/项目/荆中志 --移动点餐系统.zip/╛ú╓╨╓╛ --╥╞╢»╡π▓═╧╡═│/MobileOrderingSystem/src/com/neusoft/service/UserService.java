/**
 * @time  2014-8-18 ����07:22:00
 * @author new
 * @function ת������
 * 
 */
package com.neusoft.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.print.attribute.standard.MediaSize.ISO;

import com.neusoft.bean.User;
import com.neusoft.dao.UserDao;
import com.neusoft.jdbc.DBConn;

/**
 * 
 */
public class UserService {
	
	private Connection conn;
	private DBConn db=new DBConn();
	
	
	
	/**
	 * @func ͨ���û�����ȡ�û���Ϣ
	 * @param username
	 * @return
	 * @throws SQLException 
	 */
	public User getUserInfo(String username) {
		User user=new User();
		try {
			this.conn=db.connection();
			UserDao ud=new UserDao(this.conn);
			user=ud.getUserInfo(username);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return user;
	}

	/**
	 * @func �����û�����
	 * @param user
	 * @return
	 */
	public boolean updateUser(User user){
		boolean isOk=false;
		try {
			this.conn=db.connection();
			UserDao ud=new UserDao(this.conn);
			isOk=ud.updateUser(user);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return isOk;
	}
	
	/**
	 * @func �����û��˻����
	 * @param user
	 * @return
	 */
	public boolean updateMoney(User user){
		boolean isOk=false;
		try {
			this.conn=db.connection();
			UserDao ud=new UserDao(this.conn);
			isOk=ud.updateMoney(user);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return isOk;
	}
	
	
	/**
	 * @func ɾ���û���Ϣ
	 * @param user
	 * @return
	 */
	public boolean deleteUser(User user){
		boolean isOk=false;
		try {
			this.conn=db.connection();
			UserDao ud=new UserDao(this.conn);
			isOk=ud.deleteUser(user);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return isOk;
	}
	
	
	/**
	 * @func ��ȡ�����û���Ϣ
	 * @return
	 */
	public List<User> getAllUserInfo(){
		List<User> users=new ArrayList<User>();
		try {
			this.conn=db.connection();
			UserDao ud=new UserDao(this.conn);
			users=ud.getAllUserInfo();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return users;
	}
	
	/**
	 * @func �����û�
	 * @param user
	 * @return
	 */
	public boolean isRegister(User user) {
		boolean isOK=false;
		UserDao dao;
		try {
			
			dao = new UserDao(db.connection());
			System.out.println("ok");
			isOK=dao.register(user);
			if (isOK) {
				System.out.println("ע��ɹ�");
			}else{
				System.err.println("ע��ʧ��");
			}
		} catch (ClassNotFoundException e1) {
			System.out.println("���������ʧ��!");
			e1.printStackTrace();
		} catch (SQLException e1) {
			System.err.println("ϵͳ�쳣!");
			e1.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return isOK;
	}
	
	/**
	 * @func ��¼ϵͳ
	 * @param username
	 * @param pwd
	 * @return
	 */
	public boolean isLogin(String username,String pwd) {
		boolean isOk=false;
		try {
			UserDao dao=new UserDao(db.connection());
			String password=dao.findPwd(username);
			System.out.println("password:"+password);
			isOk=password.equals(pwd);
		} catch (ClassNotFoundException e) {
			System.err.println("���������ʧ��");
			e.printStackTrace();
		} catch (SQLException e) {
			System.err.println("ϵͳ�쳣,δ�ܵ�¼�ɹ�");
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return isOk;
	}
	
	/**
	 * @func ��ȡ�û����� �ж�����ͨ�˿ͻ��ǹ���Ա
	 * @param username
	 * @return int
	 */
	public int getUserType(String username){
		int type=0;
		try {
			UserDao dao=new UserDao(db.connection());
			type=dao.findUserType(username);
		} catch (ClassNotFoundException e) {
			System.out.println("--getUserType--ClassNotFound--");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("--getUserType--SQLException--");
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return type;
	}
 	
	
	
/*	*//**
	 * @param args
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 *//*
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		UserTransfer uTransfer=new UserTransfer();
		String fromUser="jing";
		String toUser="zhi";
		int money=6000;
		uTransfer.Transfer(fromUser, toUser, money);
		System.out.println("����");
	}*/

}
