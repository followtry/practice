/**
 * @time  2014-8-18 ����07:04:28
 * @author new
 * @function ת�˵�ϸ�ڲ���
 * 
 */
package com.neusoft.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.neusoft.bean.User;
import com.neusoft.jdbc.DBConn;

/**
 * 
 */
public class UserDao {
	
	private Connection conn;
	private DBConn db=new DBConn();
	
	public UserDao() {}
	public UserDao(Connection conn) {
		this.conn=conn;
	}
	
	/**
	 * ɾ���û�
	 * @param user
	 * @return
	 * @throws SQLException
	 */
	public boolean deleteUser(User user) throws SQLException{
		db.connection(this.conn);
		String userName=user.getUserName();
		String sql="delete from users where username=?";
		Object obj[]={userName};
		int num=db.executeUpdate(sql,obj);
		return num>0?true:false;
	}
	
	/**
	 * @func �����û�����
	 * @param user
	 * @return
	 * @throws SQLException
	 */
	public boolean updateUser(User user) throws SQLException{
		db.connection(this.conn);
		String sql="update users set pwd=? where username=?";
		Object obj[]={user.getPwd(),user.getUserName()};
		int num=db.executeUpdate(sql,obj);
		return num>0?true:false;
	}
	
	/**
	 * @func �����û��˻����
	 * @param user
	 * @return
	 * @throws SQLException
	 */
	public boolean updateMoney(User user) throws SQLException{
		db.connection(this.conn);
		String sql="update users set money=money+? where username=?";
		Object obj[]={user.getMoney(),user.getUserName()};
		int num=db.executeUpdate(sql,obj);
		return num>0?true:false;
	}
	
	/**
	 * @func �����û�
	 * @param user
	 * @return
	 * @throws SQLException
	 */
	public boolean register(User user) throws SQLException {
		int count=0;
		String NameSql="select * from users where username='"+user.getUserName()+"'";
		db.connection(this.conn);
		ResultSet rs=db.executeQuery(NameSql);
		if (rs.next()) {
			System.out.println("�û��Ѿ�����!");
			return false;
		}else {
			String sql="insert into users(id,username,pwd,nickname,money,type) " +
				"values(?,?,?,?,?,?)";
			String queryMaxId="select max(id) from users";
			ResultSet rSet=db.executeQuery(queryMaxId);
			int maxId=0;
			if (rSet.next()) {
				maxId=rSet.getInt(1);
			}
			Object obj[]={maxId+1,user.getUserName(),user.getPwd(),user.getNickName(),user.getMoney(),user.getType()};
			count=db.executeUpdate(sql, obj);
		}
		return  count>0?true:false;
	}
	
	/**
	 * @func ͨ���û�����������
	 * @param username
	 * @return
	 * @throws SQLException
	 */
	public String findPwd(String username) throws SQLException{
		String pwd=null;
		db.connection(this.conn);
		String sql="select pwd  from users where username= ? ";
		Object obj[]={username};
		ResultSet rSet=db.executeQuery(sql,obj);
		if (rSet.next()) {
			pwd=rSet.getString("pwd");
		}else{
			pwd="";
		}
		return pwd;
	}
	
	/**
	 * @func ͨ���û�����ѯ�û�����
	 * @param username
	 * @return
	 * @throws SQLException
	 */
	public int findUserType(String username) throws SQLException{
		int type=0;
		db.connection(this.conn);
		String sql="select type  from users where username= ? ";
		Object obj[]={username};
		ResultSet rSet=db.executeQuery(sql,obj);
		if (rSet.next()) {
			type=rSet.getInt("type");
		}else{
			type=0;
		}
		return type;
	}
	
	/**
	 * @func ��ȡȫ���û���Ϣ
	 * @return
	 * @throws SQLException
	 */
	public List<User> getAllUserInfo() throws SQLException{
		List<User> users=new ArrayList<User>();
		db.connection(this.conn);
		String sql="select *  from users order by id";
		ResultSet rSet=db.executeQuery(sql);
		while (rSet.next()) {
			User user=new User();
			user.setNickName(rSet.getString("nickname"));
			user.setMoney(rSet.getInt("money"));
			user.setId(rSet.getInt("id"));
			user.setUserName(rSet.getString("username"));
			user.setPwd(rSet.getString("pwd"));
			user.setType(rSet.getInt("type"));
			users.add(user);
		}
		return users;
	}
	
	/**
	 * @func ͨ���û�����ȡ�û���Ϣ
	 * @param username
	 * @return
	 * @throws SQLException 
	 */
	public User getUserInfo(String username) throws SQLException{
		User user=new User();
		db.connection(this.conn);
		String sql="select *  from users where username= ? ";
		Object obj[]={username};
		ResultSet rSet=db.executeQuery(sql,obj);
		if (rSet.next()) {
			user.setNickName(rSet.getString("nickname"));
			user.setMoney(rSet.getInt("money"));
			user.setId(rSet.getInt("id"));
			user.setUserName(rSet.getString("username"));
			user.setPwd(rSet.getString("pwd"));
			user.setType(rSet.getInt("type"));
		}
		return user;
	}
}
