/**
 * @author ����־
 * @time 2014-8-21 ����07:15:09
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Toolkit;

import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Rectangle;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.neusoft.bean.Dining_table;
import com.neusoft.bean.Menu;
import com.neusoft.service.BookDinnerService;
import com.neusoft.service.ManageService;
import javax.swing.JButton;

/**
 * @author new
 *
 */
public class Manage extends JFrame {
	
	private AddWine aw=new AddWine();
	
	private AddMenu am=new AddMenu();

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JMenuBar jJMenuBar = null;

	private JMenu foodMenu = null;

	private JMenu squareAccountsMenu = null;

	private JMenu accountMenu = null;

	private JMenuItem queryMenuItem = null;

	private JMenuItem addMenuItem = null;

	private JMenuItem squareMenuItem = null;

	private JMenuItem daySalesMenuItem = null;

	private JMenuItem foodSalesMenuItem = null;

	private JLabel currentMenuLabel = null;

	private JLabel tableStateLabel = null;

	private JScrollPane menuScrollPane = null;

	private JTable menuShowTable = null;

	private JScrollPane tableScrollPane = null;

	private JTable tableStatTable = null;
	
	private DefaultTableModel dt=null;
	private DefaultTableModel dtable=null;
	private BookDinnerService bDS=new BookDinnerService();  //  @jve:decl-index=0:
	private ManageService ms=new ManageService();  //  @jve:decl-index=0:

	private JButton flushButton = null;

	private JLabel manageLabel = null;
	
	private String  manageName=null;

	private JMenu userInfoMenu = null;

	private JMenuItem queryUserMenuItem = null;

	private JMenuItem updateUserMenuItem = null;

	private JMenuItem addWineMenuItem = null;

	private JButton deleteButton = null;

	private JButton addMenuButton = null;

	private JButton addWineButton = null;

	private JButton updatePriceButton = null;

	private JButton shutButton = null;

	private JButton jButton = null;  //  @jve:decl-index=0:visual-constraint="1256,82"

	private JMenuItem orderMenuItem = null;

	/**
	 * This is the default constructor
	 */
	public Manage() {
		super();
		initialize();
	}
	
	public Manage(String manageName) {
		super();
		this.manageName=manageName;
		initialize();
		manageLabel.setText("��ǰ����Ա:"+this.manageName);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(1228, 711);
		this.setJMenuBar(getJJMenuBar());
		this.setContentPane(getJContentPane());
		this.setTitle("����Ա����");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			manageLabel = new JLabel();
			manageLabel.setBounds(new Rectangle(8, 3, 177, 30));
			manageLabel.setText("");
			tableStateLabel = new JLabel();
			tableStateLabel.setBounds(new Rectangle(829, 33, 287, 37));
			tableStateLabel.setHorizontalAlignment(SwingConstants.CENTER);
			tableStateLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			tableStateLabel.setText("����ʹ�����");
			currentMenuLabel = new JLabel();
			currentMenuLabel.setBounds(new Rectangle(13, 51, 135, 40));
			currentMenuLabel.setHorizontalAlignment(SwingConstants.CENTER);
			currentMenuLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			currentMenuLabel.setText("��ǰ�˵�");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(currentMenuLabel, null);
			jContentPane.add(tableStateLabel, null);
			jContentPane.add(getMenuScrollPane(), null);
			jContentPane.add(getTableScrollPane(), null);
			jContentPane.add(getFlushButton(), null);
			jContentPane.add(manageLabel, null);
			jContentPane.add(getDeleteButton(), null);
			jContentPane.add(getAddMenuButton(), null);
			jContentPane.add(getAddWineButton(), null);
			jContentPane.add(getUpdatePriceButton(), null);
			jContentPane.add(getShutButton(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			jJMenuBar.add(getFoodMenu());
			jJMenuBar.add(getSquareAccountsMenu());
			jJMenuBar.add(getAccountMenu());
			jJMenuBar.add(getUserInfoMenu());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes foodMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getFoodMenu() {
		if (foodMenu == null) {
			foodMenu = new JMenu();
			foodMenu.setText("           �˵�����          ");
			foodMenu.add(getQueryMenuItem());
			foodMenu.add(getAddMenuItem());
			foodMenu.add(getAddWineMenuItem());
			foodMenu.add(getOrderMenuItem());
		}
		return foodMenu;
	}

	/**
	 * This method initializes squareAccountsMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getSquareAccountsMenu() {
		if (squareAccountsMenu == null) {
			squareAccountsMenu = new JMenu();
			squareAccountsMenu.setText("          ���˹���          ");
			squareAccountsMenu.add(getSquareMenuItem());
		}
		return squareAccountsMenu;
	}

	/**
	 * This method initializes accountMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getAccountMenu() {
		if (accountMenu == null) {
			accountMenu = new JMenu();
			accountMenu.setText("         ͳ�ƹ���          ");
			accountMenu.add(getDaySalesMenuItem());
			accountMenu.add(getFoodSalesMenuItem());
		}
		return accountMenu;
	}

	/**
	 * This method initializes queryMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getQueryMenuItem() {
		if (queryMenuItem == null) {
			queryMenuItem = new JMenuItem();
			queryMenuItem.setText("       ��������");
			queryMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					ManageOrder mo=new ManageOrder();
					mo.setLocation(400, 200);
					mo.setVisible(true);
				}
			});
		}
		return queryMenuItem;
	}

	/**
	 * This method initializes addMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getAddMenuItem() {
		if (addMenuItem == null) {
			addMenuItem = new JMenuItem();
			addMenuItem.setText("       ���Ӳ���");
			addMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					AddMenu am=new AddMenu();
					am.setLocation(400, 200);
					am.setVisible(true);
				}
			});
		}
		return addMenuItem;
	}

	/**
	 * This method initializes squareMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getSquareMenuItem() {
		if (squareMenuItem == null) {
			squareMenuItem = new JMenuItem();
			squareMenuItem.setText("          ����");
			squareMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					SquareAccounts sa=new SquareAccounts();
					sa.setLocation(400, 200);
					sa.setVisible(true);
				}
			});
		}
		return squareMenuItem;
	}

	/**
	 * This method initializes daySalesMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getDaySalesMenuItem() { 
		if (daySalesMenuItem == null) {
			daySalesMenuItem = new JMenuItem();
			daySalesMenuItem.setText("Ӫҵ��ͳ��");
			daySalesMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					SalesCountByDate scb=new SalesCountByDate();
					scb.setLocation(400, 150);
					scb.setVisible(true);
				}
			});
		}
		return daySalesMenuItem;
	}

	/**
	 * This method initializes foodSalesMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getFoodSalesMenuItem() {
		if (foodSalesMenuItem == null) {
			foodSalesMenuItem = new JMenuItem();
			foodSalesMenuItem.setText("��������ͳ��");
			foodSalesMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("-----��������ͳ��-----"); // TODO Auto-generated Event stub actionPerformed()
					FoodSalesNum fsn=new FoodSalesNum();
					fsn.setLocation(400, 200);
					fsn.setVisible(true);
				}
			});
		}
		return foodSalesMenuItem;
	}

	/**
	 * This method initializes menuScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getMenuScrollPane() {
		if (menuScrollPane == null) {
			menuScrollPane = new JScrollPane();
			menuScrollPane.setBounds(new Rectangle(19, 92, 721, 505));
			menuScrollPane.setViewportView(getMenuShowTable());
		}
		return menuScrollPane;
	}

	/**
	 * This method initializes menuShowTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getMenuShowTable() {
		
		List<Menu> menus=new ArrayList<Menu>();
		menus=bDS.browseMenu();
		
		displayMenus(menus);
		
		if (menuShowTable == null) {
			menuShowTable = new JTable(dt);
			System.out.println("===================");
			menuShowTable.setRowHeight(32);
			menuShowTable.setRowSelectionInterval(0,0);
		}
		menuShowTable.setModel(dt);
		menuShowTable.revalidate();
		return menuShowTable;
	}
	
	public  void displayMenus(List<Menu> menus){
		String[] cols = {"�˱��","����","�۸�","����","ѡ��"};
		dt=new DefaultTableModel();
		dt.setColumnIdentifiers(cols);
		if(menuShowTable!=null)
			menuShowTable.removeAll();
		
		Iterator iter=menus.iterator();
		while(iter.hasNext()){
			Menu menu=new Menu();
			menu=(Menu)iter.next();
			String type="";
			/*������(1,��Ʒ\2,���\3,�ز�\4,��ˮ\5\��\6��ʳ\7.����)*/
			switch(menu.getMtype()){
			case 1:type="��ʳ";break;
			case 2:type="���";break;
			case 3:type="�ز�";break;
			case 4:type="��ˮ";break;
			case 5:type="��";break;
			case 6:type="��ʳ";break;
			case 7:type="����";break;
			default:type="�޷���";break;
			}
			//System.out.println(menu.getMid()+"\t"+menu.getMid()+"\t"+menu.getMname()+"\t"+menu.getMprice()+"\t"+type+"\t"+menu.getMpic());
			Object[] menuRow=new Object[]{menu.getMid()+"",menu.getMname(),
					menu.getMprice()+"",type,new Boolean(false)};
			dt.addRow(menuRow);
			
		}
	}
	private void displayTable(List<Dining_table> tables){
		String[] cols = {"����","��������","״̬"};
		dtable=new DefaultTableModel();
		dtable.setColumnIdentifiers(cols);
		if(tableStatTable!=null)
			tableStatTable.removeAll();
		Iterator<Dining_table> iter=tables.iterator();
		while(iter.hasNext()){
			Dining_table dt=new Dining_table();
			dt=(Dining_table)iter.next();
			String stat="";
			/*������(1,��Ʒ\2,���\3,�ز�\4,��ˮ\5\��\6��ʳ\7.����)*/
			switch(dt.getTstate()){
			case 1:stat="ʹ����";break;
			case 0:stat="����";break;
			default:stat="�޷���";break;
			}
			System.out.println(dt.getTid()+"\t"+stat);
			Object[] tableRow=new Object[]{dt.getTid()+"",dt.getPnum()+"��",stat};
			dtable.addRow(tableRow);
		}
	}

	/**
	 * This method initializes tableScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getTableScrollPane() {
		if (tableScrollPane == null) {
			tableScrollPane = new JScrollPane();
			tableScrollPane.setBounds(new Rectangle(781, 91, 413, 502));
			tableScrollPane.setViewportView(getTableStatTable());
		}
		return tableScrollPane;
	}

	/**
	 * This method initializes tableStatTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getTableStatTable() {
		List<Dining_table> tables=new ArrayList<Dining_table>();
		tables=ms.getTableStat();
		displayTable(tables);
		if (tableStatTable == null) {
			tableStatTable = new JTable(dtable);
			tableStatTable.setRowHeight(32);
		}
		tableStatTable.setModel(dtable);
		tableStatTable.revalidate();
		return tableStatTable;
	}

	/**
	 * This method initializes flushButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getFlushButton() {
		if (flushButton == null) {
			flushButton = new JButton();
			flushButton.setBounds(new Rectangle(658, 50, 80, 35));
			flushButton.setFont(new Font("Dialog", Font.BOLD, 18));
			flushButton.setText("ˢ��");
			flushButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					getMenuShowTable();
					getTableStatTable();
				}
			});
		}
		return flushButton;
	}

	/**
	 * This method initializes userInfoMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getUserInfoMenu() {
		if (userInfoMenu == null) {
			userInfoMenu = new JMenu();
			userInfoMenu.setText("        �û���Ϣ����         ");
			userInfoMenu.add(getQueryUserMenuItem());
			userInfoMenu.add(getUpdateUserMenuItem());
		}
		return userInfoMenu;
	}

	/**
	 * This method initializes queryUserMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getQueryUserMenuItem() {
		if (queryUserMenuItem == null) {
			queryUserMenuItem = new JMenuItem();
			queryUserMenuItem.setText("          �����û� ");
			queryUserMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					UserManage um=new UserManage(manageName);
					um.setLocation(300, 200);
					um.setVisible(true);
				}
			});
		}
		return queryUserMenuItem;
	}

	/**
	 * This method initializes updateUserMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getUpdateUserMenuItem() {
		if (updateUserMenuItem == null) {
			updateUserMenuItem = new JMenuItem();
			updateUserMenuItem.setText("          �����û�");
			updateUserMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("---�����û�---"); // TODO Auto-generated Event stub actionPerformed()
					AddUser au=new AddUser();
					au.setLocation(400, 200);
					au.setVisible(true);
				}
			});
		}
		return updateUserMenuItem;
	}

	/**
	 * This method initializes addWineMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getAddWineMenuItem() {
		if (addWineMenuItem == null) {
			addWineMenuItem = new JMenuItem();
			addWineMenuItem.setText("       ���Ӿ�ˮ");
			addWineMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					AddWine aw=new AddWine();
					aw.setLocation(400, 200);
					aw.setVisible(true);
				}
			});
		}
		return addWineMenuItem;
	}

	/**
	 * This method initializes deleteButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getDeleteButton() {
		if (deleteButton == null) {
			deleteButton = new JButton();
			deleteButton.setBounds(new Rectangle(559, 50, 83, 35));
			deleteButton.setFont(new Font("Dialog", Font.BOLD, 18));
			deleteButton.setText("ɾ��");
			deleteButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int x=menuShowTable.getSelectedRow();
					if(x!=-1){
						String menuName=menuShowTable.getValueAt(menuShowTable.getSelectedRow(), 1)+"";
						Menu menu=new Menu();
						menu.setMname(menuName);
						int count=ms.deleteMenu(menu);
						if(count>0){
							JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
							
						}else{
							JOptionPane.showMessageDialog(null, "ɾ��ʧ��");
						}
						getMenuShowTable();
					}else{
						JOptionPane.showMessageDialog(null, "����û��ѡ��ʳ��");
					}
				}
			});
		}
		return deleteButton;
	}

	/**
	 * This method initializes addMenuButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getAddMenuButton() {
		if (addMenuButton == null) {
			addMenuButton = new JButton();
			addMenuButton.setBounds(new Rectangle(165, 50, 116, 35));
			addMenuButton.setFont(new Font("Dialog", Font.BOLD, 18));
			addMenuButton.setText("��������");
			addMenuButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					am.setLocation(400, 200);
					am.setVisible(true);
				}
			});
		}
		return addMenuButton;
	}

	/**
	 * This method initializes addWineButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getAddWineButton() {
		if (addWineButton == null) {
			addWineButton = new JButton();
			addWineButton.setBounds(new Rectangle(299, 49, 116, 35));
			addWineButton.setFont(new Font("Dialog", Font.BOLD, 18));
			addWineButton.setText("������ˮ");
			addWineButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					aw.setLocation(400, 200);
					aw.setVisible(true);
				}
			});
		}
		return addWineButton;
	}

	/**
	 * This method initializes updatePriceButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getUpdatePriceButton() {
		if (updatePriceButton == null) {
			updatePriceButton = new JButton();
			updatePriceButton.setBounds(new Rectangle(430, 50, 116, 35));
			updatePriceButton.setFont(new Font("Dialog", Font.BOLD, 18));
			updatePriceButton.setText("���¼۸�");
			updatePriceButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int x=menuShowTable.getSelectedRow();
					if(x!=-1){
						String menuName=menuShowTable.getValueAt(x, 1)+"";
						System.out.println("menuName:"+menuName);
						updatePrice up=new updatePrice(menuName);
						up.setLocation(400, 200);
						up.setVisible(true);
					}else{
						JOptionPane.showMessageDialog(null, "����û��ѡ��ʳ��");
					}
					
				}
			});
		}
		return updatePriceButton;
	}

	/**
	 * This method initializes shutButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getShutButton() {
		if (shutButton == null) {
			shutButton = new JButton();
			shutButton.setBounds(new Rectangle(1125, 33, 87, 37));
			shutButton.setFont(new Font("Dialog", Font.BOLD, 18));
			shutButton.setText("����");
			shutButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					ms.shutdown();
				}
			});
		}
		return shutButton;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
		}
		return jButton;
	}

	/**
	 * This method initializes orderMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getOrderMenuItem() {
		if (orderMenuItem == null) {
			orderMenuItem = new JMenuItem();
			orderMenuItem.setText("        �������");
			orderMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					FirstPage_1 fp=new FirstPage_1();
					
					fp.setLocation(200, 200);
					fp.setVisible(true);
				}
			});
		}
		return orderMenuItem;
	}

}  //  @jve:decl-index=0:visual-constraint="63,10"
