/**
 * @author ����־
 * @time 2014-8-19 ����06:54:21
 * @func count_table����ʵ���ϵӳ��
 * 
 */
package com.neusoft.bean;

/**
 * @author new
 *
 */
public class CountTable {
	private int cid;
	private int mid;
	private String date;
	private int mnum;
	/**
	 * @return the cid
	 */
	public int getCid() {
		return cid;
	}
	/**
	 * @param cid the cid to set
	 */
	public void setCid(int cid) {
		this.cid = cid;
	}
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/**
	 * @return the mid
	 */
	public int getMid() {
		return mid;
	}
	/**
	 * @param mid the mid to set
	 */
	public void setMid(int mid) {
		this.mid = mid;
	}
	/**
	 * @return the mnum
	 */
	public int getMnum() {
		return mnum;
	}
	/**
	 * @param mnum the mnum to set
	 */
	public void setMnum(int mnum) {
		this.mnum = mnum;
	}
	
}
/*cid	number
mid	number(3)
orderdate	date
mnum	number(1)

*/