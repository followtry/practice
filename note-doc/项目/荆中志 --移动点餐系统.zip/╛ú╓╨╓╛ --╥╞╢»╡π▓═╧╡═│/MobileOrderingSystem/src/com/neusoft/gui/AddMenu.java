/**
 * @author ����־
 * @time 2014-8-21 ����08:29:10
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

import com.neusoft.bean.Menu;
import com.neusoft.service.BookDinnerService;
import com.neusoft.service.ManageService;

/**
 * @author new
 *
 */
public class AddMenu extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel addFoodLabel = null;

	private JLabel foodNameLabel = null;

	private JLabel foodTypeLabel = null;

	private JLabel foodPriceLabel = null;

	private JLabel foodPicLabel = null;

	private JTextField foodNameTextField = null;

	private JTextField foodPriceTextField = null;

	private JTextField foodPicTextField = null;

	private JComboBox foodTypeComboBox = null;

	private JButton cancelButton = null;

	private JButton okButton = null;

	/**
	 * This is the default constructor
	 */
	public AddMenu() {
		super();
		initialize();
	}
	
	public void close(){
		this.setVisible(false);
		//this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(437, 422);
		this.setContentPane(getJContentPane());
		this.setTitle("���Ӳ˵�������");
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			foodPicLabel = new JLabel();
			foodPicLabel.setBounds(new Rectangle(33, 255, 137, 37));
			foodPicLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			foodPicLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			foodPicLabel.setText("����ͼƬ:");
			foodPriceLabel = new JLabel();
			foodPriceLabel.setBounds(new Rectangle(33, 135, 137, 33));
			foodPriceLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			foodPriceLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			foodPriceLabel.setText("���ȼ۸�:");
			foodTypeLabel = new JLabel();
			foodTypeLabel.setBounds(new Rectangle(33, 195, 137, 33));
			foodTypeLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			foodTypeLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			foodTypeLabel.setText("��������:");
			foodNameLabel = new JLabel();
			foodNameLabel.setBounds(new Rectangle(33, 75, 137, 33));
			foodNameLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			foodNameLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			foodNameLabel.setText("��������:");
			addFoodLabel = new JLabel();
			addFoodLabel.setBounds(new Rectangle(31, 20, 362, 34));
			addFoodLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			addFoodLabel.setHorizontalAlignment(SwingConstants.CENTER);
			addFoodLabel.setText("���Ӳ���");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(addFoodLabel, null);
			jContentPane.add(foodNameLabel, null);
			jContentPane.add(foodTypeLabel, null);
			jContentPane.add(foodPriceLabel, null);
			jContentPane.add(foodPicLabel, null);
			jContentPane.add(getFoodNameTextField(), null);
			jContentPane.add(getFoodPriceTextField(), null);
			jContentPane.add(getFoodPicTextField(), null);
			jContentPane.add(getFoodTypeComboBox(), null);
			jContentPane.add(getCancelButton(), null);
			jContentPane.add(getOkButton(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes foodNameTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getFoodNameTextField() {
		if (foodNameTextField == null) {
			foodNameTextField = new JTextField();
			foodNameTextField.setBounds(new Rectangle(191, 75, 154, 33));
		}
		return foodNameTextField;
	}

	/**
	 * This method initializes foodPriceTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getFoodPriceTextField() {
		if (foodPriceTextField == null) {
			foodPriceTextField = new JTextField();
			foodPriceTextField.setBounds(new Rectangle(191, 135, 154, 33));
		}
		return foodPriceTextField;
	}

	/**
	 * This method initializes foodPicTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getFoodPicTextField() {
		if (foodPicTextField == null) {
			foodPicTextField = new JTextField();
			foodPicTextField.setBounds(new Rectangle(191, 255, 154, 33));
		}
		return foodPicTextField;
	}

	/**
	 * This method initializes foodTypeComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getFoodTypeComboBox() {
		if (foodTypeComboBox == null) {
			foodTypeComboBox = new JComboBox();
			addfoodTypeItem();
			foodTypeComboBox.setBounds(new Rectangle(191, 195, 154, 33));
		}
		return foodTypeComboBox;
	}
	
	private void addfoodTypeItem(){
		foodTypeComboBox.addItem("");
		foodTypeComboBox.addItem("��ʳ");
		foodTypeComboBox.addItem("��ʳ");
		foodTypeComboBox.addItem("��ʳ");
		//foodTypeComboBox.addItem("��ʳ");
		foodTypeComboBox.addItem("��");
		foodTypeComboBox.addItem("��ʳ");
		foodTypeComboBox.addItem("����");
	}

	/**
	 * This method initializes cancelButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setBounds(new Rectangle(58, 322, 124, 36));
			cancelButton.setFont(new Font("Dialog", Font.BOLD, 18));
			cancelButton.setText("ȡ��");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					close();
					
				}
			});
		}
		return cancelButton;
	}

	/**
	 * This method initializes okButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setBounds(new Rectangle(221, 322, 124, 36));
			okButton.setFont(new Font("Dialog", Font.BOLD, 18));
			okButton.setText("����");
			okButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addMenu();
				}
			});
		}
		return okButton;
	}
	
	
	public void addMenu(){
		ManageService ms=new ManageService();
		BookDinnerService bds=new BookDinnerService();
		Menu menu=new Menu();
		//�жϲ˵����Ƿ������ӵĲ�
		menu=bds.browseMenuByName(foodNameTextField.getText());
		if(menu.getMid()==0){
			int type=0;
			String tmp=foodTypeComboBox.getSelectedItem()+"";
			if(tmp.equals("")){
				System.out.println("���ʹ���");
			}else if(tmp.equals("��ʳ")){
				type=1;
			}else if(tmp.equals("��ʳ")){
				type=2;
			}else if(tmp.equals("��ʳ")){
				type=3;
			}else if(tmp.equals("��ʳ")){
				type=6;
			}else if(tmp.equals("��")){
				type=5;
			}else if(tmp.equals("����")){
				type=7;
			}
			int mid=ms.getMaxMenuId()+1;
			menu.setMid(mid);
			String mname=foodNameTextField.getText();
			String mprice=foodPriceTextField.getText();
			if(!mname.equals("")&&!mprice.equals("")&&foodTypeComboBox.getSelectedIndex()>0){
				Pattern p = Pattern.compile("(^[0-9]{3})|(^[0-9]{2})|(^[0-9]{1})");  
				Matcher m = p.matcher(mprice);
				if(m.matches()==true){
					menu.setMname(mname);
					menu.setMprice(Integer.parseInt(mprice+""));
					System.err.println("mprice :"+mprice);
					menu.setMtype(type);
					menu.setMpic(foodPicTextField.getText());
					ms.addMenu(menu);
					JOptionPane.showMessageDialog(null, mname+" ���ӳɹ�!");
				}else{
					JOptionPane.showMessageDialog(null, mname+" �۸���1-999֮��!");
				}
				
			}else{
				JOptionPane.showMessageDialog(null, "�뽫������д����,ͼƬ���Բ���");
			}
			System.out.println("-"+tmp+"---"+type);
		}else{
			JOptionPane.showMessageDialog(null, "���Ѿ�����!");
		}
	}

}  //  @jve:decl-index=0:visual-constraint="335,8"
