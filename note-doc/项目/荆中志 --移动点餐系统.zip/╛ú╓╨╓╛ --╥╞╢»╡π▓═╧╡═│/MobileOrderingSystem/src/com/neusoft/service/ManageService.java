/**
 * @author ����־
 * @time 2014-8-21 ����07:40:30
 * @func 
 * 
 */
package com.neusoft.service;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import com.neusoft.bean.Dining_table;
import com.neusoft.bean.Menu;
import com.neusoft.dao.BookDinnerDao;
import com.neusoft.dao.ManageDao;
import com.neusoft.jdbc.DBConn;

/**
 * @author new
 *
 */
public class ManageService {
	
	private Connection conn;
	
	private DBConn db=new DBConn();
	
	
	
	/**
	 * @func �˲�\�˾�  Ĭ������Ϊ1(�ѶԷ�һ�����������д���)
	 * @param menu
	 * @param dt
	 * @param num
	 * @return int
	 * @throws SQLException
	 */
	public int deleteOrderForm(String menuName,Dining_table dt) {
		int count=0;
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			BookDinnerService bds=new BookDinnerService();
			Menu menu=new Menu();
			menu=bds.browseMenuByName(menuName);
			count=md.deleteOrderForm(menu, dt);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	
	
	
	/**
	 * @func ��ȡһ�����ܵ����۶�(�����ʽ:2014-8)
	 * @param day
	 * @return
	 * @throws SQLException
	 */
	public long getSalesTotleMoneyOfMonth(String beginMonth,String endMonth){
		long count=0;
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			count = md.getSalesTotleMoneyOfMonth(beginMonth,endMonth);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return count;
	}
	
	/**
	 * @throws SQLException 
	 * @func ���²�ѯ���۶�(�����ʽ:2014-8)
	 * @return ResultSet
	 *
	 */
	public List<Object[]>   queryByMonth(String beginMonth,String endMonth){
		ResultSet rs=null;
		List<Object[]> lists=new ArrayList<Object[]>();
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			rs=md.queryByMonth(beginMonth,endMonth);
			while(rs.next()){
				Object newRow[]={rs.getInt("�˱��"),rs.getString("����"),
						rs.getInt("�˼�"),rs.getInt("����"),rs.getInt("�����۶�")};
				lists.add(newRow);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return lists;
	}
	
	/**
	 * @throws SQLException 
	 * @func ���ղ�ѯ���۶�(�����ʽ:2014-8)
	 * @return ResultSet
	 *
	 */
	public List<Object[]>   queryByDay(String day){
		ResultSet rs=null;
		
		List<Object[]> lists=new ArrayList<Object[]>();
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			rs=md.queryByDay(day);
			while(rs.next()){
				Object newRow[]={rs.getInt("�˱��"),rs.getString("����"),
						rs.getInt("�˼�"),rs.getInt("����"),rs.getInt("�����۶�")};
				lists.add(newRow);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return lists;
	}
	
	
	
	/**
	 * @func ��ȡһ���ܵ����۶�(��������ڸ�ʽ:2014-5-6)
	 * @param day
	 * @return long
	 * @throws SQLException
	 */
	public long getSalesTotleMoneyOfDay(String day){
		long count=0;
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			count=md.getSalesTotleMoneyOfDay(day);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return count;
	}
	
	/**
	 * @func ���ÿ���˵�����
	 * @return
	 * @throws SQLException
	 */
	public List<Menu> getSalesVolume(){
		List<Menu> menus=new ArrayList<Menu>();
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			ResultSet rs=md.getSalesVolume();
			while(rs.next()){
				Menu menu=new Menu();
				
				menu.setMname(rs.getString("����"));
				menu.setMprice(rs.getInt("�۸�"));
				menu.setMnum(rs.getInt("����"));
				menu.setMid(rs.getInt("�˱��"));
				menu.setMtype(rs.getInt("������"));
				System.out.println(menu.getMname()+"\t"+menu.getMprice()+"\t"+menu.getMnum());
				menus.add(menu);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return menus;
	}
	
	/**
	 * @func ����ĳ���Ĳ��ȴ���״̬ 
	 * @param dt
	 * @param menu
	 * @param oldStat
	 * @param newStat
	 * @return	int
	 * @throws SQLException
	 */
	public int updateMenuState(Dining_table dt,Menu menu ,int oldStat,int newStat){
		int count=0;
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			db.startTransaction();
			count = md.updateMenuState(dt, menu, oldStat, newStat);
			if(count>0){
				db.commit();
			}else{
				db.roolback();
			}
		} catch (ClassNotFoundException e) {
			System.out.println("--updateMenuState--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("--updateMenuState--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	
	/**
	 * @func �鿴�����Ƿ���ʹ����
	 * @return
	 */
	public List<Dining_table> getTableStat(){
		List<Dining_table> tables=new ArrayList<Dining_table>();
		try {
			this.conn=db.connection();
			ManageDao mdao=new ManageDao(this.conn);
			ResultSet rs=mdao.getTableStat();
			while(rs.next()){
				Dining_table dt=new Dining_table();
				//tid,pnum,tstate
				dt.setTid(rs.getInt("tid"));
				dt.setPnum(rs.getInt("pnum"));
				dt.setTstate(rs.getInt("tstate"));
				tables.add(dt);
			}
		} catch (ClassNotFoundException e) {
			System.out.println("--getTableStat--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("--getTableStat--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return tables;
	}
	
	/**
	 * @func �˵��ϼӲ�
	 * @param menu
	 * @return
	 * @throws SQLException 
	 */
	public int  addMenu(Menu menu){
		int count=0;
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			count=md.addMenu(menu);
		} catch (ClassNotFoundException e) {
			System.out.println("--addMenu--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("--addMenu--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	
	/**
	 * @func ��ȡ���Ĳ��ȱ��
	 * @return
	 * @throws SQLException 
	 */
	public int getMaxMenuId(){
		int num=0;
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			num=md.getMaxMenuId();
		} catch (ClassNotFoundException e) {
			System.out.println("--getMaxMenuId--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("--getMaxMenuId--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return num;
	}
	
	/**
	 * @func �˵���ɾ��
	 * @param mneu
	 * @return
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public int  deleteMenu(Menu menu){
		int count=0;
		try {
			this.conn=db.connection();
			
			ManageDao md=new ManageDao(this.conn);
			count=md.deleteMenu(menu);
		} catch (ClassNotFoundException e) {
			System.out.println("--deleteMenu--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("--deleteMenu--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	
	/**
	 * @func ���²˼�
	 * @param menu
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public int updateMenuPrice(Menu menu){
		int count=0;
		try {
			this.conn=db.connection();
			
			ManageDao md=new ManageDao(this.conn);
			count=md.updateMenuPrice(menu);
		} catch (ClassNotFoundException e) {
			System.out.println("--deleteMenu--ClassNotFound-");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("--deleteMenu--SQLException-");
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	
	/**
	 * @��ĳ���Ѿ����ѵļ�¼���ӵ�ͳ�Ʊ���(�Ѿ����ѵ���ƷalreadyCostGoods,���ӵ�ͳ�Ʊ�)
	 * @param dt
	 * @return
	 */
	public int appendCountTable(Dining_table dt ){
		int count=0;
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			ResultSet rset=md.getAlreadyConsumeRecord(dt);
			count=md.appendCountTable(rset);
		} catch (SQLException e) {
			System.out.println("--appendCountTable--SQLException--");
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			System.out.println("--appendCountTable--ClassNotFound--");
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return count;
	}
	
	/**
	 * @func ����(��ն���,��������)
	 * @param dt
	 * @return 
	 */
	public int squareAccounts(Dining_table dt){
		int count=0;
		/*ResultSet rset;*/
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			/*rset=md.getAllConsumeRecord(dt);*/
			count=md.cleanOrder(dt);
			System.out.println("�����Ѿ����");
			if(count>0){
				count=md.cleanTable(dt);
				System.out.println("�����������");
			}else{
				count=0;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
		
	}
	
	/**
	 * @func �Ƶ����(�������в����Ͷ���)
	 * @return
	 * @throws SQLException 
	 */
	public int shutdown() {
		int count=0;
		try {
			this.conn=db.connection();
			ManageDao md=new ManageDao(this.conn);
			count = md.cleanAllOrder();
			if(count>0){
				count=md.cleanAllTable();
				if(count>0){
					JOptionPane.showMessageDialog(null, "���������ɹ�");
				}else{
					JOptionPane.showMessageDialog(null, "������δ����");
				}
			}else{
				JOptionPane.showMessageDialog(null, "����δ�����ɹ��������Ѿ����");
			}
		} catch (HeadlessException e) {
			System.out.println("-------shutdown-------------HeadlessException-----------");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("-------shutdown-------------ClassNotFoundException-----------");
			e.printStackTrace();
		}catch (SQLException e) {
			System.out.println("-------shutdown-------------SQLException-----------");
			e.printStackTrace();
		}finally{
			try {
				db.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return count;
	}
	
}
