/**
 * @author ����־
 * @time 2014-8-22 ����07:47:08
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Rectangle;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.SwingConstants;

import com.neusoft.bean.Menu;
import com.neusoft.service.BookDinnerService;
import com.neusoft.service.ManageService;

/**
 * @author new
 *
 */
public class AddWine extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel addWineLabel = null;

	private JLabel wineNameLabel = null;

	private JLabel winePriceLabel = null;

	private JTextField wineNameTextField = null;

	private JTextField winePriceTextField = null;

	private JButton cancelButton = null;

	private JButton okButton = null;

	private JLabel winePicLabel = null;

	private JTextField winePicTextField = null;

	/**
	 * This is the default constructor
	 */
	public AddWine() {
		super();
		initialize();
	}

	public void close(){
		this.setVisible(false);
		//this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setContentPane(getJContentPane());
		this.setTitle("���Ӿ�ˮ");
		this.setBounds(new Rectangle(0, 0, 437, 422));
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			winePicLabel = new JLabel();
			winePicLabel.setBounds(new Rectangle(28, 237, 122, 37));
			winePicLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			winePicLabel.setHorizontalAlignment(SwingConstants.CENTER);
			winePicLabel.setText("Ԥ��ͼ:");
			winePriceLabel = new JLabel();
			winePriceLabel.setBounds(new Rectangle(27, 170, 125, 37));
			winePriceLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			winePriceLabel.setHorizontalAlignment(SwingConstants.CENTER);
			winePriceLabel.setText("�ۼ�:");
			wineNameLabel = new JLabel();
			wineNameLabel.setBounds(new Rectangle(27, 100, 125, 37));
			wineNameLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			wineNameLabel.setHorizontalAlignment(SwingConstants.CENTER);
			wineNameLabel.setText("����:");
			addWineLabel = new JLabel();
			addWineLabel.setBounds(new Rectangle(89, 19, 253, 51));
			addWineLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			addWineLabel.setHorizontalAlignment(SwingConstants.CENTER);
			addWineLabel.setText("���Ӿ�ˮ");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(addWineLabel, null);
			jContentPane.add(wineNameLabel, null);
			jContentPane.add(winePriceLabel, null);
			jContentPane.add(getWineNameTextField(), null);
			jContentPane.add(getWinePriceTextField(), null);
			jContentPane.add(getCancelButton(), null);
			jContentPane.add(getOkButton(), null);
			jContentPane.add(winePicLabel, null);
			jContentPane.add(getWinePicTextField(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes wineNameTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getWineNameTextField() {
		if (wineNameTextField == null) {
			wineNameTextField = new JTextField();
			wineNameTextField.setBounds(new Rectangle(165, 100, 195, 37));
		}
		return wineNameTextField;
	}

	/**
	 * This method initializes winePriceTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getWinePriceTextField() {
		if (winePriceTextField == null) {
			winePriceTextField = new JTextField();
			winePriceTextField.setBounds(new Rectangle(165, 170, 195, 37));
		}
		return winePriceTextField;
	}

	/**
	 * This method initializes cancelButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setBounds(new Rectangle(33, 291, 134, 41));
			cancelButton.setFont(new Font("Dialog", Font.BOLD, 18));
			cancelButton.setText("ȡ��");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					close();
				}
			});
		}
		return cancelButton;
	}

	/**
	 * This method initializes okButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setBounds(new Rectangle(206, 292, 122, 42));
			okButton.setFont(new Font("Dialog", Font.BOLD, 18));
			okButton.setText("����");
			okButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					addWine();
				}
			});
		}
		return okButton;
	}
	
	private void addWine(){
		ManageService ms=new ManageService();
		BookDinnerService bds=new BookDinnerService();
		Menu menu=new Menu();
		
		//�жϾ��Ƿ����
		menu=bds.browseMenuByName(wineNameTextField.getText());
		if(menu.getMid()==0){
			int type=4;
		
			int mid=ms.getMaxMenuId()+1;
			menu.setMid(mid);
			String mname=wineNameTextField.getText();
			String mprice=winePriceTextField.getText();
			if(!mname.equals("")&&!mprice.equals("")){
				
				Pattern p = Pattern.compile("(^[0-9]{3})|(^[0-9]{2})|(^[0-9]{1})");  
				Matcher m = p.matcher(mprice);  
				if(m.matches()==true){
					menu.setMname(mname);
					menu.setMprice(Integer.parseInt(mprice));
					menu.setMtype(type);
					menu.setMpic(winePicTextField.getText());
					ms.addMenu(menu);
					JOptionPane.showMessageDialog(null, mname+" ���ӳɹ�!");
				}else{
					JOptionPane.showMessageDialog(null, mname+" �۸���1-999֮��!");
				}
				
			}else{
				JOptionPane.showMessageDialog(null, "�뽫������д����,ͼƬ���Բ���");
			}
			
			
			System.out.println("----"+type);
		}else{
			JOptionPane.showMessageDialog(null, "���Ѿ�����!");
		}
	}

	/**
	 * This method initializes winePicTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getWinePicTextField() {
		if (winePicTextField == null) {
			winePicTextField = new JTextField();
			winePicTextField.setBounds(new Rectangle(165, 237, 195, 37));
		}
		return winePicTextField;
	}


}  //  @jve:decl-index=0:visual-constraint="458,34"
