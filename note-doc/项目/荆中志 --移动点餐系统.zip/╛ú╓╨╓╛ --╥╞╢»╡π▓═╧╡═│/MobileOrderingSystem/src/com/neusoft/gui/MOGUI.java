/**
 * @author ����־
 * @time 2014-8-19 ����04:22:17
 * @func �ƶ����ϵͳ�׽���
 * 
 */
package com.neusoft.gui;

import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Point;
import javax.swing.JButton;

/**
 * @author new
 *
 */
public class MOGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JLabel OSTitle = null;
	private JButton In = null;
	private JButton Out = null;

	/**
	 * This is the default constructor
	 */
	public MOGUI() {
		super();
		initialize();
	}
	
	public void close(){
		this.setVisible(false);
		
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
	
		
		this.setSize(384, 283);
		this.setContentPane(getJContentPane());
		this.setTitle("��ӭ��");
		this.setLocation(400, 200);
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			OSTitle = new JLabel();
			OSTitle.setBounds(new Rectangle(53, 13, 280, 69));
			OSTitle.setFont(new Font("Dialog", Font.BOLD, 24));
			OSTitle.setHorizontalAlignment(SwingConstants.CENTER);
			OSTitle.setForeground(new Color(210, 37, 86));
			OSTitle.setText("��ӭʹ���ƶ����ϵͳ");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.setBackground(new Color(204, 255, 204));
			jContentPane.add(OSTitle, null);
			jContentPane.add(getIn(), null);
			jContentPane.add(getOut(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes In	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getIn() {
		if (In == null) {
			In = new JButton();
			In.setLocation(new Point(56, 99));
			In.setText("������ϵͳ");
			In.setFont(new Font("Dialog", Font.BOLD, 24));
			In.setSize(new Dimension(264, 56));
			In.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Login login=new Login();
					int w = (Toolkit.getDefaultToolkit().getScreenSize().width-login.WIDTH)/3;
					int h = (Toolkit.getDefaultToolkit().getScreenSize().height-login.HEIGHT)/4;
					//System.out.println("W:"+w+"  h:"+h);
					
					login.setLocation(w, h);
					login.setVisible(true);
					close();
				}
			});
		}
		return In;
	}

	/**
	 * This method initializes Out	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOut() {
		if (Out == null) {
			Out = new JButton();
			Out.setBounds(new Rectangle(57, 168, 264, 60));
			Out.setFont(new Font("Dialog", Font.BOLD, 24));
			Out.setText("�˳�ϵͳ");
			Out.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.exit(0);
				}
			});
		}
		return Out;
	}

}  //  @jve:decl-index=0:visual-constraint="152,32"
