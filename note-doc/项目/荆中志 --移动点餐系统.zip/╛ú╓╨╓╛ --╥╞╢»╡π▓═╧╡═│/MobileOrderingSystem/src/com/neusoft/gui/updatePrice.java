/**
 * @author ����־
 * @time 2014-8-22 ����09:38:10
 * @func 
 * 
 */
package com.neusoft.gui;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;

import com.neusoft.bean.Menu;
import com.neusoft.service.BookDinnerService;
import com.neusoft.service.ManageService;

/**
 * @author new
 *
 */
public class updatePrice extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel jLabel = null;

	private JLabel foodNameLabel1 = null;

	private JLabel nameLabel1 = null;

	private JLabel oldPriceLabel1 = null;

	private JLabel oldpriceLabel1 = null;

	private JLabel newPriceLabel1 = null;

	private JTextField newPriceTextField = null;

	private JButton cancelButton = null;

	private JButton okButton = null;
	
	private String menuName="";  //  @jve:decl-index=0:
	
	private BookDinnerService  bds=new BookDinnerService();  //  @jve:decl-index=0:

	/**
	 * This is the default constructor
	 */
	public updatePrice() {
		super();
		initialize();
	}
	
	public updatePrice(String menuName) {
		super();
		this.menuName=menuName;
		Menu menu=new Menu();
		menu=bds.browseMenuByName(this.menuName);
		initialize();
		if(menu.getMid()>0){
			System.out.println("--------------"+menu.getMname());
			nameLabel1.setText(menu.getMname());
			oldpriceLabel1.setText(menu.getMprice()+"Ԫ");
		}
	}

	
	private void close(){
		this.setVisible(false);
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(334, 383);
		this.setContentPane(getJContentPane());
		this.setTitle("���¼۸�");
		this.setResizable(false);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			newPriceLabel1 = new JLabel();
			newPriceLabel1.setBounds(new Rectangle(25, 185, 96, 30));
			newPriceLabel1.setFont(new Font("Dialog", Font.BOLD, 18));
			newPriceLabel1.setHorizontalAlignment(SwingConstants.CENTER);
			newPriceLabel1.setText("�¼۸�:");
			oldpriceLabel1 = new JLabel();
			oldpriceLabel1.setBounds(new Rectangle(134, 125, 125, 30));
			oldpriceLabel1.setText("");
			oldPriceLabel1 = new JLabel();
			oldPriceLabel1.setBounds(new Rectangle(25, 125, 96, 30));
			oldPriceLabel1.setFont(new Font("Dialog", Font.BOLD, 18));
			oldPriceLabel1.setHorizontalAlignment(SwingConstants.CENTER);
			oldPriceLabel1.setText("ԭ�۸�:");
			nameLabel1 = new JLabel();
			nameLabel1.setBounds(new Rectangle(134, 65, 125, 30));
			nameLabel1.setText("");
			foodNameLabel1 = new JLabel();
			foodNameLabel1.setBounds(new Rectangle(25, 65, 96, 30));
			foodNameLabel1.setFont(new Font("Dialog", Font.BOLD, 18));
			foodNameLabel1.setHorizontalAlignment(SwingConstants.CENTER);
			foodNameLabel1.setText("����:");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(34, 12, 257, 35));
			jLabel.setFont(new Font("Dialog", Font.BOLD, 18));
			jLabel.setHorizontalAlignment(SwingConstants.CENTER);
			jLabel.setText("���¼۸�");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(jLabel, null);
			jContentPane.add(foodNameLabel1, null);
			jContentPane.add(nameLabel1, null);
			jContentPane.add(oldPriceLabel1, null);
			jContentPane.add(oldpriceLabel1, null);
			jContentPane.add(newPriceLabel1, null);
			jContentPane.add(getNewPriceTextField(), null);
			jContentPane.add(getCancelButton(), null);
			jContentPane.add(getOkButton(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes newPriceTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getNewPriceTextField() {
		if (newPriceTextField == null) {
			newPriceTextField = new JTextField();
			newPriceTextField.setBounds(new Rectangle(134, 185, 125, 30));
		}
		return newPriceTextField;
	}

	/**
	 * This method initializes cancelButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = new JButton();
			cancelButton.setBounds(new Rectangle(25, 245, 98, 40));
			cancelButton.setText("ȡ��");
			cancelButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					close();
				}
			});
		}
		return cancelButton;
	}

	/**
	 * This method initializes okButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOkButton() {
		if (okButton == null) {
			okButton = new JButton();
			okButton.setBounds(new Rectangle(134, 245, 100, 40));
			okButton.setText("����");
			okButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					ManageService ms=new ManageService();
					Menu menu=new Menu();
					System.out.println("***************"+newPriceTextField.getText());
					String mprice=newPriceTextField.getText();
					Pattern p = Pattern.compile("(^[0-9]{3})|(^[0-9]{2})|(^[0-9]{1})");  
					Matcher m = p.matcher(mprice);  
					if(m.matches()==true){
						int price =Integer.parseInt(mprice);
						menu.setMname(menuName);
						menu.setMprice(price);
						int count=ms.updateMenuPrice(menu);
						if(count>0){
							JOptionPane.showMessageDialog(null, "�۸���³ɹ�");
							close();
						}else{
							JOptionPane.showMessageDialog(null, "�۸����ʧ��");
						}
					}else{
						JOptionPane.showMessageDialog(null, "�¼۸��������,��1-999֮��!");
					}
					
					
				}
			});
		}
		return okButton;
	}

}  //  @jve:decl-index=0:visual-constraint="259,27"
