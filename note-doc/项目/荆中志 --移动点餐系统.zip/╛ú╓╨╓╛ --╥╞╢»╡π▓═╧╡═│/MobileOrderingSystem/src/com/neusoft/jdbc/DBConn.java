/**
 * @time  2014-8-18 ����06:10:19
 * @author new
 * @function ���ݿ������,�����ֲ������ݿ�ķ���
 * 
 */
package com.neusoft.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 
 */
public class DBConn {
	private Connection conn;
	private PreparedStatement pStatement;
	
	/**
	 * @func �������ݿ�
	 * @return conn
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public Connection connection() throws ClassNotFoundException, SQLException{
		String oracleDriver="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@10.25.117.10:1521:oracle";
		String user="jing";
		String password="jing";
		
		Class.forName(oracleDriver);
		System.out.println("���������ɹ�");
		conn=DriverManager.getConnection(url,user,password);
		System.out.println("�������ݿ�ɹ�");
		
		return conn;
	}
	
	/**
	 * @func ��֤�ڴ�������ʱ��connΪͬһ��
	 * @param conn
	 * @return this.conn
	 */
	public Connection connection(Connection conn) {
		this.conn=conn;
		return this.conn;
	}
	
	/**
	 * @func �ر����ݿ⼰������Ҫ�رյ�ѡ��
	 * @throws SQLException
	 */
	public void close() throws SQLException {
		if (pStatement!=null) {
			pStatement.close();
			System.out.println("pStatement�Ѿ��ر�");
		}
		if (conn!=null) {
			conn.close();
			System.out.println("conn�Ѿ��ر�");
		}
		
	}
	
	/**
	 * @func �������ݿ����
	 * @param sql
	 * @return count
	 * @throws SQLException
	 */
	public int executeUpdate(String sql) throws SQLException {
		int  count=0;
		//System.out.println(sql);
		pStatement=conn.prepareStatement(sql);
		count=pStatement.executeUpdate();
		//System.out.println("�������ݳɹ�1");
		return count;
	}
	
	/**
	 * @func ͨ�������������ݿ�
	 * @param sql
	 * @param obj
	 * @return
	 * @throws SQLException
	 */
	public int executeUpdate(String sql,Object obj[]) throws SQLException {
		int  count=0;
		//System.out.println(sql);
		pStatement=conn.prepareStatement(sql);
		if (obj!=null) {
			for (int i = 0; i < obj.length; i++) {
				pStatement.setObject(i+1, obj[i]);
			}
		}
		count=pStatement.executeUpdate();
		//System.out.println("�������ݳɹ�2");
		return count;
	}
	
	/**
	 * @func ��ͨ��ѯ
	 * @param sql
	 * @return ResultSet
	 * @throws SQLException 
	 */
	public ResultSet executeQuery(String sql) throws SQLException {
		ResultSet rSet;
		//System.out.println(sql);
		pStatement=conn.prepareStatement(sql);
		rSet=pStatement.executeQuery();
		//System.out.println("��ѯ���ݳɹ�1");
		return rSet;
	}
	
	/**
	 * @func ͨ��������ѯ����
	 * @param sql
	 * @param obj
	 * @return ResultSet
	 * @throws SQLException
	 */
	public ResultSet executeQuery(String sql,Object obj[]) throws SQLException {
		ResultSet rSet;
		//System.out.println(sql);
		pStatement=conn.prepareStatement(sql);
		if (obj!=null) {
			for (int i = 0; i < obj.length; i++) {
				pStatement.setObject(i+1, obj[i]);
			}
		}
		rSet=pStatement.executeQuery();
		//System.out.println("��ѯ���ݳɹ�2");
		return rSet;
	}
	
	/**
	 * @func ��ʾ���
	 * @param rSet
	 * @throws SQLException
	 */
	public void display(ResultSet rSet) throws SQLException {
		if (rSet.next()) {
			System.out.println(rSet.getString(1)+"\t"+rSet.getString(2)+"\t"+rSet.getString(3)+"\t"+
					rSet.getString(4)+"\t"+rSet.getString(5)+"\t");
		}
		
		//System.out.println("display");
	}
	
	/**
	 * @func ����������Զ��ύ
	 * @throws SQLException
	 */
	public void startTransaction() throws SQLException {
		conn.setAutoCommit(false);
		System.out.println("��ʼ����!");
	}
	
	/**
	 * @func �ύ����
	 * @throws SQLException
	 */
	public void commit() throws SQLException {
		conn.commit();
		System.out.println("�ύ����1");
	}
	
	/**
	 * @func ����ع�
	 * @throws SQLException
	 */
	public void roolback() throws SQLException {
		conn.rollback();
		System.out.println("����ع�!");
	}
	
	
	

/*	*//**
	 * @param args
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 *//*
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		DBConn db=new DBConn();
		String sql="insert into users(id,username,pwd,nickname,money)" +
				"values(?,?,?,?,?)" ;
		Object obj[]={4,"skd","321","JZZ",40000};
		db.connection();
		System.out.println("ok---");
		String sql="select * from users where id=?";
		Object obj[]={3};
		db.display(db.executeQuery(sql,obj));
		
		//db.executeUpdate(sql, obj);
		//db.executeUpdate(sql);
		System.out.println("ok2");
		db.close();
	}*/

}
