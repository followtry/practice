/**
 * @author ����־
 * @time 2014-8-20 ����07:53:47
 * @func �����˶Զ�����Ϣ���д���
 * 
 */
package com.neusoft.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.neusoft.bean.Dining_table;
import com.neusoft.bean.Menu;
import com.neusoft.jdbc.DBConn;

/**
 * @author new
 *
 */
public class ManageDao {
	
	private Connection conn;
	private DBConn db=new DBConn();
	
	public ManageDao() {}
	
	public ManageDao(Connection conn) {
		this.conn=conn;
	}
	

	
	/**
	 * @func �������в���
	 * @return
	 * @throws SQLException
	 */
	public  int cleanAllTable() throws SQLException{
		int count=0;
		db.connection(this.conn);
		String cleanTable="update dining_table set Tstate=0 ";
		count = db.executeUpdate(cleanTable);
		
		return count;
	}
	
	/**
	 * @func �������ж���
	 * @return
	 * @throws SQLException 
	 */
	public int cleanAllOrder() throws SQLException{
		int count=0;
		db.connection(this.conn);
		String cleanOrder="delete from ordermeal";
		count = db.executeUpdate(cleanOrder);
		
		return count;
	}
	
	/**
	 * @func �˲�\�˾�  Ĭ������Ϊ1(�ѶԷ�һ�����������д���)
	 * @param menu
	 * @param dt
	 * @param num
	 * @return int
	 * @throws SQLException
	 */
	public int deleteOrderForm(Menu menu,Dining_table dt) throws SQLException{
		int count=0;
		db.connection(this.conn);
		int tid=dt.getTid();
		int num=1;
		int mid=menu.getMid();
		String mname=menu.getMname();
		System.err.println("---------------------�д���?--------------------------");
		//��ѯδ�ϲ˵�����
		String queryNum="select mnum from ordermeal where tid=? and mid=? and ostat=0";
		Object queryObj[]={tid,mid};
		ResultSet rs=db.executeQuery(queryNum, queryObj);
		if(rs.next()){
			num=rs.getInt("mnum");
		}
		if(num==1){//����Ϊ1ֱ��ɾ����¼
			//insert into ordermeal(tid,mid,mnum,orderdate)  values(?,?,?,sysdate)
			String sql="delete from ordermeal " +
					"where ordermeal.mid=( " +
					"select mid from menu " +
					"where mname=?  ) and ordermeal.tid=(" +
					" select tid from dining_table " +
					"where tid=? ) and ordermeal.ostat=0";
			
			Object obj[]={mname,tid};
			count=db.executeUpdate(sql, obj);
		}else if(num>1){//��������1����ԭ�����ϼ�ȥ1
			String updateNum="update ordermeal set mnum=mnum-1 where  tid=? and mid=? and ostat=0";
			Object updateNumObj[]={tid,mid};
			count = db.executeUpdate(updateNum, updateNumObj);
		}else{
			System.err.println("--�˲�--deleteOrderForm---����-");
		}
		//db.close();
		return count;
	}
	
	/**
	 * @func �����Ѽ�¼���ӵ�����ͳ�Ʊ���,���سɹ����ӵļ�¼��
	 * @param dt
	 * @return int
	 * @throws SQLException 
	 */
	public int appendCountTable(ResultSet rset) throws SQLException{
		int count=0;
		db.connection(this.conn);
		
		/*insert into count_table(cid,mid,orderdate,tid,mnum) values(2,3,sysdate,7,1)*/
		String sql="insert into count_table values(?,?,sysdate,?,?)";
		String sql_1="select max(cid) ����� from COUNT_TABLE ";
		ResultSet r1=db.executeQuery(sql_1);
		int cid=0;
		
		while (rset.next()&&r1.next()) {
			cid=r1.getInt("�����")+1;
			System.out.println("cid="+cid);
			int mid=rset.getInt("�˱��");
			int mnum=rset.getInt("������");
			int tid=rset.getInt("�����");		
			Object obj[]={cid,mid,tid,mnum};
			count+=db.executeUpdate(sql, obj);
			r1=db.executeQuery(sql_1);
		}
		//db.close();
		return count;
	}
	
	/**
	 * @func ��ȡ�Ѿ����ѵļ�¼
	 * @param dt
	 * @return ResultSet
	 * @throws SQLException 
	 */
	public ResultSet getAlreadyConsumeRecord(Dining_table dt) throws SQLException{
		ResultSet rs;
		db.connection(this.conn);
		int tid=dt.getTid();
		String sql="select o.mid �˱��,o.mnum ������,o.tid �����,m.mname ���� " +
				"from  ordermeal o ,dining_table d ,menu m " +
				"where o.tid=d.tid and o.mid=m.mid and o.tid=? and o.ostat=1";
		Object obj[]={tid};
		rs=db.executeQuery(sql, obj);
		//db.close();
		return rs;
	}
	
	/**
	 * @func ��ȡĳ�����е����Ѽ�¼
	 * @param dt
	 * @return ResultSet
	 * @throws SQLException 
	 */
	public ResultSet getAllConsumeRecord(Dining_table dt) throws SQLException{
		ResultSet rs;
		db.connection(this.conn);
		int tid=dt.getTid();
		String sql="select o.mid �˱��,o.mnum ������,o.tid �����,m.mname ���� " +
				"from  ordermeal o ,dining_table d ,menu m " +
				"where o.tid=d.tid and o.mid=m.mid and o.tid=?";
		Object obj[]={tid};
		rs=db.executeQuery(sql, obj);
		//db.close();
		return rs;
	}
	
	/**
	 * @func ��ӡĳ�������Ѽ�¼
	 * @param rSet
	 * @throws SQLException 
	 * @return ResultSet
	 */
	public ResultSet  printConsumeRecord(ResultSet rSet) throws SQLException{
		System.out.println("�����\t�˱��\t����\t������");
		while(rSet.next()){
			int mid=rSet.getInt("�˱��");
			int mnum=rSet.getInt("������");
			int tid=rSet.getInt("�����");
			String mname=rSet.getString("����");
			System.out.println(tid+"\t"+mid+"\t"+mname+"\t"+mnum);
		}
		return rSet;
	}
	
	/**
	 * @func ����ĳ�����������ܶ�
	 * @param dt
	 * @return int
	 * @throws SQLException 
	 */
	public  int  consumeSum(Dining_table dt) throws SQLException{
		ResultSet rs;
		db.connection(this.conn);
		String sql="select sum(mprice*mnum) �����ܺ� from ORDERMEAL o " +
				"join menu m on m.mid=o.mid " +
				"join Dining_Table d on d.tid=o.tid " +
				"and o.tid=? group by o.tid";
		int tid=dt.getTid();
		Object obj[]={tid};
		rs=db.executeQuery(sql,obj);
		int sumOfConsume=0;
		if(rs.next()){
			sumOfConsume=rs.getInt("�����ܺ�");
			System.out.println("�����ܺ�:1--"+sumOfConsume);
		}else{
			System.out.println("�����ܺ�:2--"+sumOfConsume);
		}
		//db.close();
		return sumOfConsume;
	}
	
	/**
	 * @func ��ȡĳ�������Ĳ��ȴ���״̬(�Ƿ��ϲ���)   
	 * @param dt
	 * @param stat
	 * @return	ResultSet 
	 * @throws SQLException 
	 */
	public ResultSet getMenuState(Dining_table dt ,int stat) throws SQLException{
		ResultSet rSet;
		db.connection(this.conn);
		int tid=dt.getTid();
		String sql="select o.tid ����,o.mid �˺�,o.mnum ������,o.ostat ��״̬,m.mname ���� " +
				"from ordermeal o,menu m " +
				"where o.mid=m.mid and o.ostat=? and o.tid=?";
		Object obj[]={stat,tid};
		rSet=db.executeQuery(sql, obj);
		//db.close();
		return rSet;
	}
	 
/*	*//**
	 * @func ����ĳ����ĳ�˵Ĳ��ȴ���״̬ 
	 * @param dt
	 * @param menu
	 * @param oldStat
	 * @param newStat
	 * @return	int
	 * @throws SQLException
	 *//*
	public int updateMenuState_1(Dining_table dt,Menu menu ,int oldStat,int newStat) throws SQLException{
		int count=0;
		db.connection(this.conn);
		int tid=dt.getTid();
		int mid=menu.getMid();
		String sql="update ORDERMEAL set ostat=?  " +
				"where tid=? and ostat=? and mid=?";
		Object obj[]={newStat,tid,oldStat,mid};
		count=db.executeUpdate(sql, obj);
		//db.close();
		return count;
	}
	*/
	
	/**
	 * @func ����ĳ����ĳ�˵Ĳ��ȴ���״̬ (�޸�)  ��Ҫ��������
	 * @param dt ��Ҫ����
	 * @param menu ��Ҫ���ȱ��
	 * @param oldStat
	 * @param newStat
	 * @return	int
	 * @throws SQLException
	 */
	public int updateMenuState(Dining_table dt,Menu menu ,int oldStat,int newStat) throws SQLException{
		int count=0;
		int num=0;
		db.connection(this.conn);
		int tid=dt.getTid();
		int mid=menu.getMid();
		/*********************��ѯ�����������Ӳ˵ľ���*************************************************/
		String queryNum="select mnum from ordermeal where tid=? and mid=? and ostat=?";
		Object queryObj[]={tid,mid,oldStat};
		ResultSet rs=db.executeQuery(queryNum, queryObj);
		if(rs.next()){
			num=rs.getInt("mnum");
		}
		if(num>1){//�����ϼ�һ,���Ҹı�״̬�Ĳ˼����¼��
			String updateNum="update ordermeal set mnum=mnum-1 where  tid=? and mid=?  and ostat=?";
			Object updateObj[]={tid,mid,oldStat};
			int a=0;
			a=db.executeUpdate(updateNum, updateObj);
			if(a>=1){//��δ�ϲ�״̬�����ı�ɹ���,�޸��ϲ�,��ѯ�Ѿ��ϵ�ͬһ���������ж���
				count=queryExitsOrder(tid,mid,newStat);
			}
		}else if(num==1){
			int a=0;
			String sql="delete ORDERMEAL where tid=? and ostat=? and mid=?";
			Object obj[]={tid,oldStat,mid};
			a=db.executeUpdate(sql, obj);
			if(a>=1){//��δ�ϲ�״̬�����ı�ɹ���,�޸��ϲ�,��ѯ�Ѿ��ϵ�ͬһ���������ж���
				count=queryExitsOrder(tid,mid,newStat);
			}
		}else{
			System.err.println("--dao--updateMenuState_1--�˵���û���ֲ�");
		}
		
		/*******************************************************************************************/
		return count;
	}
	
	/**
	 * @func ���²˵�����ʱ��ѯ�Ѿ��ϲ˵����� ֻ��updateMenuState����
	 * @param tid
	 * @param mid
	 * @param newStat
	 * @return
	 * @throws SQLException
	 */
	private int queryExitsOrder(int tid,int mid,int newStat) throws SQLException{
		int count=0;
		String newQuery="select mnum from ordermeal where tid=? and mid=? and ostat=?";
		Object newQueryObj[]={tid,mid,newStat};
		ResultSet res=db.executeQuery(newQuery, newQueryObj);
		int num2=0;
		if(res.next()){ num2=res.getInt("mnum");  }
		if(num2==0){
			int mnum=1;
			String insertNew="insert into ordermeal values(?,?,?,sysdate,?)";
			Object insertNewObj[]={tid,mid,mnum,newStat};
			count=db.executeUpdate(insertNew, insertNewObj);
		}else if(num2>0){//��¼�д����Ѿ��ϵĲ˵�����,����ԭ�����ϼ�1
			
			String updateNew="update ordermeal set mnum=mnum+1  where tid=? and mid=?  and ostat=?";
			Object updateNewObj[]={tid,mid,newStat};
			count=db.executeUpdate(updateNew, updateNewObj);
		}else{
			System.err.println("--dao--updateMenuState_1--�˵�����״̬����,��һ�����˵Ĳ�");
		}
		return count;
	}
	
	/**
	 * @func ��������
	 * @param dt
	 * @return int
	 * @throws SQLException 
	 */
	public int cleanOrder(Dining_table dt) throws SQLException{
		int count=0;
		db.connection(this.conn);
		int tid=dt.getTid();
		String sql="delete from ordermeal where tid=?";
		Object obj[]={tid};
		count=db.executeUpdate(sql, obj);
		//db.close();
		return count;
	}
	
	/**
	 * @func ��������
	 * @param dt
	 * @return
	 * @throws SQLException 
	 */
	public int cleanTable(Dining_table dt) throws SQLException{
		int count=0;
		db.connection(this.conn);
		int tid=dt.getTid();
		String sql="update dining_table set tstate=0 where tid=?";
		Object obj[]={tid};
		count=db.executeUpdate(sql, obj);
		//db.close();
		return count;
	}
	
	
	/**
	 * @func �˵��ϼӲ�
	 * @param menu
	 * @return
	 * @throws SQLException 
	 */
	public int  addMenu(Menu menu) throws SQLException{
		int count=0;
		int max=0;
		String mname=menu.getMname();
		int mprice=menu.getMprice();
		int mtype=menu.getMtype();
		String mpic=menu.getMpic();
		db.connection(this.conn);
		String sqlMax="select max(mid) from menu";
		ResultSet rs=db.executeQuery(sqlMax);
		if(rs.next())
			max=rs.getInt(1)+1;
		String sql="insert into menu(mid,mname,mprice,mtype,mpic) " +
				"values(?,?,?,?,?)";
		Object obj[]={max,mname,mprice,mtype,mpic};
		count=db.executeUpdate(sql, obj);
		//db.close();
		return count;
	}
	
	/**
	 * @func �˵���ɾ��
	 * @param mneu
	 * @return
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public int  deleteMenu(Menu menu) throws SQLException, ClassNotFoundException{
		int count=0;
		db.connection(this.conn);
		BookDinnerDao bDao=new BookDinnerDao(this.conn);
		Menu menu1=null;
		String mname=menu.getMname();
		menu1=bDao.browseMenuByName(mname);
		if(menu1.getMid()>0)
		{
			System.out.println("�˴���");
			String sql="delete from menu where mname=?";
			Object obj[]={mname};
			count = db.executeUpdate(sql, obj);
			System.out.println("ɾ�˳ɹ�");
		}else{
			System.out.println("�˲�����");
		}
		//db.close();
		return count;
	}
	
	/**
	 * @func ���²˼�
	 * @param menu
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public int updateMenuPrice(Menu menu) throws SQLException, ClassNotFoundException{
		int count = 0;
		db.connection(this.conn);
		BookDinnerDao bDao=new BookDinnerDao(this.conn);
		Menu menu1=null;
		String mname=menu.getMname();
		menu1=bDao.browseMenuByName(mname);
		if(menu1.getMid()>0)
		{
			System.out.println("�˴���");
			int mprice=menu.getMprice();
			String sql="update menu set mprice=? where mname=?";
			Object obj[]={mprice,mname};
			count=db.executeUpdate(sql, obj);
			System.out.println("���²˼۳ɹ�");
		}else{
			System.out.println("�˲�����");
		}
		return count;
	}
	
	/**
	 * @func ���ÿ���˵�����
	 * @return
	 * @throws SQLException
	 */
	public ResultSet getSalesVolume() throws SQLException{
		ResultSet rSet;
		/*select  m.mname ����,count(c.mid)    from menu m
		join COUNT_TABLE c on c.mid=m.mid
		group by m.mname
		order by count(c.mid) desc*/
		String sql="select  c.mid �˱��,m.mname ����,m.mprice �۸�,m.mtype ������,sum(c.mnum) ����  " +
				"from menu m " +
				"join COUNT_TABLE c on c.mid=m.mid " +
				"group by c.mid,m.mname,m.mprice,m.mtype " +
				"order by sum(c.mnum) desc";
		db.connection(this.conn);
		rSet=db.executeQuery(sql);
		return rSet;
	}
	
	/**
	 * @func ��ȡ������״̬(�Ƿ�����)
	 * @return
	 * @throws SQLException
	 */
	public ResultSet getTableStat() throws SQLException{
		ResultSet rSet;
		String sql="select tid,pnum,tstate from dining_table order by tid";
		db.connection(this.conn);
		
		rSet=db.executeQuery(sql);
		return rSet;
	}
	
	/**
	 * @func ��ȡ���Ĳ��ȱ��
	 * @return
	 * @throws SQLException 
	 */
	public int getMaxMenuId() throws SQLException{
		int num=0;
		db.connection(this.conn);
		String  sql="select max(mid) ����� from menu";
		ResultSet rs=db.executeQuery(sql);
		if(rs.next()){
			num=rs.getInt("�����");
		}
		return num;
	}
	
	/**
	 * @func ��ȡһ���ܵ����۶�
	 * @param day
	 * @return
	 * @throws SQLException
	 */
	public long getSalesTotleMoneyOfDay(String day) throws SQLException{
		long count=0;
		String beginDate=day+" 00:00:00";
		String endDate=day+" 23:59:59 ";
		db.connection(this.conn);
		String sql=" select sum(m.mprice*c.mnum) from menu m " +
				"join count_table c on c.mid=m.mid  " +
				"and   orderdate>to_date(?,'yyyy-mm-dd HH24:mi:ss') " +
				"and orderdate<to_date(?,'yyyy-mm-dd HH24:mi:ss')";
		Object obj[]={beginDate,endDate};
		ResultSet rs=db.executeQuery(sql, obj);
		while(rs.next()){
			count=rs.getInt(1);
		}
		System.out.println("count="+count);
		return count;
	}
	
	/**
	 * @func ��ȡһ�����ܵ����۶�(�����ʽ:2014-8)
	 * @param day
	 * @return
	 * @throws SQLException
	 */
	public long getSalesTotleMoneyOfMonth(String beginMonth,String endMonth) throws SQLException{
		long count=0;
		db.connection(this.conn);
		String end=endMonth+"-1 00:00:00 ";
		String sql=" select sum(m.mprice*c.mnum) from menu m " +
				"join count_table c on c.mid=m.mid  " +
				"and   orderdate>to_date(?,'yyyy-mm') " +
				"and orderdate<to_date(?,'yyyy-mm-dd HH24:mi:ss') ";
		Object obj[]={beginMonth,end};
		ResultSet rs=db.executeQuery(sql, obj);
		while(rs.next()){
			count=rs.getInt(1);
		}
		System.out.println("count="+count);
		return count;
	}
	
	/**
	 * @throws SQLException 
	 * @func ���ղ�ѯ�����˾Ƶ����۶�
	 * @return ResultSet
	 *
	 */
	public ResultSet queryByDay(String day) throws SQLException{
		ResultSet rs;
		db.connection(this.conn);
		String beginDate=day+" 00:00:00";
		String endDate=day+" 23:59:59";
		String sql="select m.mid �˱��,m.mname ����,m.mprice �˼�,sum(c.mnum) ����, sum(c.mnum*m.mprice) �����۶� " +
				"from menu m join count_table c on c.mid=m.mid  " +
				"and  orderdate>to_date(?,'yyyy-mm-dd HH24:mi:ss') " +
				"and orderdate<to_date(?,'yyyy-mm-dd HH24:mi:ss') " +
				"group by m.mid,m.mname,m.mprice " +
				"order by sum(c.mnum*m.mprice) desc,m.mid asc";
		Object obj[]={beginDate,endDate};
		System.out.println(sql);
		rs=db.executeQuery(sql, obj);
		/*while(rs.next()){
			System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getInt(3)+"\t"+rs.getInt(4)+"\t"+rs.getInt(5));
		}*/
		return rs;
	}
	
	/**
	 * @throws SQLException 
	 * @func ���²�ѯ���۶�(�����ʽ:2014-8)
	 * @return ResultSet
	 *
	 */
	public ResultSet  queryByMonth(String beginMonth,String endMonth) throws SQLException{
		ResultSet rs;
		db.connection(this.conn);
		String end=endMonth+"-1 00:00:00 ";
		String sql="select m.mid �˱��,m.mname ����,m.mprice �˼�,sum(c.mnum) ����, sum(c.mnum*m.mprice) �����۶� " +
				"from menu m join count_table c on c.mid=m.mid  " +
				"and   orderdate>to_date(?,'yyyy-mm') " +
				"and orderdate<to_date(?,'yyyy-mm-dd HH24:mi:ss') " +
				"group by m.mid,m.mname,m.mprice " +
				"order by sum(c.mnum*m.mprice) desc,m.mid asc";
		Object obj[]={beginMonth,end};
		System.out.println(sql);
		rs=db.executeQuery(sql, obj);
		/*while(rs.next()){
			System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t" +
					""+rs.getInt(3)+"\t"+rs.getInt(4)+"\t" +
							""+rs.getInt(5));
		}*/
		return rs;
		
	}
}